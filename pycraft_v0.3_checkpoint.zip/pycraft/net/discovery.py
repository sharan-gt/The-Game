"""Tiny LAN discovery: hosts shout 'PYCRAFT2|name|port|players' over UDP broadcast,
the Join screen listens and lists them. Everything is best-effort and silent on failure."""
import socket
import threading
import time

from net import protocol as P


class Announcer:
    def __init__(self, world_name, port, players_fn):
        self.world_name, self.port, self.players_fn = world_name, port, players_fn
        self.stop = False
        threading.Thread(target=self._run, name="net-announce", daemon=True).start()

    def _run(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        except OSError:
            return
        while not self.stop:
            msg = f"PYCRAFT{P.PROTOCOL}|{self.world_name[:24]}|{self.port}|{self.players_fn()}".encode()
            for dest in ("255.255.255.255", "<broadcast>"):
                try:
                    s.sendto(msg, (dest, P.DISCOVERY_PORT))
                except OSError:
                    pass
            time.sleep(1.5)
        s.close()

    def close(self):
        self.stop = True


class Listener:
    def __init__(self):
        self.found = {}        # ip -> (name, port, players, last_seen)
        self.stop = False
        threading.Thread(target=self._run, name="net-listen", daemon=True).start()

    def _run(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind(("", P.DISCOVERY_PORT))
            s.settimeout(0.5)
        except OSError:
            return
        while not self.stop:
            try:
                data, addr = s.recvfrom(512)
            except socket.timeout:
                continue
            except OSError:
                break
            try:
                tag, name, port, players = data.decode().split("|")
                if tag == f"PYCRAFT{P.PROTOCOL}":
                    self.found[addr[0]] = (name, int(port), players, time.time())
            except ValueError:
                pass
        s.close()

    def servers(self):
        now = time.time()
        return [(ip, v[0], v[1], v[2]) for ip, v in self.found.items() if now - v[3] < 6]

    def close(self):
        self.stop = True


def local_ips():
    ips = []
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ips.append(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    if not ips:
        try:
            ips.append(socket.gethostbyname(socket.gethostname()))
        except OSError:
            ips.append("127.0.0.1")
    return ips
