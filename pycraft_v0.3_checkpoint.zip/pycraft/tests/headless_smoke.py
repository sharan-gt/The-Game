"""Boot -> title -> create world -> play, screenshot each stage. Headless via Xvfb."""
import sys, os, time, shutil
ROOT = __import__("pathlib").Path(__file__).resolve().parent.parent; sys.path.insert(0, str(ROOT))
os.chdir(ROOT)
OUT = str(ROOT / "cache")
from ursina import Ursina, window, held_keys
from panda3d.core import Filename
app = Ursina(title="t", development_mode=False, fullscreen=False, borderless=False, vsync=False,
             size=(1100, 640), show_ursina_splash=False, editor_ui_enabled=False)
for a in ("exit_button", "fps_counter", "cog_button", "entity_counter", "collider_counter"):
    try: getattr(window, a).enabled = False
    except Exception: pass
from game.app import Game
from game import screens
g = Game(app, safe=False)
shutil.rmtree("saves/_smoke", ignore_errors=True)

def frames(n, dt=1/30):
    for _ in range(n):
        app.taskMgr.step()
        g.tick(dt)

def shot(name):
    for _ in range(2): app.taskMgr.step()
    app.win.save_screenshot(Filename(os.path.join(OUT, name)))
    print("shot", name, "state", g.state)

t0 = time.time()
while g.state == "boot":
    frames(1)
print("boot", round(time.time()-t0, 2), "s ->", g.state)
frames(120)
shot("sm_title.png")
g.start_new_world("_smoke", 4242, "creative")
t0 = time.time()
while g.state == "loading" and time.time() - t0 < 40:
    frames(1)
print("loading took", round(time.time()-t0, 2), "s ->", g.state, "pos", [round(v,1) for v in g.player.pos])
frames(90)
shot("sm_play1.png")
g.player.pitch = 40
frames(10)
shot("sm_play_down.png")
g.player.pitch = 5
g.player.yaw = 90
g.cfg["show_debug"] = True; g.hud.set_debug(True)
frames(20)
shot("sm_play_debug.png")
print(g.debug_text())
# survival test: spawn mobs near
g.set_gamemode("survival")
for k in ("boar", "woolly", "hen", "shambler"):
    g.mobs.spawn(k, (g.player.pos[0] + 3, g.player.pos[1] + 1, g.player.pos[2] + 3 + ["boar","woolly","hen","shambler"].index(k)))
g.player.yaw = 0
frames(60)
g.player.yaw = 45; g.player.pitch = 10
frames(5)
shot("sm_mobs.png")
g.time_of_day = 0.62
frames(20)
shot("sm_night.png")
g.time_of_day = 0.1
g.open_pause(); frames(5); shot("sm_pause.png")
g.resume()
g.open_overlay(lambda: screens.inventory(g)); frames(5); shot("sm_inventory.png")
g.resume()
g.open_overlay(lambda: screens.soundboard(g, g.resume)); frames(5); shot("sm_soundboard.png")
g.resume()
n = g.save_world(); print("saved", n)
g.quit_to_title(); frames(30)
screens.options(g, lambda: screens.title_screen(g)); frames(5); shot("sm_options.png")
screens.world_select(g); frames(5); shot("sm_worlds.png")
screens.multiplayer(g); frames(5); shot("sm_multi.png")
screens.mods_screen(g, lambda: screens.title_screen(g)); frames(5); shot("sm_mods.png")
print("SMOKE OK")
