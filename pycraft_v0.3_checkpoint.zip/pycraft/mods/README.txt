PyCraft mods
============
Put a .py file here (or a folder containing mod.py) and restart the game.
Mods are listed on  Title screen -> Mods  where each can be switched off.

Smallest possible mod:

    MOD_NAME = "Hello"
    def register(api):
        api.add_block("ruby_block", color=(0.8, 0.1, 0.2), hotbar=True)
        api.add_command("hi", lambda game, args: "hello!", "say hello")

API (api.*):
    add_block(name, color=(r,g,b) | png="file.png", hardness=1.0, solid=True,
              transparent=False, glow=False, material="stone", hotbar=False)
    add_command(name, func(game, args) -> str, help)     # used as /name
    add_key(key, func(game), help)                       # e.g. "j"
    on(event, func)  events: start tick block_break block_place key chat mob_killed
    log(...)

`game` gives you: game.world (get_block / set_block), game.player (pos, vel, yaw,
health, give(name, n)), game.mobs (spawn / damage), game.audio (play(name)), game.say(text).

A mod that raises more than 3 errors is switched off automatically - it can never
crash the game. See lamp_block.py, jetpack.py and hello_commands.py for examples.
