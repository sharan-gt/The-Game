"""Headless tests for streaming, edits, saves and physics (no window needed)."""
import sys, time, tempfile, shutil
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import numpy as np
from engine import blocks as B, atlas as A, world as W, physics, raycast, settings


class Node:
    def __init__(self): self.alive = True
    def remove_node(self): self.alive = False


class FakeRenderer:
    def __init__(self): self.live = []
    def make_chunk_nodes(self, cx, cz, s, w):
        a = Node() if s is not None else None
        b = Node() if w is not None else None
        self.live += [n for n in (a, b) if n]
        return a, b


def pump(world, px, pz, secs=30):
    t0 = time.time()
    while time.time() - t0 < secs:
        world.update(px, pz, budget_ms=8)
        if not world.busy():
            return True
        time.sleep(0.002)
    return False


def main():
    at = A.build("patrix", B.tile_names(), B.extra_tiles)
    B.tables.build(at.index)
    settings.SAVE_DIR = Path(tempfile.mkdtemp())
    W.SAVE_DIR = settings.SAVE_DIR
    fr = FakeRenderer()
    w = W.World(777, fr, B.tables, at.uv, name="t", render_distance=5)
    sx, sz = w.gen.find_spawn()
    t0 = time.time()
    assert pump(w, sx, sz), "streaming never settled"
    print(f"initial load: {time.time()-t0:.2f}s chunks={len(w.chunks)} uploads={w.stats['uploads']}")
    R = w.render_distance
    pcx, pcz = sx >> 4, sz >> 4
    for dx in range(-R, R + 1):
        for dz in range(-R, R + 1):
            c = w.chunks[(pcx + dx, pcz + dz)]
            assert c.meshed == c.version, ("unmeshed", dx, dz)
    assert len(w.chunks) == (2 * R + 3) ** 2, len(w.chunks)

    # ---- edit: break the surface block, mesh must change on the same call
    h = w.column_top(sx, sz)
    c = w.chunks[(sx >> 4, sz >> 4)]
    old_node = c.solid
    assert w.set_block(sx, h, sz, B.AIR)
    assert c.solid is not old_node and not old_node.alive, "edit did not remesh immediately"
    assert w.get_block(sx, h, sz) == B.AIR
    assert w.set_block(sx, h, sz, B.PLANKS) and w.get_block(sx, h, sz) == B.PLANKS

    # ---- border edit remeshes the neighbour too
    bx = (pcx + 1) * 16
    hb = w.column_top(bx, sz)
    nb = w.chunks[(bx >> 4, sz >> 4)]; nb_node = nb.solid
    left = w.chunks[((bx - 1) >> 4, sz >> 4)]; left_node = left.solid
    w.set_block(bx, hb, sz, B.AIR)
    assert nb.solid is not nb_node and left.solid is not left_node, "border edit missed a neighbour"

    # ---- sand falls
    sx2, sz2 = sx + 3, sz + 3
    top = w.column_top(sx2, sz2)
    w.set_block(sx2, top + 3, sz2, B.SAND)
    t0 = time.time()
    while w.get_block(sx2, top + 1, sz2) != B.SAND and time.time() - t0 < 4:
        w.update(sx, sz); time.sleep(0.02)
    assert w.get_block(sx2, top + 1, sz2) == B.SAND, "sand did not settle"

    # ---- walk far away: bounded memory, old chunks unloaded, edits remembered
    maxc = 0
    for step in range(1, 60):
        px = sx + step * 8
        w.update(px, sz, budget_ms=8)
        maxc = max(maxc, len(w.chunks))
        time.sleep(0.01)
    assert pump(w, sx + 59 * 8, sz)
    live = sum(1 for n in fr.live if n.alive)
    print(f"after 470-block trek: chunks={len(w.chunks)} (max {maxc}) live nodes={live}")
    assert len(w.chunks) <= (2 * R + 5) ** 2
    assert live <= len(w.chunks) * 2
    assert (sx >> 4, sz >> 4) not in w.chunks and (sx >> 4, sz >> 4) in w.saved
    # come back: the edit is still there
    pump(w, sx, sz)
    assert w.get_block(sx, h, sz) == B.PLANKS, "edit lost after unload/reload"

    # ---- save / load round trip
    n = w.save({"hello": 1})
    w2 = W.World(777, fr, B.tables, at.uv, name="t", render_distance=3)
    w2.load_edits()
    pump(w2, sx, sz)
    assert w2.get_block(sx, h, sz) == B.PLANKS, "edit lost after save/load"
    print("saved chunks:", n)

    # ---- physics: fall to the ground, stop flush, jump height, wall stop
    pos = [sx + 0.5, h + 1 + 30, sz + 0.5]
    vel = [0.0, 0.0, 0.0]
    for _ in range(400):
        vel[1] = max(vel[1] - settings.GRAVITY * 0.016, settings.TERMINAL_VELOCITY)
        g, *_ = physics.move(w, pos, vel, 0.016)
        if g: break
    floor_y = h + 1                       # planks block we placed is at h
    assert g and abs(pos[1] - floor_y) < 0.01, (g, pos[1], floor_y)
    # big lag spike must not tunnel
    pos2 = [sx + 0.5, h + 40.0, sz + 0.5]; vel2 = [0.0, -50.0, 0.0]
    for _ in range(10):
        physics.move(w, pos2, vel2, 0.1)
    assert pos2[1] > h, f"tunnelled through floor: {pos2[1]}"
    # jump apex
    vel[1] = settings.JUMP_SPEED; apex = pos[1]
    for _ in range(120):
        vel[1] -= settings.GRAVITY * 0.008
        physics.move(w, pos, vel, 0.008)
        apex = max(apex, pos[1])
    print(f"jump apex {apex - floor_y:.2f} blocks")
    assert 1.1 < apex - floor_y < 1.6
    # raycast straight down hits the planks
    hit = raycast.cast(w, (sx + 0.5, h + 5.5, sz + 0.5), (0, -1, 0), 8)
    assert hit and hit[0] == (sx, h, sz) and hit[2] == (0, 1, 0), hit
    w.shutdown(); w2.shutdown()
    shutil.rmtree(settings.SAVE_DIR, ignore_errors=True)
    print("ALL WORLD TESTS PASSED")


if __name__ == "__main__":
    main()
