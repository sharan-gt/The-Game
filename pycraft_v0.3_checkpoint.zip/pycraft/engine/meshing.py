"""
Vectorised chunk mesher (pure numpy, no Panda3D, safe to run on a worker thread).

Input is a "padded" block array of shape (sx+2, H+2, sz+2): the chunk plus a
one-block border copied from its neighbours, so faces on chunk edges are culled
correctly and ambient occlusion is seamless.

Winding: Ursina/Panda run in a left-handed Y-up space. The corner order listed
in FACES is counter-clockwise in right-handed maths, so triangles are emitted as
(0,2,1)/(0,3,2) -- verified by rendering a coloured cube (see tools/ tests).
Emitting (0,1,2)/(0,2,3) instead makes every face inside-out: tops disappear
and you see the underside of the world.
"""
import numpy as np

from engine import blocks as B

# name, normal, corners (x,y,z offsets inside the unit cube), tile selector, shade
FACES = [
    ("top",    (0, 1, 0),  [(0, 1, 0), (0, 1, 1), (1, 1, 1), (1, 1, 0)], "top",    1.00),
    ("bottom", (0, -1, 0), [(0, 0, 1), (0, 0, 0), (1, 0, 0), (1, 0, 1)], "bottom", 0.50),
    ("north",  (0, 0, 1),  [(1, 0, 1), (1, 1, 1), (0, 1, 1), (0, 0, 1)], "side",   0.84),
    ("south",  (0, 0, -1), [(0, 0, 0), (0, 1, 0), (1, 1, 0), (1, 0, 0)], "side",   0.84),
    ("east",   (1, 0, 0),  [(1, 0, 0), (1, 1, 0), (1, 1, 1), (1, 0, 1)], "side",   0.68),
    ("west",   (-1, 0, 0), [(0, 0, 1), (0, 1, 1), (0, 1, 0), (0, 0, 0)], "side",   0.68),
]

# VIS[class_of_block][class_of_neighbour] -> is the face visible?
#            air  opaque cutout water
VIS = np.array([[0, 0, 0, 0],      # air never draws
                [1, 0, 1, 1],      # opaque
                [1, 0, 1, 1],      # cutout (same-id culled separately)
                [1, 0, 1, 0]],     # water
               dtype=bool)

AO_LEVELS = np.array([0.50, 0.68, 0.84, 1.00], np.float32)
PAT_NORMAL = np.array([0, 2, 1, 0, 3, 2], np.uint32)
PAT_FLIPPED = np.array([1, 0, 3, 1, 3, 2], np.uint32)
WATER_DROP = 0.1


def make_pad(blocks, nbr, bedrock_id=B.BEDROCK):
    """blocks: (sx,H,sz) uint8. nbr: {(dx,dz): blocks array or None}."""
    sx, H, sz = blocks.shape
    pad = np.zeros((sx + 2, H + 2, sz + 2), np.uint8)
    pad[:, 0, :] = bedrock_id                 # floor of the world is solid
    pad[1:-1, 1:-1, 1:-1] = blocks
    n = nbr.get((-1, 0))
    if n is not None:
        pad[0, 1:-1, 1:-1] = n[-1, :, :]
    n = nbr.get((1, 0))
    if n is not None:
        pad[-1, 1:-1, 1:-1] = n[0, :, :]
    n = nbr.get((0, -1))
    if n is not None:
        pad[1:-1, 1:-1, 0] = n[:, :, -1]
    n = nbr.get((0, 1))
    if n is not None:
        pad[1:-1, 1:-1, -1] = n[:, :, 0]
    n = nbr.get((-1, -1))
    if n is not None:
        pad[0, 1:-1, 0] = n[-1, :, -1]
    n = nbr.get((1, -1))
    if n is not None:
        pad[-1, 1:-1, 0] = n[0, :, -1]
    n = nbr.get((-1, 1))
    if n is not None:
        pad[0, 1:-1, -1] = n[-1, :, 0]
    n = nbr.get((1, 1))
    if n is not None:
        pad[-1, 1:-1, -1] = n[0, :, 0]
    return pad


def _empty():
    return None


def mesh_chunk(pad, T, uvt):
    """Returns (solid_mesh, water_mesh); each is None or a dict of arrays:
       pos float32 (n,3), uv float32 (n,2), col uint8 (n,4), idx uint32 (m,)"""
    sx, H, sz = pad.shape[0] - 2, pad.shape[1] - 2, pad.shape[2] - 2
    cls_pad = T.cls[pad]
    core = pad[1:-1, 1:-1, 1:-1]
    cls_core = cls_pad[1:-1, 1:-1, 1:-1]
    if not cls_core.any():
        return None, None
    occ = (cls_pad == B.OPAQUE)

    # ---- sky exposure per column (cheap fake skylight: caves get dark) ------
    sky_occ = T.sky[pad]
    has = sky_occ.any(axis=1)
    top = (H + 2) - np.argmax(sky_occ[:, ::-1, :], axis=1)
    top = np.where(has, top, 0).astype(np.int32)

    P_pos, P_uv, P_col, P_flip, P_water = [], [], [], [], []

    for name, nrm, corners, sel, shade in FACES:
        dx, dy, dz = nrm
        nb_cls = cls_pad[1 + dx:1 + dx + sx, 1 + dy:1 + dy + H, 1 + dz:1 + dz + sz]
        nb_ids = pad[1 + dx:1 + dx + sx, 1 + dy:1 + dy + H, 1 + dz:1 + dz + sz]
        vis = VIS[cls_core, nb_cls]
        vis &= ~((cls_core == B.CUTOUT) & (core == nb_ids))
        ii, jj, kk = np.nonzero(vis)
        n = ii.size
        if n == 0:
            continue
        ids = core[ii, jj, kk]
        tile = getattr(T, sel)[ids]
        rect = uvt[tile]                                    # (n,4) u0,v0,u1,v1
        corners_a = np.array(corners, np.float32)           # (4,3)
        base = np.stack([ii, jj, kk], 1).astype(np.float32)
        pos = base[:, None, :] + corners_a[None, :, :]       # (n,4,3)

        is_water = cls_core[ii, jj, kk] == B.WATER_CLS
        if is_water.any():
            above = cls_pad[ii + 1, jj + 2, kk + 1]
            lower = is_water & (above != B.WATER_CLS)
            if lower.any():
                top_corner = (corners_a[:, 1] == 1.0)[None, :]
                pos[:, :, 1] -= (WATER_DROP * lower[:, None] * top_corner)

        uv = np.empty((n, 4, 2), np.float32)
        uv[:, 0, 0] = rect[:, 0]; uv[:, 0, 1] = rect[:, 1]
        uv[:, 1, 0] = rect[:, 0]; uv[:, 1, 1] = rect[:, 3]
        uv[:, 2, 0] = rect[:, 2]; uv[:, 2, 1] = rect[:, 3]
        uv[:, 3, 0] = rect[:, 2]; uv[:, 3, 1] = rect[:, 1]

        # ---- lighting: face shade * ambient occlusion * sky exposure -----------
        pi, pj, pk = ii + 1, jj + 1, kk + 1
        qi, qj, qk = pi + dx, pj + dy, pk + dz
        axis = 0 if dx else (1 if dy else 2)
        u_ax, v_ax = [a for a in range(3) if a != axis]
        eu = np.zeros(3, np.int32); eu[u_ax] = 1
        ev = np.zeros(3, np.int32); ev[v_ax] = 1
        ao = np.empty((n, 4), np.int8)
        for c in range(4):
            su = 2 * int(corners[c][u_ax]) - 1
            sv = 2 * int(corners[c][v_ax]) - 1
            s1 = occ[qi + su * eu[0], qj + su * eu[1], qk + su * eu[2]]
            s2 = occ[qi + sv * ev[0], qj + sv * ev[1], qk + sv * ev[2]]
            co = occ[qi + su * eu[0] + sv * ev[0], qj + su * eu[1] + sv * ev[1],
                     qk + su * eu[2] + sv * ev[2]]
            level = 3 - (s1.astype(np.int8) + s2.astype(np.int8) + co.astype(np.int8))
            ao[:, c] = np.where(s1 & s2, 0, level)
        light = AO_LEVELS[ao]                                # (n,4)
        depth = np.maximum(top[qi, qk] - qj, 0).astype(np.float32)
        sky = np.clip(1.0 - depth * 0.105, 0.22, 1.0)
        bright = shade * light * sky[:, None]
        glow = T.glow[ids]
        if glow.any():
            bright = np.where(glow[:, None], 1.0, bright)
        if is_water.any():
            bright = np.where(is_water[:, None], np.minimum(1.0, shade + 0.15) * sky[:, None], bright)
        col = np.empty((n, 4, 4), np.uint8)
        v8 = np.clip(bright * 255.0, 0, 255).astype(np.uint8)
        col[:, :, 0] = v8; col[:, :, 1] = v8; col[:, :, 2] = v8; col[:, :, 3] = 255
        flip = (ao[:, 0] + ao[:, 2]) < (ao[:, 1] + ao[:, 3])

        P_pos.append(pos); P_uv.append(uv); P_col.append(col)
        P_flip.append(flip); P_water.append(is_water)

    if not P_pos:
        return None, None
    pos = np.concatenate(P_pos); uv = np.concatenate(P_uv); col = np.concatenate(P_col)
    flip = np.concatenate(P_flip); water = np.concatenate(P_water)

    def pack(sel):
        m = int(sel.sum())
        if m == 0:
            return None
        p = pos[sel].reshape(-1, 3)
        u = uv[sel].reshape(-1, 2)
        c = col[sel].reshape(-1, 4)
        base_idx = (np.arange(m, dtype=np.uint32) * 4)[:, None]
        pat = np.where(flip[sel][:, None], PAT_FLIPPED[None, :], PAT_NORMAL[None, :])
        idx = (base_idx + pat).reshape(-1)
        return {"pos": np.ascontiguousarray(p, np.float32),
                "uv": np.ascontiguousarray(u, np.float32),
                "col": np.ascontiguousarray(c, np.uint8),
                "idx": idx.astype(np.uint32)}

    return pack(~water), pack(water)
