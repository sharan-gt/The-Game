"""LAN host. Runs in threads inside the host's game; the game loop only ever calls
poll()/send()/broadcast(), which never block (each client has its own writer thread)."""
import queue
import socket
import threading
import time

from net import protocol as P


class Peer:
    def __init__(self, pid, sock, addr):
        self.pid = pid
        self.sock = sock
        self.addr = addr
        self.name = f"Player{pid}"
        self.out = queue.Queue(maxsize=4000)
        self.alive = True
        self.joined = False
        self.pos = (0.0, 0.0, 0.0, 0.0, 0.0)


class GameServer:
    def __init__(self, port=P.PORT, max_players=8):
        self.port = port
        self.max_players = max_players
        self.peers = {}
        self.events = queue.SimpleQueue()
        self.lock = threading.Lock()
        self.next_pid = 1
        self.closed = False
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind(("0.0.0.0", port))
        self.sock.listen(8)
        self.sock.settimeout(0.5)
        threading.Thread(target=self._accept, name="net-accept", daemon=True).start()

    # ---- threads -----------------------------------------------------------------
    def _accept(self):
        while not self.closed:
            try:
                s, addr = self.sock.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            with self.lock:
                if len(self.peers) >= self.max_players:
                    try:
                        s.sendall(P.encode({"t": "kick", "reason": "server full"}))
                        s.close()
                    except OSError:
                        pass
                    continue
                pid = self.next_pid
                self.next_pid += 1
                peer = Peer(pid, s, addr)
                self.peers[pid] = peer
            s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            s.settimeout(30)
            threading.Thread(target=self._reader, args=(peer,), name=f"net-r{pid}", daemon=True).start()
            threading.Thread(target=self._writer, args=(peer,), name=f"net-w{pid}", daemon=True).start()

    def _reader(self, peer):
        lb = P.LineBuffer(P.MAX_CLIENT_LINE)
        try:
            while peer.alive and not self.closed:
                data = peer.sock.recv(65536)
                if not data:
                    break
                for m in lb.feed(data):
                    if m.get("t") == "hello" and not peer.joined:
                        if m.get("proto") != P.PROTOCOL:
                            self._send_raw(peer, {"t": "kick", "reason": "version mismatch"})
                            raise ConnectionError("version mismatch")
                        peer.name = str(m.get("name", peer.name))[:16] or peer.name
                        peer.joined = True
                        self.events.put(("join", peer.pid, peer.name))
                    elif peer.joined:
                        self.events.put(("msg", peer.pid, m))
        except (OSError, ValueError, ConnectionError):
            pass
        finally:
            self._drop(peer)

    def _writer(self, peer):
        try:
            while peer.alive and not self.closed:
                try:
                    data = peer.out.get(timeout=0.5)
                except queue.Empty:
                    continue
                if data is None:
                    break
                peer.sock.sendall(data)
        except OSError:
            pass
        finally:
            self._drop(peer)

    def _send_raw(self, peer, msg):
        try:
            peer.sock.sendall(P.encode(msg))
        except OSError:
            pass

    def _drop(self, peer):
        with self.lock:
            if self.peers.pop(peer.pid, None) is None:
                return
        peer.alive = False
        try:
            peer.sock.shutdown(socket.SHUT_RDWR)      # unblocks recv() in the reader
        except OSError:
            pass
        try:
            peer.sock.close()
        except OSError:
            pass
        try:
            peer.out.put_nowait(None)
        except queue.Full:
            pass
        if peer.joined:
            self.events.put(("leave", peer.pid, peer.name))

    # ---- API for the game loop -------------------------------------------------------
    def poll(self):
        out = []
        while True:
            try:
                out.append(self.events.get_nowait())
            except queue.Empty:
                return out

    def send(self, pid, msg):
        peer = self.peers.get(pid)
        if peer is None or not peer.alive:
            return
        try:
            peer.out.put_nowait(P.encode(msg))
        except queue.Full:
            self._drop(peer)                           # client can't keep up

    def broadcast(self, msg, exclude=None):
        data = P.encode(msg)
        for pid, peer in list(self.peers.items()):
            if pid == exclude or not peer.joined or not peer.alive:
                continue
            try:
                peer.out.put_nowait(data)
            except queue.Full:
                self._drop(peer)

    def players(self):
        return [(p.pid, p.name) for p in self.peers.values() if p.joined]

    def kick(self, pid, reason="kicked"):
        self.send(pid, {"t": "kick", "reason": reason})
        peer = self.peers.get(pid)
        if peer:
            time.sleep(0.05)
            self._drop(peer)

    def close(self):
        self.closed = True
        for peer in list(self.peers.values()):
            self._drop(peer)
        try:
            self.sock.close()
        except OSError:
            pass
