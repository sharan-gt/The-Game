"""All menus. Every screen is a function that builds a ui.Screen and shows it."""
import shutil
import time as pytime
import zlib

from ursina import Entity, camera, window
from ursina.color import Color

from engine import atlas as A
from engine import blocks as B
from engine import render, world as W
from engine.settings import PACK_DIR, SAVE_DIR, SOUND_DIR, VERSION, TITLE
from net import discovery
from net import protocol as NP
from game import ui as U


def _backdrop(s, alpha=0.55):
    Entity(parent=s.root, model='quad', scale=(4, 2), color=Color(0.02, 0.03, 0.05, alpha), z=0.3)


def _panel(s, w, h, title, y=0.0, sub=None):
    U.Panel(s.root, 0, y, w, h, U.PANEL, z=0.2)
    U.Label(s.root, title, 0, y + h / 2 - 0.055, 1.9, U.ACCENT)
    if sub:
        U.Label(s.root, sub, 0, y + h / 2 - 0.105, 0.9, U.DIM)


def _new(g, name):
    s = U.Screen(g.ui, name)
    g.ui.show(s)
    g.set_cursor(True)
    return s


# ------------------------------------------------------------------ title ------
def title_screen(g):
    s = _new(g, "title")
    _backdrop(s, 0.28)
    U.Label(s.root, "PYCRAFT", 0, 0.30, 5.2, U.ACCENT)
    U.Label(s.root, "a voxel sandbox for modest laptops", 0, 0.205, 1.05, U.TEXT)
    y = 0.095
    for text, fn in (("Singleplayer", lambda: world_select(g)),
                     ("Multiplayer", lambda: multiplayer(g)),
                     ("Options", lambda: options(g, lambda: title_screen(g))),
                     ("Soundboard", lambda: soundboard(g, lambda: title_screen(g))),
                     ("Mods", lambda: mods_screen(g, lambda: title_screen(g)))):
        U.Btn(s.root, text, 0, y, 0.52, 0.065, fn)
        y -= 0.082
    U.Btn(s.root, "Quit", 0, y - 0.01, 0.52, 0.065, g.quit, U.BTN_RED, U.BTN_RED_HI)
    U.Label(s.root, f"v{VERSION}", -window.aspect_ratio / 2 + 0.015, -0.485, 0.8, U.DIM, origin=(-0.5, -0.5))
    pack = A.pack_info(g.cfg["resource_pack"]).get("name", g.cfg["resource_pack"])
    U.Label(s.root, f"Pack: {pack}   |   Shader: {g.cfg['shader']}   |   Original game - not affiliated with Mojang or Microsoft",
            0, -0.485, 0.75, U.DIM, origin=(0, -0.5))
    return s


# ---------------------------------------------------------------- single player --
def _ago(ts):
    d = max(0, pytime.time() - ts)
    if d < 90:
        return "just now"
    if d < 5400:
        return f"{int(d // 60)} min ago"
    if d < 172800:
        return f"{int(d // 3600)} h ago"
    return f"{int(d // 86400)} days ago"


def world_select(g):
    s = _new(g, "worlds")
    _backdrop(s)
    _panel(s, 1.15, 0.86, "Singleplayer", sub="Pick a world, or start a new one")
    worlds = W.list_worlds()
    items = [f"{m.get('name', m['dir'])}    {m.get('gamemode', 'creative')}    seed {m.get('seed')}    {_ago(m.get('saved_at', 0))}"
             for m in worlds]
    lst = U.ScrollList(s.root, 0, 0.19, 1.0, rows=6, row_h=0.075)
    lst.set_items(items, "No worlds yet - press New World")
    state = {"del": False}

    def selected():
        i = lst.selected()
        return worlds[i] if i is not None else None

    play = U.Btn(s.root, "Play Selected", -0.36, -0.34, 0.3, 0.065,
                 lambda: selected() and g.load_world(selected()["dir"]), U.BTN_ON, U.BTN_ON_HI)
    U.Btn(s.root, "New World", -0.04, -0.34, 0.3, 0.065, lambda: create_world(g))
    dbtn = U.Btn(s.root, "Delete", 0.28, -0.34, 0.26, 0.065, None, U.BTN_RED, U.BTN_RED_HI)

    def delete():
        w = selected()
        if not w:
            return
        if not state["del"]:
            state["del"] = True
            dbtn.set_text("Really delete?")
            return
        shutil.rmtree(SAVE_DIR / w["dir"], ignore_errors=True)
        world_select(g)

    dbtn.cb = delete
    lst.on_select = lambda i: (state.update({"del": False}), dbtn.set_text("Delete"))
    U.Btn(s.root, "Back", 0, -0.415, 0.3, 0.06, lambda: title_screen(g))
    if not worlds:
        play.set_disabled(True)
    return s


def create_world(g):
    s = _new(g, "create")
    _backdrop(s)
    _panel(s, 0.9, 0.78, "Create World")
    U.Label(s.root, "World name", -0.36, 0.20, 0.95, U.DIM, origin=(-0.5, 0))
    name = U.TextField(s.root, 0.0, 0.14, 0.72, 0.058, "New World", 24, hint="World name")
    U.Label(s.root, "Seed (empty = random)", -0.36, 0.05, 0.95, U.DIM, origin=(-0.5, 0))
    seed = U.TextField(s.root, 0.0, -0.01, 0.72, 0.058, "", 20, hint="random")
    s.fields = [name, seed]
    mode = {"v": g.cfg["gamemode"]}
    U.Cycler(s.root, "Game mode", 0, -0.12, 0.72, 0.062, ["creative", "survival"],
             lambda: mode["v"], lambda v: mode.update(v=v), fmt=lambda v: v.capitalize())
    U.Label(s.root, "Creative: fly, unlimited blocks.  Survival: health, mining time, hostile mobs at night.",
            0, -0.19, 0.8, U.DIM)

    def create():
        sd = seed.text.strip()
        if sd == "":
            import random
            sv = random.randrange(1, 2 ** 31)
        elif sd.lstrip("-").isdigit():
            sv = int(sd) % (2 ** 31)
        else:
            sv = zlib.crc32(sd.encode()) % (2 ** 31)
        g.start_new_world(name.text.strip() or "World", sv, mode["v"])

    U.Btn(s.root, "Create World", -0.2, -0.30, 0.34, 0.07, create, U.BTN_ON, U.BTN_ON_HI)
    U.Btn(s.root, "Cancel", 0.2, -0.30, 0.34, 0.07, lambda: world_select(g))
    name.on_click()
    return s


# ---------------------------------------------------------------- multiplayer ----
def multiplayer(g, host_only=False):
    s = _new(g, "multiplayer")
    _backdrop(s)
    _panel(s, 1.45, 0.88, "Multiplayer", sub="Play together on the same Wi-Fi / LAN")
    U.Label(s.root, "JOIN A GAME", -0.36, 0.28, 1.15, U.ACCENT)
    U.Label(s.root, "Your name", -0.66, 0.22, 0.85, U.DIM, origin=(-0.5, 0))
    nm = U.TextField(s.root, -0.36, 0.17, 0.60, 0.055, g.cfg["player_name"], 16, hint="name")
    U.Label(s.root, "Host address", -0.66, 0.095, 0.85, U.DIM, origin=(-0.5, 0))
    ip = U.TextField(s.root, -0.36, 0.045, 0.60, 0.055, g.cfg["last_ip"], 40, hint="192.168.1.20",
                     allowed="0123456789.:abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-")
    s.fields = [nm, ip]

    def join():
        g.cfg["player_name"] = nm.text.strip() or "Player"
        g.cfg["last_ip"] = ip.text.strip()
        g.cfg.save()
        host, _, port = ip.text.strip().partition(":")
        g.join(host or "127.0.0.1", int(port) if port.isdigit() else NP.PORT, g.cfg["player_name"])

    U.Btn(s.root, "Join", -0.36, -0.04, 0.60, 0.065, join, U.BTN_ON, U.BTN_ON_HI)
    U.Label(s.root, "Games found on your network", -0.66, -0.115, 0.85, U.DIM, origin=(-0.5, 0))
    found = U.ScrollList(s.root, -0.36, -0.17, 0.60, rows=3, row_h=0.066)
    found.set_items([], "Searching... (or type the host's address)")
    lis = g.net_listener()
    cache = {"srv": [], "t": 0.0}

    def pick(i):
        if i < len(cache["srv"]):
            ip.text = f"{cache['srv'][i][0]}:{cache['srv'][i][2]}"
            ip._render()
    found.on_select = pick

    def upd():
        cache["t"] += 0.016
        if cache["t"] > 1.0:
            cache["t"] = 0.0
            srv = lis.servers()
            if [x[:3] for x in srv] != [x[:3] for x in cache["srv"]]:
                cache["srv"] = srv
                found.set_items([f"{n}   ({players} online)   {ip_}" for ip_, n, p, players in srv],
                                "Searching... (or type the host's address)")
                found.sel = -1
                found._draw()
    s.on_update = upd

    # right: host
    U.Label(s.root, "HOST YOUR WORLD", 0.36, 0.28, 1.15, U.ACCENT)
    worlds = W.list_worlds()
    wl = U.ScrollList(s.root, 0.36, 0.20, 0.60, rows=4, row_h=0.07)
    wl.set_items([f"{m.get('name', m['dir'])}  ({m.get('gamemode', 'creative')})" for m in worlds],
                 "Create a world first")
    ips = discovery.local_ips()
    U.Label(s.root, f"Friends join with:  {ips[0]}:{NP.PORT}", 0.36, -0.12, 0.95, U.WARN)
    U.Label(s.root, "Everyone must be on the same network. Hosting runs in this window.", 0.36, -0.16, 0.7, U.DIM)
    hb = U.Btn(s.root, "Host Selected World", 0.36, -0.235, 0.60, 0.065,
               lambda: wl.selected() is not None and g.load_world(worlds[wl.selected()]["dir"], host=True),
               U.BTN_ON, U.BTN_ON_HI)
    if not worlds:
        hb.set_disabled(True)
    U.Btn(s.root, "Back", 0, -0.37, 0.3, 0.06, lambda: (g.close_listener(), title_screen(g)))
    return s


def connecting(g, text="Connecting..."):
    s = _new(g, "connecting")
    _backdrop(s, 0.75)
    U.Label(s.root, text, 0, 0.05, 1.6, U.TEXT)
    U.Btn(s.root, "Cancel", 0, -0.1, 0.3, 0.06, g.cancel_join)
    return s


def message(g, title, text, back, colour=U.WARN):
    s = _new(g, "message")
    _backdrop(s, 0.75)
    U.Panel(s.root, 0, 0, 1.0, 0.4, U.PANEL, z=0.2)
    U.Label(s.root, title, 0, 0.1, 1.6, colour)
    U.Label(s.root, text, 0, 0.02, 0.95, U.TEXT)
    U.Btn(s.root, "OK", 0, -0.1, 0.3, 0.06, back)
    return s


# --------------------------------------------------------------------- options ---
def options(g, back):
    s = _new(g, "options")
    _backdrop(s)
    _panel(s, 1.4, 0.92, "Options")
    cfg = g.cfg
    L, R = -0.36, 0.36
    w, h = 0.64, 0.062
    y0, dy = 0.25, 0.082

    def setcfg(k, v):
        cfg[k] = v
        cfg.save()

    U.Cycler(s.root, "View distance", L, y0, w, h, list(range(2, 13)),
             lambda: cfg["render_distance"], lambda v: (setcfg("render_distance", v), g.set_render_distance(v)),
             fmt=lambda v: f"{v} chunks")
    U.Cycler(s.root, "Field of view", L, y0 - dy, w, h, list(range(60, 111, 5)),
             lambda: int(cfg["fov"]), lambda v: setcfg("fov", v))
    U.Cycler(s.root, "Mouse sensitivity", L, y0 - 2 * dy, w, h, list(range(10, 101, 5)),
             lambda: int(cfg["mouse_sensitivity"]), lambda v: setcfg("mouse_sensitivity", v))
    U.Cycler(s.root, "Volume", L, y0 - 3 * dy, w, h, [i / 10 for i in range(0, 11)],
             lambda: round(cfg["master_volume"], 1), lambda v: setcfg("master_volume", v),
             fmt=lambda v: f"{int(v * 100)}%")
    U.Toggle(s.root, "Music", L, y0 - 4 * dy, w, h, lambda: cfg["music"], lambda v: setcfg("music", v))
    U.Toggle(s.root, "Hostile & friendly mobs", L, y0 - 5 * dy, w, h, lambda: cfg["mobs"], lambda v: g.set_mobs(v))

    ids = A.list_packs()
    names = {i: A.pack_info(i).get("name", i) for i in ids}
    U.Cycler(s.root, "Resource pack", R, y0, w, h, ids, lambda: cfg["resource_pack"],
             lambda v: g.set_resource_pack(v), fmt=lambda v: names.get(v, v))
    desc = U.Label(s.root, "", R, y0 - 2 * dy, 0.8, U.DIM)

    def set_shader(v):
        g.set_shader(v)
        desc.text = render.SHADER_INFO[v]

    U.Cycler(s.root, "Shader pack", R, y0 - dy, w, h, render.SHADER_NAMES, lambda: cfg["shader"], set_shader)
    desc.text = render.SHADER_INFO.get(cfg["shader"], "")
    U.Toggle(s.root, "Auto performance guard", R, y0 - 3 * dy, w, h, lambda: cfg["auto_performance"],
             lambda v: setcfg("auto_performance", v))
    U.Toggle(s.root, "Debug info (F3)", R, y0 - 4 * dy, w, h, lambda: cfg["show_debug"], lambda v: g.set_debug(v))
    U.Toggle(s.root, "Fullscreen (F11)", R, y0 - 5 * dy, w, h, lambda: bool(window.fullscreen), lambda v: g.set_fullscreen(v))
    U.Label(s.root, "Packs live in resourcepacks/<name>/blocks/*.png (+ pack.json). Missing tiles use built-in art.",
            0, -0.31, 0.78, U.DIM)
    U.Label(s.root, "If anything looks wrong or runs slowly: Shader = off, View distance = 3.", 0, -0.345, 0.78, U.DIM)
    U.Btn(s.root, "Done", 0, -0.41, 0.34, 0.065, back, U.BTN_ON, U.BTN_ON_HI)
    return s


# ------------------------------------------------------------------- soundboard --
def soundboard(g, back):
    s = _new(g, "soundboard")
    _backdrop(s)
    _panel(s, 1.5, 0.92, "Soundboard", sub="Click a sound (or press 1-9). In multiplayer everyone hears it.")
    items = [(lbl, n, None) for n, lbl in __import__("engine.audio", fromlist=["x"]).SOUNDBOARD_LABELS.items()]
    g.audio.scan_user_clips()
    for lbl, path in g.audio.user_clips:
        items.append((lbl[:14], None, path))
    cols = 5
    cw, ch = 0.27, 0.075
    x0 = -(cols - 1) * cw / 2
    y0 = 0.27
    for i, (lbl, name, path) in enumerate(items[:25]):
        x, y = x0 + (i % cols) * cw, y0 - (i // cols) * (ch + 0.01)
        tag = f"{i + 1}. " if i < 9 else ""
        fn = (lambda n=name: g.play_soundboard(n)) if name else (lambda p=path: g.play_soundboard_file(p))
        U.Btn(s.root, tag + lbl, x, y, cw - 0.012, ch, fn, U.BTN if name else U.BTN_ON,
              U.BTN_HI if name else U.BTN_ON_HI, size=0.9)
    U.Label(s.root, f"Add your own .wav/.ogg/.mp3 clips to:  {SOUND_DIR / 'soundboard'}", 0, -0.30, 0.8, U.DIM)
    U.Label(s.root, "Green buttons are your own clips.", 0, -0.335, 0.8, U.DIM)
    U.Btn(s.root, "Back", 0, -0.41, 0.34, 0.065, back)
    s.on_key = lambda key: (key.isdigit() and 0 < int(key) <= min(9, len(items)) and
                            (g.play_soundboard(items[int(key) - 1][1]) if items[int(key) - 1][1]
                             else g.play_soundboard_file(items[int(key) - 1][2])))
    return s


# ------------------------------------------------------------------------ mods -----
def mods_screen(g, back):
    s = _new(g, "mods")
    _backdrop(s)
    _panel(s, 1.3, 0.86, "Mods", sub=f"Drop .py files into  {g.mod_dir}  - restart to apply changes")
    mods = g.mods.mods
    if not mods:
        U.Label(s.root, "No mods found. See mods/README.txt to write one in ~10 lines.", 0, 0.1, 1.0, U.DIM)
    y = 0.22
    for m in mods[:6]:
        on = m.enabled
        col = U.BTN_ON if on else (U.BTN_RED if m.error else U.BTN)
        info = f"{m.name}  v{m.version}"
        if m.error:
            info += f"   ERROR: {m.error[:48]}"
        elif m.blocks or m.commands or m.keys:
            bits = []
            if m.blocks:
                bits.append(f"{len(m.blocks)} blocks")
            if m.commands:
                bits.append("/" + " /".join(m.commands[:3]))
            if m.keys:
                bits.append("keys " + ",".join(m.keys))
            info += "   " + "  ".join(bits)
        b = U.Btn(s.root, info, -0.05, y, 1.0, 0.068, None, col, U.BTN_ON_HI if on else U.BTN_HI, size=0.9)
        b.label.origin = (-0.5, 0)
        b.label.x = -0.55

        def toggle(m=m, b=b):
            dis = set(g.cfg["mods_disabled"])
            if m.id in dis:
                dis.discard(m.id)
            else:
                dis.add(m.id)
            g.cfg["mods_disabled"] = sorted(dis)
            g.cfg.save()
            state = "will be OFF" if m.id in dis else "will be ON"
            b.label.text = f"{m.name}   {state} after restart"
        b.cb = toggle
        U.Label(s.root, m.desc[:90], -0.55, y - 0.04, 0.72, U.DIM, origin=(-0.5, 0))
        y -= 0.115
    U.Btn(s.root, "Back", 0, -0.39, 0.34, 0.065, back)
    return s


# --------------------------------------------------------------------- pause ------
def pause(g):
    s = _new(g, "pause")
    _backdrop(s, 0.5)
    U.Panel(s.root, 0, 0, 0.7, 0.8, U.PANEL, z=0.2)
    U.Label(s.root, "Paused", 0, 0.34, 2.0, U.ACCENT)
    y = 0.22
    items = [("Back to Game", g.resume),
             ("Options", lambda: options(g, lambda: pause(g))),
             ("Soundboard", lambda: soundboard(g, lambda: pause(g))),
             ("Save World", lambda: (g.save_world(), g.hud.toast("World saved", U.ACCENT), g.resume()))]
    if not g.is_client:
        items.append(("Open to LAN" if g.server is None else "LAN: open (port %d)" % NP.PORT,
                      lambda: (g.host_current(), pause(g))))
    items.append(("Save & Quit to Title", g.quit_to_title))
    for i, (t, fn) in enumerate(items):
        col = U.BTN_RED if t.startswith("Save & Quit") else (U.BTN_ON if t == "Back to Game" else U.BTN)
        hi = U.BTN_RED_HI if t.startswith("Save & Quit") else (U.BTN_ON_HI if t == "Back to Game" else U.BTN_HI)
        U.Btn(s.root, t, 0, y, 0.52, 0.065, fn, col, hi)
        y -= 0.085
    if g.server is not None:
        ips = discovery.local_ips()
        U.Label(s.root, f"Friends join: {ips[0]}:{NP.PORT}", 0, y - 0.01, 0.9, U.WARN)
    return s


def dead(g):
    s = _new(g, "dead")
    Entity(parent=s.root, model='quad', scale=(4, 2), color=Color(0.35, 0.02, 0.02, 0.6), z=0.3)
    U.Label(s.root, "You died!", 0, 0.12, 4.0, U.BAD)
    U.Btn(s.root, "Respawn", 0, -0.03, 0.4, 0.07, g.respawn_from_death, U.BTN_ON, U.BTN_ON_HI)
    U.Btn(s.root, "Save & Quit to Title", 0, -0.12, 0.4, 0.07, g.quit_to_title, U.BTN_RED, U.BTN_RED_HI)
    return s


# ---------------------------------------------------------------------- inventory --
class _Cell(Entity):
    def __init__(self, parent, x, y, size, name, count, icon, label, pick):
        super().__init__(parent=parent, model='quad', position=(x, y, -0.01), scale=(size, size),
                         color=Color(0.2, 0.22, 0.27, 1), collider='box')
        self.icon = Entity(parent=parent, model='quad', texture=icon, position=(x, y, -0.05),
                           scale=(size * 0.8, size * 0.8))
        self.name, self.label_ref, self.pick = name, label, pick
        self.count = U.Label(parent, str(count) if count else "", x + size * 0.42, y - size * 0.3, 0.8,
                             U.TEXT, origin=(0.5, -0.5), z=-0.08)

    def on_mouse_enter(self):
        self.color = Color(0.35, 0.45, 0.62, 1)
        self.label_ref.text = self.name.replace("_", " ")

    def on_mouse_exit(self):
        self.color = Color(0.2, 0.22, 0.27, 1)

    def on_click(self):
        self.pick(self.name)


def inventory(g):
    s = _new(g, "inventory")
    _backdrop(s, 0.45)
    survival = g.gamemode == "survival"
    _panel(s, 1.08, 0.86, "Inventory",
           sub="Click a block to put it in your selected hotbar slot" if not survival
           else "Your collected blocks")
    names = [b.name for b in B.placeable_blocks()]
    if survival:
        names = [n for n in names if g.player.count(n) > 0] + [n for n in g.player.items if n not in names and g.player.count(n) > 0]
    hover = U.Label(s.root, "", 0, -0.165, 1.1, U.TEXT)
    cols, size, gap = 9, 0.092, 0.101
    x0 = -(cols - 1) * gap / 2
    y0 = 0.25

    def pick(name):
        g.player.hotbar[g.player.selected] = name
        g.audio.play("tick", 0.5)
        g.hud.refresh_hotbar()
    for i, n in enumerate(names[:36]):
        _Cell(s.root, x0 + (i % cols) * gap, y0 - (i // cols) * gap, size, n,
              g.player.count(n) if survival else 0, g.hud.icon_tex(n), hover, pick)
    if not names:
        U.Label(s.root, "Nothing yet - go mine something!", 0, 0.05, 1.2, U.DIM)
    U.Label(s.root, "Hotbar - click a slot to select it", 0, -0.215, 0.8, U.DIM)
    marks = []

    def select(i):
        g.player.selected = i
        g.hud.refresh_hotbar()
        for k, m in enumerate(marks):
            m.color = Color(1, 1, 1, 0.95) if k == i else Color(0.3, 0.33, 0.4, 1)

    for i in range(9):
        x = x0 + i * gap
        mark = Entity(parent=s.root, model='quad', position=(x, -0.275, -0.005), scale=(size + 0.012, size + 0.012),
                      color=Color(1, 1, 1, 0.95) if i == g.player.selected else Color(0.3, 0.33, 0.4, 1))
        marks.append(mark)
        name = g.player.hotbar[i]
        c = _Cell(s.root, x, -0.275, size, name or "", g.player.count(name) if (survival and name) else 0,
                  g.hud.icon_tex(name) if name else None, hover, lambda n, i=i: select(i))
        if not name:
            c.icon.enabled = False
    U.Btn(s.root, "Close (E)", 0, -0.375, 0.3, 0.06, g.resume)
    return s


def loading(g, text="Loading...", sub=""):
    s = _new(g, "loading")
    Entity(parent=s.root, model='quad', scale=(4, 2), color=U.BG, z=0.3)
    U.Label(s.root, "PYCRAFT", 0, 0.2, 4.0, U.ACCENT)
    s.text = U.Label(s.root, text, 0, 0.02, 1.3, U.TEXT)
    s.sub = U.Label(s.root, sub, 0, -0.04, 0.9, U.DIM)
    s.bar = U.Bar(s.root, 0, -0.1, 0.7)
    return s
