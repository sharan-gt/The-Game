"""
World storage and Minecraft-style chunk streaming.

  * chunks are 16 x 64 x 16 uint8 arrays
  * a single worker thread generates terrain and builds meshes (numpy, no Panda3D)
  * the main thread only inserts finished chunks and uploads meshes, under a small
    per-frame time budget, so streaming never stalls a frame
  * chunks are meshed only when all 8 neighbours exist (no holes / seams)
  * chunks outside the keep radius are unloaded; edited chunks are remembered
  * saves are one small npz + json, written atomically
"""
import itertools
import json
import os
import queue
import threading
import time
from collections import deque
from pathlib import Path

import numpy as np

from engine import blocks as B
from engine import meshing
from engine.settings import CHUNK_H, CHUNK_X, CHUNK_Z, SAVE_DIR
from engine.terrain import TerrainGenerator

H = CHUNK_H
_NBR8 = [(dx, dz) for dx in (-1, 0, 1) for dz in (-1, 0, 1) if (dx, dz) != (0, 0)]


class Chunk:
    __slots__ = ("cx", "cz", "blocks", "solid", "water", "version",
                 "meshed", "modified")

    def __init__(self, cx, cz, blocks, modified=False):
        self.cx, self.cz = cx, cz
        self.blocks = blocks
        self.solid = None          # NodePath or None
        self.water = None
        self.version = 1           # bumped whenever blocks (or a neighbour edge) change
        self.meshed = 0            # version currently shown
        self.modified = modified


class World:
    def __init__(self, seed, renderer, tables, uvt, name="world", render_distance=4):
        self.seed = int(seed)
        self.name = name
        self.renderer = renderer
        self.T = tables
        self.uvt = uvt
        self.gen = TerrainGenerator(self.seed)
        self.chunks = {}
        self.saved = {}                 # key -> array for edited chunks not loaded
        self.pending_edits = {}         # key -> [(x,y,z,id)] for chunks not loaded yet
        self.render_distance = int(render_distance)
        self.stats = {"gen": 0, "mesh": 0, "uploads": 0, "mesh_ms": 0.0}
        self.edit_counter = 0
        self.falling = []               # [(due_time, x, y, z)] sand/gravel to settle
        self.on_chunk_unload = None     # callback(cx,cz) for mobs etc.

        self._jobs = queue.PriorityQueue()
        self._results = queue.SimpleQueue()
        self._seq = itertools.count()
        self._wanted = set()
        self._pending_gen = set()
        self._pending_mesh = {}         # key -> version in flight
        self._ready = deque()
        self._mesh_dirty = True
        self._center = None
        self._stop = False
        self._worker = threading.Thread(target=self._run, name="chunk-worker", daemon=True)
        self._worker.start()

    # ------------------------------------------------------------ worker ---
    def _run(self):
        T, uvt, gen = self.T, self.uvt, self.gen
        while not self._stop:
            try:
                _, _, job = self._jobs.get(timeout=0.25)
            except queue.Empty:
                continue
            if job is None:
                break
            try:
                if job[0] == "gen":
                    key = job[1]
                    if key not in self._wanted:
                        self._results.put(("skip", key))
                        continue
                    blocks = gen.generate(*key)
                    self._results.put(("gen", key, blocks))
                else:
                    _, key, version, pad = job
                    t0 = time.perf_counter()
                    s, w = meshing.mesh_chunk(pad, T, uvt)
                    self._results.put(("mesh", key, version, s, w,
                                       (time.perf_counter() - t0) * 1000.0))
            except Exception as e:                       # never kill the worker
                print("[world] worker error:", repr(e))
                if job and job[0] == "gen":
                    self._results.put(("skip", job[1]))
                elif job:
                    self._results.put(("meshfail", job[1]))

    def destroy(self):
        """Stop the worker and remove every node (used when leaving a world)."""
        self.shutdown()
        for c in list(self.chunks.values()):
            if c.solid is not None:
                c.solid.remove_node()
            if c.water is not None:
                c.water.remove_node()
        self.chunks.clear()
        self.saved.clear()
        self._ready.clear()
        self.on_chunk_unload = None

    def invalidate_all(self):
        """Re-mesh everything (texture pack changed)."""
        for c in self.chunks.values():
            c.version += 1
        self._pending_mesh.clear()
        self._mesh_dirty = True

    def shutdown(self):
        self._stop = True
        try:
            self._jobs.put((-1, -1, None))
        except Exception:
            pass

    # ------------------------------------------------------- block access ---
    def get_block(self, x, y, z):
        """Block id, or -1 if the chunk isn't loaded."""
        if y < 0:
            return B.BEDROCK
        if y >= H:
            return B.AIR
        c = self.chunks.get((x >> 4, z >> 4))
        if c is None:
            return -1
        return int(c.blocks[x & 15, y, z & 15])

    def is_solid(self, x, y, z):
        """Physics query. Unloaded terrain counts as solid so nobody falls out."""
        if y < 0:
            return True
        if y >= H:
            return False
        c = self.chunks.get((x >> 4, z >> 4))
        if c is None:
            return True
        return bool(self.T.solid[c.blocks[x & 15, y, z & 15]])

    def is_water(self, x, y, z):
        if y < 0 or y >= H:
            return False
        c = self.chunks.get((x >> 4, z >> 4))
        return c is not None and c.blocks[x & 15, y, z & 15] == B.WATER

    def column_top(self, x, z):
        """y of the highest solid block in a loaded column, else -1."""
        c = self.chunks.get((x >> 4, z >> 4))
        if c is None:
            return -1
        col = self.T.solid[c.blocks[x & 15, :, z & 15]]
        idx = np.nonzero(col)[0]
        return int(idx[-1]) if idx.size else -1

    def loaded_around(self, x, z, radius=1):
        cx, cz = int(x) >> 4, int(z) >> 4
        return all((cx + dx, cz + dz) in self.chunks
                   for dx in range(-radius, radius + 1) for dz in range(-radius, radius + 1))

    def set_block(self, x, y, z, bid, remesh=True, track=True):
        if y < 0 or y >= H:
            return False
        key = (x >> 4, z >> 4)
        c = self.chunks.get(key)
        if c is None:
            self.pending_edits.setdefault(key, []).append((x, y, z, bid))
            return False
        lx, lz = x & 15, z & 15
        old = int(c.blocks[lx, y, lz])
        if old == bid:
            return False
        c.blocks[lx, y, lz] = bid
        c.modified = True
        self.edit_counter += 1
        self._touch(c, lx, lz)
        if remesh:
            self.remesh_now(c, lx, lz)
        if track and bid == B.AIR:
            self._maybe_fall(x, y + 1, z)
        elif track and bid in (B.SAND, B.GRAVEL):
            self._maybe_fall(x, y, z)
        return True

    def _touch(self, c, lx, lz):
        c.version += 1
        for dx in (-1, 0, 1):
            for dz in (-1, 0, 1):
                if (dx, dz) == (0, 0):
                    continue
                if (dx == -1 and lx != 0) or (dx == 1 and lx != CHUNK_X - 1) \
                        or (dz == -1 and lz != 0) or (dz == 1 and lz != CHUNK_Z - 1):
                    continue
                n = self.chunks.get((c.cx + dx, c.cz + dz))
                if n is not None:
                    n.version += 1
        self._mesh_dirty = True

    def remesh_now(self, c, lx, lz):
        """Rebuild the edited chunk (and touched neighbours) right now so a
        broken block disappears on the same frame."""
        targets = [c]
        for dx, dz in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            if (dx == -1 and lx == 0) or (dx == 1 and lx == CHUNK_X - 1) \
                    or (dz == -1 and lz == 0) or (dz == 1 and lz == CHUNK_Z - 1):
                n = self.chunks.get((c.cx + dx, c.cz + dz))
                if n is not None:
                    targets.append(n)
        for t in targets:
            if self._neighbours_ready(t.cx, t.cz):
                self._mesh_sync(t)

    def _neighbours_ready(self, cx, cz):
        ch = self.chunks
        return all((cx + dx, cz + dz) in ch for dx, dz in _NBR8)

    def _make_pad(self, c):
        nbr = {}
        for dx, dz in _NBR8:
            n = self.chunks.get((c.cx + dx, c.cz + dz))
            nbr[(dx, dz)] = n.blocks if n is not None else None
        return meshing.make_pad(c.blocks, nbr)

    def _mesh_sync(self, c):
        t0 = time.perf_counter()
        s, w = meshing.mesh_chunk(self._make_pad(c), self.T, self.uvt)
        self._upload(c, s, w, c.version)
        self.stats["mesh_ms"] = (time.perf_counter() - t0) * 1000.0

    def _upload(self, c, s, w, version):
        if c.solid is not None:
            c.solid.remove_node()
            c.solid = None
        if c.water is not None:
            c.water.remove_node()
            c.water = None
        c.solid, c.water = self.renderer.make_chunk_nodes(c.cx, c.cz, s, w)
        c.meshed = version
        self.stats["uploads"] += 1

    # ----------------------------------------------------- sand / gravel ---
    def _maybe_fall(self, x, y, z):
        b = self.get_block(x, y, z)
        if b in (B.SAND, B.GRAVEL) and self.get_block(x, y - 1, z) in (B.AIR, B.WATER):
            self.falling.append((time.perf_counter() + 0.12, x, y, z))

    def tick_falling(self):
        if not self.falling:
            return
        now = time.perf_counter()
        keep = []
        for due, x, y, z in self.falling:
            if due > now:
                keep.append((due, x, y, z))
                continue
            b = self.get_block(x, y, z)
            if b in (B.SAND, B.GRAVEL) and self.get_block(x, y - 1, z) in (B.AIR, B.WATER):
                self.set_block(x, y, z, B.AIR, track=False)
                self.set_block(x, y - 1, z, b, track=False)
                self._maybe_fall(x, y + 1, z)        # whatever was on top follows
                self._maybe_fall(x, y - 1, z)        # keep falling
        self.falling = keep

    # ------------------------------------------------------- streaming ---
    def set_render_distance(self, r):
        self.render_distance = max(2, int(r))
        self._center = None
        self._mesh_dirty = True

    def update(self, px, pz, budget_ms=4.0):
        cx, cz = int(px) >> 4, int(pz) >> 4
        if (cx, cz) != self._center:
            self._center = (cx, cz)
            self._rescan(cx, cz)
        self._collect(budget_ms)
        if self._mesh_dirty:
            self._schedule_meshes(cx, cz)
        self.tick_falling()

    def _rescan(self, cx, cz):
        R = self.render_distance
        want = []
        for dx in range(-R - 1, R + 2):
            for dz in range(-R - 1, R + 2):
                want.append((max(abs(dx), abs(dz)) + 0.01 * (abs(dx) + abs(dz)),
                             (cx + dx, cz + dz)))
        want.sort()
        wanted = {k for _, k in want}
        self._wanted = wanted
        for d, key in want:
            if key in self.chunks or key in self._pending_gen:
                continue
            if key in self.saved:
                self._insert_chunk(key, self.saved.pop(key), modified=True)
                continue
            self._pending_gen.add(key)
            self._jobs.put((d, next(self._seq), ("gen", key)))
        # unload with 1 chunk of hysteresis
        keep = R + 2
        for key in [k for k in self.chunks
                    if abs(k[0] - cx) > keep or abs(k[1] - cz) > keep]:
            self._unload(key)
        self._mesh_dirty = True

    def _insert_chunk(self, key, blocks, modified=False):
        c = Chunk(key[0], key[1], blocks, modified)
        self.chunks[key] = c
        pe = self.pending_edits.pop(key, None)
        if pe:
            for x, y, z, bid in pe:
                c.blocks[x & 15, y, z & 15] = bid
            c.modified = True
        for dx, dz in _NBR8:
            n = self.chunks.get((key[0] + dx, key[1] + dz))
            if n is not None:
                n.version += 1
        self._mesh_dirty = True
        return c

    def _unload(self, key):
        c = self.chunks.pop(key, None)
        if c is None:
            return
        if c.solid is not None:
            c.solid.remove_node()
        if c.water is not None:
            c.water.remove_node()
        if c.modified:
            self.saved[key] = c.blocks
        self._pending_mesh.pop(key, None)
        if self.on_chunk_unload:
            self.on_chunk_unload(*key)

    def _collect(self, budget_ms):
        deadline = time.perf_counter() + budget_ms / 1000.0
        # pull everything the worker finished
        while True:
            try:
                r = self._results.get_nowait()
            except queue.Empty:
                break
            kind = r[0]
            if kind == "gen":
                key = r[1]
                self._pending_gen.discard(key)
                if key in self._wanted and key not in self.chunks:
                    self._insert_chunk(key, r[2])
                self.stats["gen"] += 1
            elif kind == "skip":
                self._pending_gen.discard(r[1])
            elif kind == "mesh":
                self._ready.append(r)
                self.stats["mesh"] += 1
            elif kind == "meshfail":
                self._pending_mesh.pop(r[1], None)
        n = 0
        while self._ready:
            _, key, version, s, w, ms = self._ready.popleft()
            if self._pending_mesh.get(key) == version:
                del self._pending_mesh[key]
            c = self.chunks.get(key)
            if c is None or version < c.meshed:
                continue
            self.stats["mesh_ms"] = ms
            self._upload(c, s, w, version)
            n += 1
            if c.version != version:
                self._mesh_dirty = True
            if time.perf_counter() > deadline:
                break

    def _schedule_meshes(self, pcx, pcz):
        self._mesh_dirty = False
        R = self.render_distance
        todo = []
        for key, c in self.chunks.items():
            dx, dz = key[0] - pcx, key[1] - pcz
            d = max(abs(dx), abs(dz))
            if d > R:
                continue
            if c.meshed == c.version or self._pending_mesh.get(key) == c.version:
                continue
            if not self._neighbours_ready(*key):
                continue
            todo.append((d + 0.01 * (abs(dx) + abs(dz)), key, c))
        todo.sort(key=lambda t: t[0])
        for d, key, c in todo[:12]:               # small batches keep memory flat
            pad = self._make_pad(c)
            self._pending_mesh[key] = c.version
            self._jobs.put((d, next(self._seq), ("mesh", key, c.version, pad)))
        if len(todo) > 12:
            self._mesh_dirty = True               # come back for the rest

    def busy(self):
        return bool(self._pending_gen or self._pending_mesh or self._ready
                    or self._mesh_dirty)

    def visible_chunk_count(self):
        return sum(1 for c in self.chunks.values() if c.solid is not None or c.water is not None)

    # ----------------------------------------------------------- saving ---
    def world_dir(self):
        return (SAVE_DIR / self.name).resolve()

    def save(self, meta=None):
        d = self.world_dir()
        d.mkdir(parents=True, exist_ok=True)
        arrays = {}
        for key, blocks in self.saved.items():
            arrays[f"c_{key[0]}_{key[1]}"] = blocks
        for key, c in self.chunks.items():
            if c.modified:
                arrays[f"c_{key[0]}_{key[1]}"] = c.blocks
        tmp = d / "chunks.tmp.npz"
        np.savez_compressed(str(tmp), **arrays)
        os.replace(tmp, d / "chunks.npz")
        m = dict(meta or {})
        m.update({"name": self.name, "seed": self.seed, "saved_at": time.time(),
                  "format": 2})
        tmpj = d / "world.tmp.json"
        tmpj.write_text(json.dumps(m, indent=1))
        os.replace(tmpj, d / "world.json")
        return len(arrays)

    def load_edits(self):
        p = self.world_dir() / "chunks.npz"
        if not p.exists():
            return 0
        try:
            with np.load(str(p)) as z:
                for name in z.files:
                    _, a, b = name.split("_")
                    arr = z[name]
                    if arr.shape == (CHUNK_X, H, CHUNK_Z):
                        self.saved[(int(a), int(b))] = arr.astype(np.uint8)
        except Exception as e:
            print("[world] could not read chunks.npz:", e)
        return len(self.saved)


# ------------------------------------------------------------ save listing ---
def list_worlds():
    out = []
    if not SAVE_DIR.exists():
        return out
    for d in sorted(SAVE_DIR.iterdir()):
        j = d / "world.json"
        if j.is_file():
            try:
                m = json.loads(j.read_text())
                m["dir"] = d.name
                out.append(m)
            except Exception:
                continue
    out.sort(key=lambda m: -m.get("saved_at", 0))
    return out


def unique_world_name(base):
    base = "".join(ch for ch in base.strip() if ch.isalnum() or ch in " _-") or "World"
    name, i = base, 2
    while (SAVE_DIR / name).exists():
        name = f"{base} {i}"
        i += 1
    return name
