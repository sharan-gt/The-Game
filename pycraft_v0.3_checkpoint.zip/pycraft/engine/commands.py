"""Chat commands (/help to list). Mods can add more through api.add_command."""
import math

from engine import blocks as B
from engine import mobs as M
from engine import render

ALIASES = {"cobble": "cobblestone", "wood": "planks", "tree": "log", "dirt": "dirt",
           "coal": "coal_ore", "iron": "iron_ore", "gold": "gold_ore", "diamond": "diamond_ore"}


def _gm(game, a):
    if not a or a[0][0].lower() not in "cs01":
        return "usage: /gamemode creative|survival"
    mode = "creative" if a[0][0].lower() in "c1" else "survival"
    game.set_gamemode(mode)
    return f"game mode: {mode}"


def _tp(game, a):
    if len(a) == 1 and game.net_players():
        t = game.find_player(a[0])
        if t is None:
            return "no such player"
        game.player.pos[:] = [t[0], t[1], t[2]]
        game.player.reset_motion()
        return f"teleported to {a[0]}"
    if len(a) != 3:
        return "usage: /tp x y z   (or /tp <player>)"
    try:
        cur = game.player.pos
        vals = []
        for i, s in enumerate(a):
            vals.append(cur[i] + float(s[1:] or 0) if s.startswith("~") else float(s))
    except ValueError:
        return "coordinates must be numbers"
    game.player.pos[:] = vals
    game.player.reset_motion()
    return "teleported"


def _time(game, a):
    if not a:
        return f"time of day: {game.time_of_day:.2f}  (0 sunrise, .25 noon, .5 sunset, .75 midnight)"
    names = {"day": 0.08, "sunrise": 0.0, "noon": 0.25, "sunset": 0.46, "night": 0.62, "midnight": 0.75}
    key = a[-1].lower()
    if key in names:
        game.set_time(names[key])
        return f"time set to {key}"
    try:
        game.set_time(float(key) % 1.0)
        return "time set"
    except ValueError:
        return "usage: /time day|noon|sunset|night|midnight|<0-1>"


def _give(game, a):
    if not a:
        return "usage: /give <block> [count]"
    name = ALIASES.get(a[0].lower(), a[0].lower())
    b = B.by_name(name)
    if b is None or not b.placeable:
        return "unknown block. try /blocks"
    n = int(a[1]) if len(a) > 1 and a[1].isdigit() else 64
    game.player.give(name, n)
    if name not in game.player.hotbar:
        game.player.hotbar[game.player.selected] = name
    return f"gave {n} {name}"


def _summon(game, a):
    kind = a[0].lower() if a else ""
    if kind not in M.SPECS:
        return "usage: /summon " + "|".join(M.SPECS) + " [count]"
    n = max(1, min(int(a[1]), 12)) if len(a) > 1 and a[1].isdigit() else 1
    p = game.player
    d = p.look_dir()
    for i in range(n):
        x = p.pos[0] + d[0] * 3 + (i % 3 - 1) * 1.2
        z = p.pos[2] + d[2] * 3 + (i // 3) * 1.2
        game.mobs.spawn(kind, (x, p.pos[1] + 0.5, z))
    return f"summoned {n} {kind}"


def _kill(game, a):
    if a and a[0] == "me":
        game.player.health = 0
        game.player.dead = False
        game.player.hurt_cd = 0
        game.player.hurt(999)
        return ""
    n = 0
    for m in list(game.mobs.mobs.values()):
        game.mobs.damage(m, 999, game.player.pos)
        n += 1
    return f"killed {n} mobs"


def _clear(game, a):
    game.player.items.clear()
    return "inventory cleared"


def _fly(game, a):
    if game.gamemode != "creative":
        return "flying needs creative mode"
    game.player.flying = not game.player.flying
    return "flying " + ("on" if game.player.flying else "off")


def _speed(game, a):
    try:
        game.player.speed_mult = max(0.2, min(float(a[0]), 6.0))
        return f"speed x{game.player.speed_mult:g}"
    except (IndexError, ValueError):
        return "usage: /speed 0.2-6"


def _sound(game, a):
    if not a:
        return "usage: /sound <name>   (soundboard names: " + ", ".join(sorted(n for n in game.audio.names if n.startswith("sb_"))) + ")"
    n = a[0] if a[0] in game.audio.names else "sb_" + a[0]
    if n not in game.audio.names:
        return "no such sound"
    game.play_soundboard(n)
    return ""


def _shader(game, a):
    if not a or a[0] not in render.SHADER_NAMES:
        return "usage: /shader " + "|".join(render.SHADER_NAMES)
    game.set_shader(a[0])
    return f"shader: {a[0]}"


def _rd(game, a):
    try:
        game.set_render_distance(max(2, min(int(a[0]), 16)))
        return f"render distance: {game.render_distance}"
    except (IndexError, ValueError):
        return "usage: /rd 2-16"


def _mods(game, a):
    if not game.mods.mods:
        return "no mods installed (see mods/README.txt)"
    return " | ".join(f"{m.name} {'on' if m.enabled else 'OFF'}" for m in game.mods.mods)


def _blocks(game, a):
    return ", ".join(b.name for b in B.placeable_blocks())


def _list(game, a):
    names = [game.cfg["player_name"]] + [n for _, n in game.net_players()]
    return "players: " + ", ".join(names)


def _pos(game, a):
    p = game.player.pos
    return f"x={p[0]:.1f} y={p[1]:.1f} z={p[2]:.1f}"


def _seed(game, a):
    return f"seed: {game.world.seed}"


def _spawn(game, a):
    game.respawn_player()
    return "back at spawn"


def _heal(game, a):
    game.player.health = 20
    return "healed"


def _say(game, a):
    game.send_chat(" ".join(a))
    return ""


def _save(game, a):
    n = game.save_world()
    return f"saved ({n} edited chunks)"


def _debug(game, a):
    game.toggle_debug()
    return ""


def _help(game, a):
    base = "/" + "  /".join(sorted(COMMANDS))
    extra = sorted(game.mods.commands)
    s = "commands: " + base
    if extra:
        s += "  | mods: /" + "  /".join(extra)
    return s


COMMANDS = {
    "help": _help, "gamemode": _gm, "gm": _gm, "tp": _tp, "time": _time, "give": _give,
    "summon": _summon, "kill": _kill, "clear": _clear, "fly": _fly, "speed": _speed,
    "sound": _sound, "shader": _shader, "rd": _rd, "mods": _mods, "blocks": _blocks,
    "list": _list, "pos": _pos, "seed": _seed, "spawn": _spawn, "heal": _heal, "say": _say,
    "save": _save, "debug": _debug,
}


def run(game, line):
    parts = line.strip().lstrip("/").split()
    if not parts:
        return ""
    name, args = parts[0].lower(), parts[1:]
    fn = COMMANDS.get(name)
    if fn is not None:
        try:
            return fn(game, args) or ""
        except Exception as e:                       # a bad command can't hurt the game
            return f"command failed: {e}"
    r = game.mods.run_command(game, name, args)
    if r is not None:
        return r
    return f"unknown command /{name}. try /help"
