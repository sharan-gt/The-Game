"""
Deterministic, fully vectorised terrain generation: the same (seed, cx, cz)
always yields the same chunk, so unmodified chunks never need saving.

Features: continents + hills + mountains, beaches, desert/snow biomes, 3D
worm caves, clustered ores, trees. A chunk takes a few ms of numpy, no Python
per-block loops (trees are the only small loop).
"""
import numpy as np

from engine import blocks as B
from engine.settings import CHUNK_X, CHUNK_Z, CHUNK_H, SEA_LEVEL


class PerlinNoise2D:
    def __init__(self, seed):
        rng = np.random.default_rng(seed)
        perm = np.arange(256, dtype=np.int32)
        rng.shuffle(perm)
        self.perm = np.concatenate([perm, perm])

    @staticmethod
    def _fade(t):
        return t * t * t * (t * (t * 6 - 15) + 10)

    def _grad(self, h, x, y):
        h = h & 7
        u = np.where(h < 4, x, y)
        v = np.where(h < 4, y, x)
        return np.where((h & 1) == 0, u, -u) + np.where((h & 2) == 0, v, -v)

    def noise(self, x, y):
        xi = np.floor(x).astype(np.int32) & 255
        yi = np.floor(y).astype(np.int32) & 255
        xf = x - np.floor(x)
        yf = y - np.floor(y)
        u, v = self._fade(xf), self._fade(yf)
        p = self.perm
        aa, ab = p[p[xi] + yi], p[p[xi] + yi + 1]
        ba, bb = p[p[xi + 1] + yi], p[p[xi + 1] + yi + 1]
        x1 = self._grad(aa, xf, yf) + u * (self._grad(ba, xf - 1, yf) - self._grad(aa, xf, yf))
        x2 = self._grad(ab, xf, yf - 1) + u * (self._grad(bb, xf - 1, yf - 1) - self._grad(ab, xf, yf - 1))
        return x1 + v * (x2 - x1)

    def fractal(self, x, y, octaves=4, persistence=0.5, scale=1.0):
        total = np.zeros_like(x, dtype=np.float64)
        amp, freq, mx = 1.0, 1.0, 0.0
        for _ in range(octaves):
            total += self.noise(x * freq / scale, y * freq / scale) * amp
            mx += amp
            amp *= persistence
            freq *= 2.0
        return total / mx


def _hash01(i, j, k, seed):
    h = (i.astype(np.int64) * 374761393 + j.astype(np.int64) * 668265263 +
         k.astype(np.int64) * 2147483629 + np.int64(seed) * 1442695041)
    h = (h ^ (h >> 13)) * 1274126177
    h = h ^ (h >> 16)
    return (h & 0xFFFFFF).astype(np.float32) / 16777215.0


def noise3(seed, xs, ys, zs, fx, fy):
    """Smooth 3D value noise in -1..1 over a (len(xs), len(ys), len(zs)) grid.
    Samples a tiny lattice once and interpolates -- much cheaper than hashing
    every voxel."""
    x = xs.astype(np.float32) * fx
    y = ys.astype(np.float32) * fy
    z = zs.astype(np.float32) * fx
    x0, y0, z0 = np.floor(x).astype(np.int64), np.floor(y).astype(np.int64), np.floor(z).astype(np.int64)
    tx, ty, tz = x - x0, y - y0, z - z0
    tx, ty, tz = tx * tx * (3 - 2 * tx), ty * ty * (3 - 2 * ty), tz * tz * (3 - 2 * tz)
    imin, jmin, kmin = x0.min(), y0.min(), z0.min()
    li = np.arange(imin, x0.max() + 2)[:, None, None]
    lj = np.arange(jmin, y0.max() + 2)[None, :, None]
    lk = np.arange(kmin, z0.max() + 2)[None, None, :]
    lat = _hash01(li, lj, lk, seed) * 2 - 1
    a, b, c = (x0 - imin)[:, None, None], (y0 - jmin)[None, :, None], (z0 - kmin)[None, None, :]
    tx, ty, tz = tx[:, None, None], ty[None, :, None], tz[None, None, :]

    def g(da, db, dc):
        return lat[a + da, b + db, c + dc]

    c00 = g(0, 0, 0) * (1 - tx) + g(1, 0, 0) * tx
    c10 = g(0, 1, 0) * (1 - tx) + g(1, 1, 0) * tx
    c01 = g(0, 0, 1) * (1 - tx) + g(1, 0, 1) * tx
    c11 = g(0, 1, 1) * (1 - tx) + g(1, 1, 1) * tx
    c0 = c00 * (1 - ty) + c10 * ty
    c1 = c01 * (1 - ty) + c11 * ty
    return c0 * (1 - tz) + c1 * tz


class TerrainGenerator:
    def __init__(self, seed):
        self.seed = int(seed)
        s = self.seed
        self.n_cont = PerlinNoise2D(s)
        self.n_base = PerlinNoise2D(s + 1)
        self.n_detail = PerlinNoise2D(s + 2)
        self.n_mount = PerlinNoise2D(s + 3)
        self.n_temp = PerlinNoise2D(s + 4)
        self.n_tree = PerlinNoise2D(s + 5)

    # ---- columns ------------------------------------------------------------
    def height(self, gx, gz):
        """gx, gz float arrays of world coords -> float heights."""
        cont = self.n_cont.fractal(gx, gz, 3, 0.5, 260.0)
        base = self.n_base.fractal(gx, gz, 4, 0.5, 80.0)
        det = self.n_detail.fractal(gx, gz, 2, 0.5, 14.0)
        m = self.n_mount.fractal(gx + 1000.0, gz - 500.0, 3, 0.5, 130.0)
        ridge = (1.0 - np.abs(m)) ** 2
        land = np.clip((cont + 0.15) * 2.2, 0.0, 1.0)
        h = SEA_LEVEL + 2 + cont * 9 + base * 12 + det * 2.5 + ridge * land * land * 20
        return np.clip(h, 3, CHUNK_H - 8)

    def temperature(self, gx, gz):
        return self.n_temp.fractal(gx, gz, 2, 0.5, 320.0)

    def height_xz(self, x, z):
        return int(self.height(np.array([float(x)]), np.array([float(z)]))[0])

    def find_spawn(self, cx=0, cz=0, radius=48):
        """Nearest dry, gentle column to the origin (x,z in blocks)."""
        best = (cx * CHUNK_X + 8, cz * CHUNK_Z + 8)
        for r in range(0, radius, 3):
            for dx in range(-r, r + 1, 3):
                for dz in range(-r, r + 1, 3):
                    if max(abs(dx), abs(dz)) != r:
                        continue
                    x, z = best[0] + dx if r else best[0], best[1] + dz if r else best[1]
                    h = self.height_xz(x, z)
                    t = float(self.temperature(np.array([float(x)]), np.array([float(z)]))[0])
                    if h >= SEA_LEVEL + 2 and h < SEA_LEVEL + 14 and t < 0.3:
                        return x, z
        return best

    # ---- chunk ------------------------------------------------------------
    def generate(self, cx, cz):
        X, Z, H = CHUNK_X, CHUNK_Z, CHUNK_H
        wx = (np.arange(X) + cx * X).astype(np.float64)
        wz = (np.arange(Z) + cz * Z).astype(np.float64)
        gx, gz = np.meshgrid(wx, wz, indexing="ij")
        h = self.height(gx, gz).astype(np.int32)                 # (X,Z)
        temp = self.temperature(gx, gz)

        sea_beach = h <= SEA_LEVEL + 1
        snowy = ((h > SEA_LEVEL + 24) | (temp < -0.33)) & ~sea_beach
        desert = (temp > 0.30) & ~sea_beach & ~snowy
        surf = np.full((X, Z), B.GRASS, np.uint8)
        surf[sea_beach | desert] = B.SAND
        surf[snowy] = B.SNOW_GRASS
        sub = np.full((X, Z), B.DIRT, np.uint8)
        sub[sea_beach | desert] = B.SAND
        rocky = (h > SEA_LEVEL + 17) & ~snowy
        surf[rocky] = B.STONE
        sub[rocky] = B.STONE

        y = np.arange(H, dtype=np.int32)[None, :, None]
        hh = h[:, None, :]
        blocks = np.zeros((X, H, Z), np.uint8)
        blocks[np.broadcast_to(y < hh - 3, blocks.shape)] = B.STONE
        sel = np.broadcast_to((y >= hh - 3) & (y < hh), blocks.shape)
        blocks[sel] = np.broadcast_to(sub[:, None, :], blocks.shape)[sel]
        sel = np.broadcast_to(y == hh, blocks.shape)
        blocks[sel] = np.broadcast_to(surf[:, None, :], blocks.shape)[sel]
        sel = np.broadcast_to((y > hh) & (y <= SEA_LEVEL), blocks.shape)
        blocks[sel] = B.WATER

        rng = np.random.default_rng([self.seed & 0xFFFFFFFF, cx & 0xFFFFFFFF, cz & 0xFFFFFFFF])

        # ---- caves: intersection of two noise surfaces = winding tunnels -------
        ymax = int(min(H - 1, h.max() - 3))
        if ymax > 6:
            ys = np.arange(5, ymax)
            n1 = noise3(self.seed + 11, wx, ys, wz, 1 / 15.0, 1 / 11.0)
            n2 = noise3(self.seed + 12, wx, ys, wz, 1 / 15.0, 1 / 11.0)
            cave = (np.abs(n1) < 0.085) & (np.abs(n2) < 0.085)
            region = blocks[:, 5:ymax, :]
            hh_r = h[:, None, :]
            ysr = ys[None, :, None]
            cave &= (ysr < hh_r - 3)
            cave &= (region != B.WATER) & (region != B.BEDROCK)
            region[cave] = B.AIR

        # ---- ores (small clusters) ------------------------------------------------
        r = rng.random((X, H, Z), dtype=np.float32)
        r2 = rng.random((X, H, Z), dtype=np.float32)
        yv = np.arange(H)[None, :, None]
        stone = blocks == B.STONE

        def cluster(mask):
            m = mask.copy()
            m |= np.roll(mask, 1, 1) & (r2 < 0.55)
            m |= np.roll(mask, 1, 0) & (r2 > 0.45)
            m |= np.roll(mask, 1, 2) & (r2 < 0.30)
            return m

        for blk, hi, p in ((B.COAL_ORE, 52, 0.0085), (B.IRON_ORE, 36, 0.0060),
                           (B.GOLD_ORE, 18, 0.0022), (B.DIAMOND_ORE, 11, 0.0014)):
            m = cluster((r < p) & (yv < hi) & (yv > 1)) & stone
            blocks[m] = blk
            stone &= ~m

        # bedrock floor with a rough second layer
        blocks[:, 0, :] = B.BEDROCK
        blocks[:, 1, :][rng.random((X, Z)) < 0.5] = B.BEDROCK

        # gravel patches near the surface
        gm = (noise3(self.seed + 21, wx, np.arange(H), wz, 1 / 9.0, 1 / 7.0) > 0.62)
        gm &= (blocks == B.STONE) & (yv > hh - 6) & (yv < hh)
        blocks[gm] = B.GRAVEL

        # ---- trees -----------------------------------------------------------------
        dens = self.n_tree.fractal(gx, gz, 2, 0.5, 60.0)
        chance = np.clip(0.004 + (dens + 0.2) * 0.02, 0.0, 0.03)
        pick = rng.random((X, Z)) < chance
        pick &= (surf == B.GRASS) & (h > SEA_LEVEL + 1)
        pick[:2, :] = pick[-2:, :] = False
        pick[:, :2] = pick[:, -2:] = False
        trunk_rnd = rng.integers(4, 7, (X, Z))
        for lx, lz in zip(*np.nonzero(pick)):
            self._tree(blocks, int(lx), int(h[lx, lz]) + 1, int(lz), int(trunk_rnd[lx, lz]))
        return blocks

    @staticmethod
    def _tree(blocks, x, y, z, th):
        H = blocks.shape[1]
        if y + th + 3 >= H:
            return
        blocks[x, y:y + th, z] = B.LOG
        top = y + th
        for dy in range(-2, 2):
            rad = 2 if dy < 0 else 1
            for dx in range(-rad, rad + 1):
                for dz in range(-rad, rad + 1):
                    if abs(dx) == rad and abs(dz) == rad and (dy >= 0 or rad == 1):
                        continue
                    xx, yy, zz = x + dx, top + dy, z + dz
                    if 0 <= xx < blocks.shape[0] and 0 <= zz < blocks.shape[2] \
                            and blocks[xx, yy, zz] == B.AIR:
                        blocks[xx, yy, zz] = B.LEAVES
        if blocks[x, top + 2, z] == B.AIR:
            blocks[x, top + 2, z] = B.LEAVES
