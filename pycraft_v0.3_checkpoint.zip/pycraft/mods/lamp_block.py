MOD_NAME = "Lamps & Gems"
MOD_VERSION = "1.0"
MOD_AUTHOR = "PyCraft"
MOD_DESC = "Adds a glowing lamp, a ruby block, an emerald block and tinted glass."


def register(api):
    api.add_block("lamp", color=(1.0, 0.86, 0.45), glow=True, hardness=0.3,
                  material="glass", hotbar=True)
    api.add_block("ruby_block", color=(0.78, 0.10, 0.18), hardness=2.0, hotbar=True)
    api.add_block("emerald_block", color=(0.10, 0.70, 0.35), hardness=2.0, hotbar=True)
    api.add_block("blue_glass", color=(0.35, 0.6, 1.0), transparent=True, hardness=0.3,
                  material="glass")
