"""
The Game object: boot sequence, state machine (boot -> title -> loading -> playing),
world lifecycle, interaction, day/night, networking glue, performance guard and the
crash guard that keeps a stray exception from ever closing the window.
"""
import gc
import json
import math
import os
import random
import time as pytime
import traceback
from pathlib import Path

import numpy as np
from panda3d.core import Filename, NodePath, TransparencyAttrib
from ursina import Entity, application, camera, held_keys, mouse, scene, window
from ursina import time as utime
from ursina.color import Color

from engine import atlas as A
from engine import audio as AUD
from engine import blocks as B
from engine import commands, mobs as M, mods as MODS, raycast, render, settings
from engine import world as W
from engine.settings import CACHE_DIR, CHUNK_H, MOD_DIR, PACK_DIR, ROOT, SAVE_DIR, SEA_LEVEL
from game import fx, hud as HUD, screens, ui as U
from game.player import Inputs, Player
from net import discovery
from net import protocol as NP
from net.client import GameClient
from net.server import GameServer

GAME = None
DAY_SECONDS = 720.0
PANORAMA_SEED = 20240607
SKY_DAY = np.array([0.55, 0.74, 0.96])
SKY_NIGHT = np.array([0.025, 0.035, 0.095])
SKY_SUNSET = np.array([0.98, 0.52, 0.30])
DROPS = {B.GRASS: "dirt", B.STONE: "cobblestone", B.LEAVES: None, B.GLASS: None, B.SNOW_GRASS: "dirt"}


def _smooth(a, b, x):
    t = max(0.0, min(1.0, (x - a) / (b - a)))
    return t * t * (3 - 2 * t)


class Game:
    def __init__(self, app, safe=False):
        global GAME
        GAME = self
        self.app = app
        self.safe = safe
        self.cfg = settings.Config()
        self.ui = U.UI(self)
        self.clock = 0.0
        self.state = "boot"
        self.chat_open = False
        self.chat_history = []
        self.hist_i = 0
        self.mod_dir = str(MOD_DIR)
        self.mods = MODS.ModManager(self.cfg["mods_disabled"])
        self.audio = None
        self.atlas = None
        self.renderer = None
        self.world = None
        self.mobs = None
        self.hud = None
        self.sky = None
        self.particles = None
        self.player = Player(self)
        self.gamemode = self.cfg["gamemode"]
        self.time_of_day = 0.08
        self.spawn = (0.5, 40.0, 0.5)
        self.dmg_flash = 0.0
        self.server = None
        self.announcer = None
        self.client = None
        self.listener = None
        self.remotes = {}
        self.peer_pos = {}
        self.is_client = False
        self.paused = False
        self.world_dir_name = None
        self.render_distance = int(self.cfg["render_distance"])
        self.dt_avg = 1 / 60
        self.slow_t = 0.0
        self.fps = 60.0
        self.autosave_t = 0.0
        self.err_times = []
        self.net_t = 0.0
        self.net_slow_t = 0.0
        self.pos_t = 0.0
        self.time_sync_t = 0.0
        self.attack_cd = 0.0
        self.break_cd = 0.0
        self.place_cd = 0.0
        self.mine = None
        self.mine_snd = 0.0
        self.lmb_edge = False
        self.rmb_edge = False
        self.target = None
        self.loading_screen = None
        self.pending_welcome = None
        self.outline = None
        self.crack = None
        self.unstick = False
        self.fresh_spawn = True
        self.boot_gen = self._boot()
        self.panorama_t = 0.0
        self.title_active = False
        app.accept('keystroke', self.ui.keystroke)
        gc.set_threshold(20000, 50, 50)

    # =================================================================== boot ====
    def _boot(self):
        scr = screens.loading(self, "Starting PyCraft", "")

        def step(text, frac, sub=""):
            scr.text.text = text
            scr.sub.text = sub
            scr.bar.set(frac)
        step("Reading settings", 0.04)
        yield
        step("Loading mods", 0.10, str(MOD_DIR))
        yield
        self.mods.load_all()
        n = sum(1 for m in self.mods.mods if m.enabled)
        step("Loading mods", 0.16, f"{n} mod(s) active")
        yield
        step("Preparing sounds", 0.20, "first start only - synthesising effects, mob voices and music")
        yield
        self.audio = AUD.AudioSystem(self.app.loader, self.cfg)
        self.audio.load(lambda label: None)
        step("Preparing sounds", 0.45, f"{len(self.audio.names)} sounds ready")
        yield
        step("Building textures", 0.50, f"resource pack: {self.cfg['resource_pack']}")
        yield
        self._build_atlas()
        step("Building textures", 0.68, f"{self.atlas.pack_name}  ({self.atlas.tile}px)")
        yield
        step("Setting up the renderer", 0.74)
        yield
        self.renderer = render.Renderer(scene, (window.size[0], window.size[1]))
        self.renderer.set_atlas(self.atlas.image)
        shader = "off" if self.safe else self.cfg["shader"]
        step("Compiling shaders", 0.82, f"shader pack: {shader}")
        yield
        self.renderer.set_shader(shader)
        if not self.renderer.gl_ok:
            self.cfg["shader"] = "off"
        step("Building mob models", 0.90)
        yield
        step("Almost there", 0.97)
        yield
        self.particles = None
        gc.collect()
        step("Ready", 1.0)
        yield
        self.show_title()

    def _build_atlas(self):
        self.atlas = A.build(self.cfg["resource_pack"], B.tile_names(), B.extra_tiles)
        B.tables.build(self.atlas.index)

    # ============================================================== utilities ====
    def say(self, text, col=None):
        if self.hud is not None:
            self.hud.say(text, col)
        else:
            print("[chat]", text)

    def set_cursor(self, free):
        mouse.locked = not free
        mouse.visible = free

    def quit(self):
        try:
            self.save_world()
        except Exception:
            pass
        application.quit()

    def toggle_debug(self):
        self.set_debug(not self.cfg["show_debug"])

    def set_debug(self, on):
        self.cfg["show_debug"] = bool(on)
        self.cfg.save()
        if self.hud:
            self.hud.set_debug(bool(on))

    def set_fullscreen(self, v):
        try:
            window.fullscreen = bool(v)
        except Exception as e:
            print("[window] fullscreen failed:", e)

    def set_mobs(self, v):
        self.cfg["mobs"] = bool(v)
        self.cfg.save()
        if self.mobs:
            self.mobs.enabled = bool(v)
            if not v:
                self.mobs.clear()

    def set_render_distance(self, r):
        r = max(2, min(int(r), 16))
        self.render_distance = r
        self.cfg["render_distance"] = r
        if self.world is not None:
            self.world.set_render_distance(r)

    def set_shader(self, name):
        self.cfg["shader"] = name
        self.cfg.save()
        if self.renderer:
            self.renderer.set_shader(name)
            if not self.renderer.gl_ok and name != "off":
                self.cfg["shader"] = "off"
                if self.hud:
                    self.hud.toast("Shader failed on this GPU - using the safe renderer", U.WARN)

    def set_resource_pack(self, pid):
        self.cfg["resource_pack"] = pid
        self.cfg.save()
        self._build_atlas()
        self.renderer.set_atlas(self.atlas.image)
        if self.world is not None:
            self.world.uvt = self.atlas.uv
            self.world.invalidate_all()
        if self.hud:
            self.hud.icons.clear()
            self.hud.hand_name = None
            self.hud.refresh_hotbar()

    def set_gamemode(self, mode):
        self.gamemode = mode
        if mode == "survival":
            self.player.flying = False
            for n in self.player.hotbar:
                if n and self.player.count(n) == 0 and False:
                    pass
        if self.hud:
            self.hud.set_survival_ui(mode == "survival")
            self.hud.refresh_hotbar()

    def set_time(self, t):
        self.time_of_day = t % 1.0

    # ================================================================ title =====
    def show_title(self):
        self.state = "title"
        self.title_active = True
        self._clear_world()
        self._start_world_object(PANORAMA_SEED, "_title", rd=min(4, self.render_distance))
        self.panorama_t = 0.0
        self.player.pos[:] = [0.5, 40, 0.5]
        sx, sz = self.world.gen.find_spawn()
        self.pano_center = (sx + 0.5, sz + 0.5)
        self.pano_y = max(self.world.gen.height_xz(sx, sz), SEA_LEVEL) + 14
        self.time_of_day = 0.1
        screens.title_screen(self)
        self.audio.music_now()

    def _clear_world(self):
        if self.hud:
            self.hud.destroy()
            self.hud = None
        if self.mobs:
            self.mobs.clear()
            self.mobs = None
        if self.particles:
            self.particles.destroy()
            self.particles = None
        if self.sky:
            self.sky.destroy()
            self.sky = None
        for r in self.remotes.values():
            r.destroy()
        self.remotes.clear()
        for n in (self.outline, self.crack):
            if n is not None:
                n.remove_node()
        self.outline = self.crack = None
        if self.world:
            self.world.destroy()
            self.world = None
        self.shutdown_net()

    def _start_world_object(self, seed, name, rd=None):
        self.world = W.World(seed, self.renderer, B.tables, self.atlas.uv, name=name,
                             render_distance=rd or self.render_distance)
        self.sky = fx.Sky(self.renderer, scene)
        self.outline = render.make_outline()
        self.outline.reparent_to(self.renderer.fx_root)
        self.outline.hide()
        box = render.box_mesh((1.007, 1.007, 1.007), (0, 0, 0), (0, -0.0035, 0))
        self.crack = NodePath(render.build_geom_node(box, "crack"))
        self.crack.reparent_to(self.renderer.fx_root)
        self.crack.set_transparency(TransparencyAttrib.M_alpha)
        self.crack.set_shader_off(10)
        self.crack.set_light_off()
        self.crack.set_fog_off()
        self.crack.set_depth_write(False)
        self.crack.hide()
        self.particles = fx.Particles(self.renderer)

    # ======================================================= starting a world ====
    def start_new_world(self, name, seed, mode):
        name = W.unique_world_name(name)
        self.world_dir_name = name
        self.is_client = False
        self.gamemode = mode
        self.cfg["gamemode"] = mode
        self.cfg.save()
        self._enter_world(seed, name, meta=None)

    def load_world(self, dirname, host=False):
        try:
            meta = json.loads((SAVE_DIR / dirname / "world.json").read_text())
        except Exception as e:
            screens.message(self, "Can't open world", str(e)[:80], lambda: screens.world_select(self), U.BAD)
            return
        self.world_dir_name = dirname
        self.is_client = False
        self.gamemode = meta.get("gamemode", "creative")
        self._enter_world(int(meta["seed"]), dirname, meta=meta, host=host)

    def _enter_world(self, seed, name, meta, host=False, remote=None):
        self._clear_world()
        self.title_active = False
        self.state = "loading"
        self.loading_screen = screens.loading(self, "Loading world", "")
        self._start_world_object(seed, name)
        w = self.world
        if remote is None:
            w.load_edits()
        self.hud = HUD.Hud(self)
        self.hud.set_survival_ui(self.gamemode == "survival")
        self.hud.set_debug(self.cfg["show_debug"])
        hooks = dict(player_pos=lambda: tuple(self.player.pos),
                     is_night=self.is_night, hurt_player=self._mob_hurt_player,
                     drop=self._mob_drop, gamemode=lambda: self.gamemode,
                     listener=lambda: (self.player.eye_pos(), self.player.yaw))
        self.mobs = M.MobManager(w, self.renderer, self.audio, hooks)
        self.mobs.enabled = bool(self.cfg["mobs"])
        self.mobs.net_proxy = remote is not None
        self.is_client = remote is not None
        p = self.player
        p.dead = False
        p.health = 20.0
        p.vel = [0.0, 0.0, 0.0]
        p.flying = False
        p.fall_start = None
        p.hotbar = [n for n in ["grass", "dirt", "stone", "cobblestone", "log", "planks", "glass", "sand", "leaves"]]
        p.items = {}
        if self.gamemode == "survival":
            p.hotbar = [None] * 9
        p.selected = 0
        if meta and "player" in meta:
            pm = meta["player"]
            self.spawn = tuple(meta.get("spawn", (0.5, 40, 0.5)))
            p.pos[:] = pm["pos"]
            p.yaw, p.pitch = pm.get("yaw", 0), pm.get("pitch", 0)
            p.health = pm.get("health", 20)
            p.hotbar = pm.get("hotbar", p.hotbar)
            p.items = pm.get("items", {})
            self.time_of_day = meta.get("tod", 0.1)
            for n in list(p.hotbar):
                if n is not None and B.by_name(n) is None and n != "meat":
                    p.hotbar[p.hotbar.index(n)] = None
        else:
            if remote is not None:
                sp = remote["spawn"]
                self.spawn = (sp[0], sp[1], sp[2])
                self.time_of_day = remote.get("tod", 0.1)
            else:
                sx, sz = w.gen.find_spawn()
                h = max(w.gen.height_xz(sx, sz), SEA_LEVEL)
                self.spawn = (sx + 0.5, h + 2.0, sz + 0.5)
                self.time_of_day = 0.08
            p.pos[:] = self.spawn
            p.yaw = p.pitch = 0.0
        self.unstick = True
        self.fresh_spawn = not (meta and "player" in meta)
        self._host_after = host
        self.hud.refresh_hotbar()
        self.set_cursor(True)
        self.load_started = pytime.time()
        self.loaded_once = False

    def _loading_tick(self):
        w, p = self.world, self.player
        w.update(p.pos[0], p.pos[2], budget_ms=14.0)
        pcx, pcz = int(p.pos[0]) >> 4, int(p.pos[2]) >> 4
        R = 2
        need = (2 * R + 1) ** 2
        done = 0
        for dx in range(-R, R + 1):
            for dz in range(-R, R + 1):
                c = w.chunks.get((pcx + dx, pcz + dz))
                if c is not None and c.meshed == c.version and c.version > 0:
                    done += 1
        scr = self.loading_screen
        if scr is not None:
            scr.bar.set(done / need)
            scr.sub.text = f"Generating terrain  {done}/{need} chunks"
        if done >= need or pytime.time() - self.load_started > 25:
            self._finish_loading()

    def _finish_loading(self):
        w, p = self.world, self.player
        # drop the player onto the real surface (saves may have edited terrain)
        if self.unstick:
            from engine import physics
            x, z = int(math.floor(p.pos[0])), int(math.floor(p.pos[2]))
            if self.fresh_spawn:
                found = self._find_safe_spawn(x, z)
                if found:
                    self.spawn = (found[0] + 0.5, found[1] + 1.05, found[2] + 0.5)
                    p.pos[:] = list(self.spawn)
                else:
                    top = w.column_top(x, z)
                    p.pos[1] = max(top, SEA_LEVEL) + 1.05 if top >= 0 else p.pos[1]
            n = 0
            while not physics.free_spot(w, p.pos) and n < CHUNK_H:
                p.pos[1] += 1.0
                n += 1
            self.unstick = False
        self.ui.clear()
        self.loading_screen = None
        self.state = "playing"
        self.paused = False
        self.set_cursor(False)
        self.hud.show(True)
        self.say("Welcome to PyCraft!  T = chat, E = blocks, B = soundboard, F3 = debug", U.ACCENT)
        if self.gamemode == "creative":
            self.say("Creative: double-tap SPACE to fly.", U.DIM)
        else:
            self.say("Survival: hold left click to mine. Shamblers roam at night.", U.DIM)
        self.mods.fire("start", self)
        if getattr(self, "_host_after", False):
            self.host_current()
        self.last_save = pytime.time()
        gc.collect()
        try:
            gc.freeze()
        except Exception:
            pass

    def _find_safe_spawn(self, x0, z0):
        """Nearest ground with open air around it (never inside a tree or a cliff)."""
        w = self.world
        for r in range(0, 30, 2):
            for dx in range(-r, r + 1, 2):
                for dz in range(-r, r + 1, 2):
                    if max(abs(dx), abs(dz)) != r:
                        continue
                    x, z = x0 + dx, z0 + dz
                    top = w.column_top(x, z)
                    if top < SEA_LEVEL or top > CHUNK_H - 8:
                        continue
                    if w.get_block(x, top, z) not in (B.GRASS, B.SAND, B.SNOW_GRASS, B.DIRT, B.STONE):
                        continue
                    ok = True
                    for ax in range(-2, 3):
                        for az in range(-2, 3):
                            for ay in range(1, 4):
                                if w.get_block(x + ax, top + ay, z + az) not in (0, -1):
                                    ok = False
                                    break
                            if not ok:
                                break
                        if not ok:
                            break
                    if ok:
                        return x, top, z
        return None

    # =============================================================== saving ======
    def save_world(self):
        if self.world is None or self.is_client or self.world.name.startswith("_"):
            return 0
        p = self.player
        meta = {"gamemode": self.gamemode, "tod": self.time_of_day, "spawn": list(self.spawn),
                "player": {"pos": [round(v, 3) for v in p.pos], "yaw": p.yaw, "pitch": p.pitch,
                           "health": p.health, "hotbar": p.hotbar, "items": p.items}}
        return self.world.save(meta)

    def quit_to_title(self):
        try:
            self.save_world()
        except Exception as e:
            print("[save] failed:", e)
        self.ui.clear()
        self.show_title()

    # ============================================================ networking =====
    def net_players(self):
        return [(pid, r.name) for pid, r in self.remotes.items()]

    def find_player(self, name):
        for pid, r in self.remotes.items():
            if r.name.lower() == name.lower() and r.pos is not None:
                return tuple(r.pos)
        return None

    def net_listener(self):
        if self.listener is None:
            self.listener = discovery.Listener()
        return self.listener

    def close_listener(self):
        if self.listener is not None:
            self.listener.close()
            self.listener = None

    def host_current(self):
        if self.server is not None or self.is_client or self.world is None:
            return
        try:
            self.server = GameServer(NP.PORT)
        except OSError as e:
            self.say(f"Can't open LAN port {NP.PORT}: {e.strerror or e}", U.BAD)
            self.server = None
            return
        self.announcer = discovery.Announcer(self.world.name, NP.PORT, lambda: len(self.remotes) + 1)
        ips = discovery.local_ips()
        self.say(f"LAN open!  Friends join with  {ips[0]}:{NP.PORT}", U.ACCENT)

    def shutdown_net(self):
        if self.announcer:
            self.announcer.close()
            self.announcer = None
        if self.server:
            self.server.close()
            self.server = None
        if self.client:
            self.client.close()
            self.client = None
        self.close_listener()

    def join(self, host, port, name):
        self.shutdown_net()
        self.client = GameClient(host, port, name)
        self.state = "connecting"
        screens.connecting(self, f"Connecting to {host}:{port}...")

    def cancel_join(self):
        if self.client:
            self.client.close()
            self.client = None
        self.state = "title"
        screens.multiplayer(self)

    def _client_connecting_tick(self):
        c = self.client
        if c is None:
            return
        if c.state == "failed":
            err = c.error
            self.client = None
            self.state = "title"
            screens.message(self, "Couldn't connect", err[:70], lambda: screens.multiplayer(self), U.BAD)
            return
        for m in c.poll():
            t = m.get("t")
            if t == "welcome":
                self.client_welcome(m)
                return
            if t in ("kick", "_closed"):
                self.client = None
                self.state = "title"
                screens.message(self, "Disconnected", m.get("reason", c.error or "connection closed")[:70],
                                lambda: screens.multiplayer(self), U.BAD)
                return

    def client_welcome(self, m):
        c = self.client
        c.pid = m["pid"]
        self.gamemode = m.get("mode", "creative")
        self.world_dir_name = None
        self._enter_world(int(m["seed"]), "_net", meta=None, remote=m)
        for cx, cz, blob in m.get("chunks", []):
            try:
                self.world.saved[(cx, cz)] = NP.unpack_chunk(blob, (16, CHUNK_H, 16))
            except Exception:
                pass
        for pid, name in m.get("players", []):
            if pid != c.pid:
                self._remote(pid, name)
        self.say(f"Joined {m.get('world', 'world')}.", U.ACCENT)

    def _remote(self, pid, name):
        r = self.remotes.get(pid)
        if r is None:
            r = fx.RemotePlayer(self.renderer, pid, name)
            self.remotes[pid] = r
        return r

    # ---- host side
    def _server_update(self, dt):
        s = self.server
        for ev in s.poll():
            kind, pid, data = ev
            if kind == "join":
                chunks = []
                for key, arr in list(self.world.saved.items()):
                    chunks.append([key[0], key[1], NP.pack_chunk(arr)])
                for key, c in self.world.chunks.items():
                    if c.modified:
                        chunks.append([key[0], key[1], NP.pack_chunk(c.blocks)])
                players = [[0, self.cfg["player_name"]]] + [[i, r.name] for i, r in self.remotes.items()]
                s.send(pid, {"t": "welcome", "pid": pid, "seed": self.world.seed, "world": self.world.name,
                             "spawn": list(self.spawn), "tod": self.time_of_day, "mode": self.gamemode,
                             "chunks": chunks[:400], "players": players})
                self._remote(pid, data)
                s.broadcast({"t": "join", "pid": pid, "name": data}, exclude=pid)
                self.say(f"{data} joined the game", U.ACCENT)
                self.audio.play("levelup", 0.5)
            elif kind == "leave":
                r = self.remotes.pop(pid, None)
                self.peer_pos.pop(pid, None)
                if r:
                    r.destroy()
                s.broadcast({"t": "leave", "pid": pid, "name": data})
                self.say(f"{data} left the game", U.DIM)
            elif kind == "msg":
                self._server_msg(pid, data)
        self.net_t += dt
        if self.net_t >= 0.1:
            self.net_t = 0.0
            plist = [[0, self.cfg["player_name"]] + [round(v, 2) for v in self.player.pos] + [round(self.player.yaw, 1)]]
            for pid, r in self.remotes.items():
                pp = self.peer_pos.get(pid)
                if pp:
                    plist.append([pid, r.name] + [round(v, 2) for v in pp])
            s.broadcast({"t": "players", "p": plist})
            if self.mobs.enabled:
                s.broadcast({"t": "mobs", "m": self.mobs.snapshot()})
        self.time_sync_t += dt
        if self.time_sync_t >= 2.0:
            self.time_sync_t = 0.0
            s.broadcast({"t": "time", "v": self.time_of_day})

    def _server_msg(self, pid, m):
        t = m.get("t")
        s = self.server
        if t == "pos":
            self.peer_pos[pid] = (m["x"], m["y"], m["z"], m.get("yaw", 0))
        elif t == "block":
            x, y, z, bid = int(m["x"]), int(m["y"]), int(m["z"]), int(m["id"])
            self.world.set_block(x, y, z, bid)
            s.broadcast({"t": "block", "x": x, "y": y, "z": z, "id": bid}, exclude=pid)
            self._edit_fx(x, y, z, bid)
        elif t == "chat":
            name = self.remotes[pid].name if pid in self.remotes else f"P{pid}"
            text = str(m.get("text", ""))[:100]
            s.broadcast({"t": "chat", "name": name, "text": text})
            self.say(f"<{name}> {text}")
        elif t == "sound":
            n = m.get("name", "")
            if n in self.audio.names and n.startswith("sb_"):
                s.broadcast({"t": "sound", "name": n}, exclude=pid)
                self.audio.play(n, 0.9)
        elif t == "hit_mob":
            mob = self.mobs.mobs.get(m.get("id"))
            pp = self.peer_pos.get(pid)
            if mob is not None and pp:
                self.mobs.damage(mob, min(float(m.get("dmg", 2)), 20), pp)

    # ---- client side
    def _client_update(self, dt):
        c = self.client
        for m in c.poll():
            t = m.get("t")
            if t == "players":
                seen = set()
                for pid, name, x, y, z, yaw in m["p"]:
                    if pid == c.pid:
                        continue
                    seen.add(pid)
                    self._remote(pid, name).set_target(x, y, z, yaw)
                for pid in [i for i in self.remotes if i not in seen]:
                    self.remotes.pop(pid).destroy()
            elif t == "block":
                self.world.set_block(int(m["x"]), int(m["y"]), int(m["z"]), int(m["id"]))
                self._edit_fx(int(m["x"]), int(m["y"]), int(m["z"]), int(m["id"]))
            elif t == "mobs":
                self.mobs.apply_snapshot(m["m"])
            elif t == "chat":
                self.say(f"<{m.get('name', '?')}> {m.get('text', '')}")
            elif t == "join":
                self.say(f"{m.get('name')} joined the game", U.ACCENT)
            elif t == "leave":
                self.say(f"{m.get('name')} left the game", U.DIM)
            elif t == "sound":
                if m.get("name") in self.audio.names:
                    self.audio.play(m["name"], 0.9)
            elif t == "time":
                self.time_of_day = float(m["v"])
            elif t in ("kick", "_closed"):
                reason = m.get("reason") or c.error or "connection closed"
                self.client = None
                self._clear_world()
                self.show_title()
                screens.message(self, "Disconnected", reason[:70], lambda: screens.title_screen(self), U.BAD)
                return
        self.pos_t += dt
        if self.pos_t >= 0.066:
            self.pos_t = 0.0
            p = self.player
            c.send({"t": "pos", "x": round(p.pos[0], 2), "y": round(p.pos[1], 2), "z": round(p.pos[2], 2),
                    "yaw": round(p.yaw, 1)})

    def _net_block(self, x, y, z, bid):
        if self.server is not None:
            self.server.broadcast({"t": "block", "x": x, "y": y, "z": z, "id": bid})
        elif self.client is not None:
            self.client.send({"t": "block", "x": x, "y": y, "z": z, "id": bid})

    def send_chat(self, text):
        text = text.strip()
        if not text:
            return
        self.say(f"<{self.cfg['player_name']}> {text}")
        if self.server is not None:
            self.server.broadcast({"t": "chat", "name": self.cfg["player_name"], "text": text[:100]})
        elif self.client is not None:
            self.client.send({"t": "chat", "text": text[:100]})
        self.mods.fire("chat", self, text)

    def play_soundboard(self, name):
        self.audio.play(name, 1.0)
        if self.server is not None:
            self.server.broadcast({"t": "sound", "name": name})
        elif self.client is not None:
            self.client.send({"t": "sound", "name": name})

    def play_soundboard_file(self, path):
        self.audio.play_file(path, 1.0)

    # =============================================================== input =======
    def on_key(self, key):
        if self.ui.key(key):
            return
        scr = self.ui.screen
        if scr is not None and scr.on_key:
            scr.on_key(key)
        st = self.state
        if st == "playing":
            self._playing_key(key)
        elif st == "paused":
            if key == "escape" or (key == "e" and scr and scr.name == "inventory"):
                self.resume()
        if key == "f11":
            self.set_fullscreen(not window.fullscreen)

    def _playing_key(self, key):
        p = self.player
        if self.chat_open:
            if key == "escape":
                self.hud.close_chat()
                self.set_cursor(False)
            elif key == "up arrow" and self.chat_history:
                self.hist_i = max(0, self.hist_i - 1)
                self.hud.chat_field.text = self.chat_history[self.hist_i]
            elif key == "down arrow" and self.chat_history:
                self.hist_i = min(len(self.chat_history), self.hist_i + 1)
                self.hud.chat_field.text = self.chat_history[self.hist_i] if self.hist_i < len(self.chat_history) else ""
            return
        if key == "escape":
            self.open_pause()
        elif key == "e":
            self.open_overlay(lambda: screens.inventory(self))
        elif key in ("t", "enter"):
            self.open_chat("")
        elif key in ("/", "slash"):
            self.open_chat("/")
        elif key == "b":
            self.open_overlay(lambda: screens.soundboard(self, self.resume))
        elif key == "f3":
            self.toggle_debug()
        elif key == "f2":
            self.screenshot()
        elif key == "f" and self.gamemode == "creative":
            p.flying = not p.flying
            p.vel[1] = 0
        elif key in "123456789" and len(key) == 1:
            p.selected = int(key) - 1
            self.hud.refresh_hotbar()
            self.audio.play("tick", 0.4)
        elif key == "scroll up":
            p.selected = (p.selected - 1) % 9
            self.hud.refresh_hotbar()
            self.audio.play("tick", 0.3)
        elif key == "scroll down":
            p.selected = (p.selected + 1) % 9
            self.hud.refresh_hotbar()
            self.audio.play("tick", 0.3)
        elif key == "left mouse down":
            self.lmb_edge = True
        elif key == "right mouse down":
            self.rmb_edge = True
        elif key == "middle mouse down":
            self.pick_block()
        else:
            self.mods.key(self, key)

    def open_chat(self, prefill):
        self.hud.open_chat(prefill)
        self.hud.chat_field.on_enter = self.submit_chat
        self.hist_i = len(self.chat_history)
        self.set_cursor(False)       # keep the mouse captured; typing goes through keystroke events

    def submit_chat(self, text):
        self.hud.close_chat()
        text = text.strip()
        if text:
            self.chat_history.append(text)
            self.chat_history = self.chat_history[-30:]
            if text.startswith("/"):
                r = commands.run(self, text)
                if r:
                    self.say(r, U.WARN)
            else:
                self.send_chat(text)

    def open_pause(self):
        self.state = "paused"
        self.set_cursor(True)
        if self.hud:
            self.hud.show(False)
        screens.pause(self)

    def open_overlay(self, builder):
        self.state = "paused"
        self.set_cursor(True)
        if self.hud:
            self.hud.show(False)
        builder()

    def resume(self):
        if self.state in ("paused",):
            self.ui.clear()
            self.state = "playing"
            self.set_cursor(False)
            if self.hud:
                self.hud.show(True)

    def screenshot(self):
        d = ROOT / "screenshots"
        d.mkdir(exist_ok=True)
        p = d / f"pycraft_{pytime.strftime('%Y%m%d_%H%M%S')}.png"
        try:
            self.app.win.save_screenshot(Filename.from_os_specific(str(p)))
            self.say(f"Saved screenshot: {p.name}", U.ACCENT)
        except Exception as e:
            self.say(f"Screenshot failed: {e}", U.BAD)

    # ================================================================ per frame ===
    def tick(self, dt):
        try:
            self._tick(dt)
        except Exception:
            tb = traceback.format_exc()
            print(tb)
            try:
                with open(ROOT / "crash.log", "a") as f:
                    f.write(f"--- {pytime.ctime()} state={self.state}\n{tb}\n")
            except Exception:
                pass
            now = pytime.time()
            self.err_times = [t for t in self.err_times if now - t < 4.0] + [now]
            if self.hud and len(self.err_times) <= 2:
                self.hud.toast("A recoverable error happened (details in crash.log)", U.BAD)
            if len(self.err_times) > 8:
                self.err_times = []
                try:
                    self.save_world()
                    self.ui.clear()
                    self.show_title()
                    screens.message(self, "Recovered from an error",
                                    "The game kept failing, so it saved and returned to the menu.\nSee crash.log",
                                    lambda: screens.title_screen(self), U.WARN)
                except Exception:
                    pass

    def _tick(self, dt):
        dt = min(dt, 0.1)
        self.clock += dt
        self.dt_avg += (dt - self.dt_avg) * 0.04
        self.fps = 1.0 / max(self.dt_avg, 1e-4)
        if self.audio:
            self.audio.update(dt)
        st = self.state
        if st == "boot":
            try:
                next(self.boot_gen)
            except StopIteration:
                pass
            return
        if st == "connecting":
            self._client_connecting_tick()
            return
        if self.ui.screen is not None and self.ui.screen.on_update:
            self.ui.screen.on_update()
        if st == "title":
            self._title_tick(dt)
            return
        if st == "loading":
            self._loading_tick()
            self._place_camera_orbit(dt, loading=True)
            return
        if st in ("playing", "paused", "dead"):
            self._game_tick(dt, active=(st == "playing"))

    # ---- title panorama
    def _title_tick(self, dt):
        self.panorama_t += dt
        self._place_camera_orbit(dt)
        self.time_of_day = (self.time_of_day + dt / (DAY_SECONDS * 2)) % 1.0
        if self.world:
            self.world.update(self.pano_center[0], self.pano_center[1], budget_ms=4.0)
        self._update_env(dt)

    def _place_camera_orbit(self, dt, loading=False):
        if loading:
            return
        a = math.radians(self.panorama_t * 3.5)
        cx, cz = self.pano_center
        camera.position = (cx + math.sin(a) * 6, self.pano_y, cz + math.cos(a) * 6)
        camera.rotation = (14, math.degrees(a) + 180 + 25 * math.sin(self.panorama_t * 0.1), 0)
        camera.fov = 78

    # ---- the real game loop
    def _game_tick(self, dt, active):
        p = self.player
        w = self.world
        host_running = self.server is not None and len(self.remotes) > 0
        simulate = active or self.client is not None or host_running
        # input -> player
        if active and not self.chat_open and not self.ui.screen:
            self._mouse_look()
        if simulate:
            inp = Inputs()
            if active and not self.chat_open:
                inp.forward = (held_keys['w'] or held_keys['up arrow']) - (held_keys['s'] or held_keys['down arrow'])
                inp.strafe = held_keys['d'] - held_keys['a']
                inp.jump = bool(held_keys['space'])
                inp.sneak = bool(held_keys['shift'])
                inp.sprint = bool(held_keys['control'])
                inp.fly_up = bool(held_keys['space'])
                inp.fly_down = bool(held_keys['shift'])
            p.update(dt, inp)
            self.mods.fire("tick", self, dt)
        if active:
            self.interact(dt)
        # world streaming (budgeted)
        budget = 4.0 if self.dt_avg < 1 / 50 else (2.5 if self.dt_avg < 1 / 30 else 1.5)
        w.update(p.pos[0], p.pos[2], budget_ms=budget)
        if simulate and self.mobs:
            self.mobs.update(dt)
        if self.particles:
            self.particles.update(dt)
        if simulate:
            self.time_of_day = (self.time_of_day + dt / DAY_SECONDS) % 1.0
        # networking
        if self.server is not None:
            self._server_update(dt)
        elif self.client is not None:
            self._client_update(dt)
        for r in self.remotes.values():
            r.update(dt)
        if self.server is not None:
            for pid, r in self.remotes.items():
                pp = self.peer_pos.get(pid)
                if pp:
                    r.set_target(*pp)
        # camera + env + hud
        self._camera(dt)
        self._update_env(dt)
        self.dmg_flash = max(0.0, self.dmg_flash - dt * 1.6)
        if self.hud:
            self.hud.update(dt)
        # perf guard + autosave
        self._performance_guard(dt)
        if simulate and not self.is_client:
            self.autosave_t += dt
            if self.autosave_t > 90:
                self.autosave_t = 0
                try:
                    self.save_world()
                except Exception as e:
                    print("[autosave] failed:", e)

    def _mouse_look(self):
        if not mouse.locked:
            return
        sens = float(self.cfg["mouse_sensitivity"])
        vx = max(-0.25, min(0.25, mouse.velocity[0]))
        vy = max(-0.25, min(0.25, mouse.velocity[1]))
        p = self.player
        p.yaw += vx * sens
        p.pitch = max(-89.0, min(89.0, p.pitch - vy * sens))

    def _camera(self, dt):
        p = self.player
        e = p.eye_pos()
        camera.position = (e[0], e[1], e[2])
        camera.rotation = (p.pitch, p.yaw, 0)
        camera.fov = float(self.cfg["fov"]) + p.fov_extra

    def is_night(self):
        return math.sin(self.time_of_day * math.tau) < -0.05

    def _update_env(self, dt):
        tod = self.time_of_day
        e = math.sin(tod * math.tau)
        day = _smooth(-0.14, 0.30, e)
        sky = SKY_NIGHT + (SKY_DAY - SKY_NIGHT) * day
        tint = math.exp(-((e - 0.0) / 0.16) ** 2) * 0.55
        sky = sky + (SKY_SUNSET - sky) * tint * (0.35 + 0.65 * (1 - abs(e) * 2))
        R = self.render_distance
        fog_end = max(30.0, R * 16 - 6.0)
        fog_start = fog_end * 0.58
        p = self.player
        if self.state in ("playing", "paused", "dead") and p.head_water:
            wc = np.array([0.08, 0.22, 0.48]) * (0.35 + 0.65 * day)
            sky = wc
            fog_start, fog_end = 0.5, 16.0
        sun = max(day, 0.0)
        self.renderer.set_env((float(sky[0]), float(sky[1]), float(sky[2])), sun, fog_start, fog_end)
        window.color = Color(float(sky[0]), float(sky[1]), float(sky[2]), 1.0)
        camera.clip_plane_far = max(120.0, R * 16 * 1.6)
        if self.sky:
            cp = camera.world_position
            self.sky.update((cp.x, cp.y, cp.z), tod, dt, CHUNK_H + 14)

    def _performance_guard(self, dt):
        if not self.cfg["auto_performance"] or self.state != "playing":
            return
        if self.dt_avg > 0.050:
            self.slow_t += dt
        else:
            self.slow_t = max(0.0, self.slow_t - dt * 0.5)
        if self.slow_t > 5.0:
            self.slow_t = 0.0
            if self.world.render_distance > 3:
                self.world.set_render_distance(self.world.render_distance - 1)
                self.render_distance = self.world.render_distance
                self.hud.toast(f"Performance guard: view distance lowered to {self.render_distance}", U.WARN)
            elif self.renderer.shader_name not in ("off", "lite"):
                self.set_shader("lite")
                self.hud.toast("Performance guard: switched to the Lite shader", U.WARN)

    # ============================================================== interaction ===
    def _player_hits(self, x, y, z):
        p = self.player
        return (abs(p.pos[0] - (x + 0.5)) < 0.3 + 0.5 and abs(p.pos[2] - (z + 0.5)) < 0.3 + 0.5
                and p.pos[1] < y + 1 and p.pos[1] + 1.8 > y)

    def pick_block(self):
        hit = raycast.cast(self.world, self.player.eye_pos(), self.player.look_dir(), settings.REACH)
        if not hit:
            return
        b = B.get(hit[3])
        if b.placeable and self.gamemode == "creative":
            self.player.hotbar[self.player.selected] = b.name
            self.hud.refresh_hotbar()

    def interact(self, dt):
        p = self.player
        w = self.world
        self.attack_cd -= dt
        self.break_cd -= dt
        self.place_cd -= dt
        eye, d = p.eye_pos(), p.look_dir()
        hit = raycast.cast(w, eye, d, settings.REACH)
        mh = self.mobs.pick(eye, d, 4.5) if (self.mobs and self.mobs.enabled) else None
        mob_first = mh is not None and (hit is None or mh[1] < hit[4])
        lmb = bool(held_keys['left mouse']) and not self.chat_open
        rmb = bool(held_keys['right mouse']) and not self.chat_open
        edge_l, edge_r = self.lmb_edge, self.rmb_edge
        self.lmb_edge = self.rmb_edge = False
        creative = self.gamemode == "creative"

        if hit and not mob_first and hit[2] != (0, 0, 0):
            hx, hy, hz = hit[0]
            self.outline.set_pos(hx, hy, hz)
            self.outline.show()
            self.target = hit
        else:
            self.outline.hide()
            self.target = None
            hit = None if mob_first else hit

        # --- attacking mobs
        if mob_first:
            self.mine = None
            self.crack.hide()
            if edge_l and self.attack_cd <= 0:
                self.attack_cd = 0.38
                mob = mh[0]
                dmg = 20 if creative else (2 if p.vel[1] >= 0 else 3)
                self.hud.swing_now()
                self.audio.play_var("hit_stone", 0.5, variants=3)
                if self.is_client:
                    self.client.send({"t": "hit_mob", "id": mob.id, "dmg": dmg})
                    mob.hurt_t = 0.3
                else:
                    if self.mobs.damage(mob, dmg, p.pos) and mob.dead_t > 0:
                        self.mods.fire("mob_killed", self, mob.kind)
        elif self.target is not None:
            pos = self.target[0]
            bid = self.target[3]
            blk = B.get(bid)
            if creative:
                self.crack.hide()
                if lmb and (edge_l or self.break_cd <= 0):
                    self.break_cd = 0.2
                    self.hud.swing_now()
                    self.break_block(*pos)
            else:
                if lmb and blk.hardness != float("inf"):
                    if self.mine is None or self.mine[0] != pos:
                        self.mine = [pos, 0.0]
                        self.mine_snd = 0.0
                    need = max(0.25, blk.hardness * 1.5)
                    self.mine[1] += dt / need
                    self.mine_snd -= dt
                    if self.mine_snd <= 0:
                        self.mine_snd = 0.27
                        self.audio.block_sound("hit", blk.material, 0.6)
                        self.hud.swing_now()
                        self.particles.burst(pos[0] + 0.5, pos[1] + 0.5, pos[2] + 0.5, self._block_color(bid), 3, 1.4)
                    self.crack.set_pos(pos[0] + 0.5, pos[1], pos[2] + 0.5)
                    self.crack.set_color_scale(1, 1, 1, min(0.65, self.mine[1] * 0.65))
                    self.crack.show()
                    if self.mine[1] >= 1.0:
                        self.mine = None
                        self.crack.hide()
                        self.break_block(*pos)
                else:
                    self.mine = None
                    self.crack.hide()
        else:
            self.mine = None
            self.crack.hide()

        # --- place / eat
        sel = p.selected_name()
        if rmb and (edge_r or self.place_cd <= 0) and sel:
            if sel == "meat":
                if edge_r and not creative and p.count("meat") > 0 and p.health < 20:
                    p.take("meat")
                    p.heal(6)
                    self.audio.play("eat", 0.8)
                    self.hud.swing_now()
                    self.hud.refresh_hotbar()
            elif self.target is not None:
                self.place_cd = 0.25
                px, py, pz = self.target[1]
                b = B.by_name(sel)
                if b is not None and w.get_block(px, py, pz) in (B.AIR, B.WATER) and \
                        not (b.solid and self._player_hits(px, py, pz)):
                    if creative or p.count(sel) > 0:
                        self.hud.swing_now()
                        if w.set_block(px, py, pz, b.id):
                            self.audio.block_sound("place", b.material, 0.8)
                            self._net_block(px, py, pz, b.id)
                            self.mods.fire("block_place", self, (px, py, pz), b.name)
                            if not creative:
                                p.take(sel)
                                self.hud.refresh_hotbar()

    def _block_color(self, bid):
        b = B.get(bid)
        c = self.atlas.avg.get(b.side) or self.atlas.avg.get(b.top) or (0.6, 0.6, 0.6)
        return c

    def break_block(self, x, y, z):
        w = self.world
        bid = w.get_block(x, y, z)
        if bid <= 0 or bid == B.BEDROCK:
            return
        blk = B.get(bid)
        if w.set_block(x, y, z, B.AIR):
            self._edit_fx(x, y, z, B.AIR, old=bid)
            self._net_block(x, y, z, B.AIR)
            self.mods.fire("block_break", self, (x, y, z), blk.name)
            if self.gamemode == "survival":
                drop = DROPS.get(bid, blk.name)
                if drop:
                    self.player.give(drop)
                    self.hud.refresh_hotbar()

    def _edit_fx(self, x, y, z, bid, old=None):
        """Particles + sound for any edit (local or remote)."""
        if old is not None and old > 0:
            blk = B.get(old)
            self.audio.block_sound("break", blk.material, 0.9)
            if self.particles:
                self.particles.burst(x + 0.5, y + 0.5, z + 0.5, self._block_color(old), 12)
        elif bid > 0:
            self.audio.block_sound("place", B.get(bid).material, 0.5)

    # ================================================================= combat =====
    def _mob_hurt_player(self, dmg, from_pos):
        self.player.hurt(dmg, from_pos)

    def _mob_drop(self, kind, pos):
        if self.gamemode == "survival" and kind in M.PASSIVE:
            self.player.give("meat", random.choice((1, 1, 2)))
            self.audio.play("pop", 0.6)
            self.hud.refresh_hotbar()

    def on_player_hurt(self):
        self.dmg_flash = 0.5

    def on_player_died(self):
        self.audio.play("player_death", 1.0)
        self.state = "dead"
        self.set_cursor(True)
        if self.hud:
            self.hud.show(False)
        screens.dead(self)

    def respawn_from_death(self):
        self.ui.clear()
        self.respawn_player()
        self.player.dead = False
        self.player.health = 20.0
        self.state = "playing"
        self.set_cursor(False)
        if self.hud:
            self.hud.show(True)

    def respawn_player(self, void=False):
        p = self.player
        p.pos[:] = list(self.spawn)
        p.reset_motion()
        p.health = 20.0
        p.dead = False
        self.unstick = False
        w = self.world
        x, z = int(math.floor(p.pos[0])), int(math.floor(p.pos[2]))
        top = w.column_top(x, z)
        if top >= 0:
            p.pos[1] = max(top, SEA_LEVEL) + 1.05
        if void:
            self.say("You fell out of the world.", U.WARN)

    # ================================================================== debug ======
    def debug_text(self):
        p, w = self.player, self.world
        cx, cz = int(math.floor(p.pos[0])) >> 4, int(math.floor(p.pos[2])) >> 4
        face = ["south (+z)", "west (-x)", "north (-z)", "east (+x)"][int(((p.yaw % 360) + 45) // 90) % 4]
        face = ["+z", "+x", "-z", "-x"][int(((p.yaw % 360) + 45) // 90) % 4]
        pp, hh = self.mobs.counts() if self.mobs else (0, 0)
        tod = self.time_of_day
        return (f"PyCraft {settings.VERSION}   {self.fps:4.0f} fps ({self.dt_avg * 1000:4.1f} ms)\n"
                f"XYZ {p.pos[0]:.1f} / {p.pos[1]:.1f} / {p.pos[2]:.1f}   facing {face}\n"
                f"chunk {cx},{cz}   loaded {len(w.chunks)}  drawn {w.visible_chunk_count()}   view {w.render_distance}\n"
                f"mesh {w.stats['mesh_ms']:.1f} ms   gen {w.stats['gen']}   pending {len(w._pending_mesh)}\n"
                f"mobs {pp} friendly / {hh} hostile   time {tod:.2f}   {self.gamemode}\n"
                f"shader {self.renderer.shader_name}   pack {self.atlas.pack_id}"
                + (f"\nplayers online: {len(self.remotes) + 1}" if (self.server or self.client) else ""))
