"""In-game HUD: crosshair, hotbar with real block icons, hearts, debug text, chat,
toasts, damage/underwater overlays and the first-person held block."""
import math

import numpy as np
from PIL import Image, ImageDraw
from panda3d.core import NodePath

from ursina import Entity, Text, Texture, camera, destroy, window
from ursina import time as utime
from ursina.color import Color

from engine import atlas as A
from engine import blocks as B
from engine import render
from game import ui as U

HEART = [
    "..XX...XX..",
    ".XXXX.XXXX.",
    "XXXXXXXXXXX",
    "XXXXXXXXXXX",
    ".XXXXXXXXX.",
    "..XXXXXXX..",
    "...XXXXX...",
    "....XXX....",
    ".....X.....",
]


def _heart_img(kind):
    S = 11
    img = Image.new("RGBA", (S + 2, 11), (0, 0, 0, 0))
    px = img.load()
    for y, row in enumerate(HEART):
        for x, c in enumerate(row):
            if c != "X":
                continue
            half_left = x < 5.5
            full = kind == "full" or (kind == "half" and half_left)
            col = (222, 38, 50, 255) if full else (46, 36, 42, 255)
            if full and y < 3 and x in (1, 2, 7, 8) and x < 5.5 + 1:
                col = (255, 130, 140, 255)
            px[x + 1, y + 1] = col
    # dark outline
    out = img.copy()
    op = out.load()
    for y in range(img.height):
        for x in range(img.width):
            if px[x, y][3] == 0:
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < img.width and 0 <= ny < img.height and px[nx, ny][3] != 0:
                        op[x, y] = (24, 6, 10, 255)
                        break
    return out


def _meat_icon():
    img = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.ellipse((5, 8, 26, 26), fill=(196, 92, 82, 255), outline=(90, 34, 30, 255), width=2)
    d.ellipse((10, 12, 17, 18), fill=(236, 150, 138, 255))
    d.rectangle((23, 4, 27, 12), fill=(238, 232, 214, 255), outline=(120, 110, 96, 255))
    d.rectangle((21, 2, 29, 6), fill=(238, 232, 214, 255), outline=(120, 110, 96, 255))
    return img


def _vignette_img(n=128):
    yy, xx = np.mgrid[0:n, 0:n].astype(np.float32)
    r = np.sqrt(((xx - n / 2) / (n / 2)) ** 2 + ((yy - n / 2) / (n / 2)) ** 2)
    a = np.clip((r - 0.55) / 0.75, 0, 1) ** 1.6
    img = np.zeros((n, n, 4), np.uint8)
    img[..., 3] = (a * 255).astype(np.uint8)
    return Image.fromarray(img, "RGBA")


class Hud:
    def __init__(self, game):
        self.g = game
        self.root = Entity(parent=camera.ui)
        self.icons = {}
        self.slot_bg, self.slot_icon, self.slot_count = [], [], []
        self.hearts = []
        self.chat_lines = []          # (text, color, born)
        self.chat_texts = []
        self.toasts = []
        self._aspect = None
        self.hand = None
        self.hand_name = None
        self.swing = 0.0
        self._build_textures()
        self._build()

    # ---------------------------------------------------------------------- build
    def _build_textures(self):
        self.tex_heart = {k: Texture(_heart_img(k)) for k in ("full", "half", "empty")}
        self.tex_vig = Texture(_vignette_img())
        self.tex_vig.filtering = 'bilinear'
        self.icons.clear()

    def icon_tex(self, name):
        t = self.icons.get(name)
        if t is not None:
            return t
        if name == "meat":
            img = _meat_icon()
        else:
            b = B.by_name(name)
            if b is None:
                img = Image.new("RGBA", (16, 16), (255, 0, 255, 255))
            else:
                img = A.make_icon(self.g.atlas, b.top, b.icon if b.icon in self.g.atlas.index else b.side)
        t = Texture(img)
        self.icons[name] = t
        return t

    def _build(self):
        r = self.root
        # crosshair
        self.xh_h = Entity(parent=r, model='quad', scale=(0.022, 0.0035), color=Color(1, 1, 1, 0.85), z=-0.5)
        self.xh_v = Entity(parent=r, model='quad', scale=(0.0035, 0.022), color=Color(1, 1, 1, 0.85), z=-0.5)
        # hotbar
        self.slot_w = 0.082
        x0 = -4 * self.slot_w
        self.bar_y = -0.452
        self.sel = Entity(parent=r, model='quad', scale=(self.slot_w + 0.006, self.slot_w + 0.006),
                          color=Color(1, 1, 1, 0.95), position=(0, self.bar_y, -0.1))
        for i in range(9):
            x = x0 + i * self.slot_w
            bg = Entity(parent=r, model='quad', scale=(self.slot_w - 0.004, self.slot_w - 0.004),
                        color=Color(0.07, 0.08, 0.10, 0.72), position=(x, self.bar_y, -0.2))
            ic = Entity(parent=r, model='quad', scale=(self.slot_w * 0.78, self.slot_w * 0.78),
                        position=(x, self.bar_y, -0.3), color=Color(1, 1, 1, 1))
            ct = U.Label(r, "", x + self.slot_w * 0.40, self.bar_y - self.slot_w * 0.30, 0.85, U.TEXT,
                         origin=(0.5, -0.5), z=-0.4)
            self.slot_bg.append(bg)
            self.slot_icon.append(ic)
            self.slot_count.append(ct)
        self.name_label = U.Label(r, "", 0, self.bar_y + 0.075, 1.0, U.TEXT, z=-0.4)
        self.name_t = 0.0
        # hearts
        for i in range(10):
            e = Entity(parent=r, model='quad', texture=self.tex_heart["full"],
                       scale=(0.036, 0.036), position=(x0 - 0.04 + i * 0.037 + 0.02, self.bar_y + 0.062, -0.3))
            self.hearts.append(e)
        self._health_cache = None
        # overlays
        self.dmg = Entity(parent=r, model='quad', scale=(4, 2), color=Color(0.8, 0.05, 0.05, 0.0), z=0.5)
        self.water = Entity(parent=r, model='quad', scale=(4, 2), color=Color(0.1, 0.25, 0.6, 0.0), z=0.45)
        self.vig = Entity(parent=r, model='quad', texture=self.tex_vig, scale=(2.4, 1.2),
                          color=Color(0, 0, 0, 0.0), z=0.4)
        # debug + chat
        self.debug = Text("", parent=r, origin=(-0.5, 0.5), scale=0.85, position=(-0.8, 0.49, -0.5),
                          color=Color(1, 1, 1, 0.95), add_to_scene_entities=False)
        self.debug_bg = Entity(parent=r, model='quad', color=Color(0, 0, 0, 0.35), z=-0.45)
        self.debug_bg.enabled = False
        self.debug.enabled = False
        self._dbg_t = 0.0
        for i in range(7):
            t = Text("", parent=r, origin=(-0.5, -0.5), scale=0.9, position=(-0.8, -0.30 + i * 0.035, -0.5),
                     add_to_scene_entities=False)
            self.chat_texts.append(t)
        self.chat_bg = Entity(parent=r, model='quad', color=Color(0, 0, 0, 0.35), z=-0.45)
        self.chat_bg.enabled = False
        self.chat_field = U.TextField(r, -0.3, -0.34, 0.9, 0.05, "", maxlen=100, hint="type a message, / for commands")
        self.chat_field.enabled = False
        self.chat_field.label.enabled = False
        self.toast_text = U.Label(r, "", 0, 0.32, 1.1, U.WARN, z=-0.5)
        self.toast_t = 0.0
        self.refresh_hotbar()
        self.layout()

    def layout(self):
        a = window.aspect_ratio
        self._aspect = a
        left = -a / 2 + 0.012
        self.debug.position = (left, 0.488, -0.5)
        for i, t in enumerate(self.chat_texts):
            t.position = (left, -0.285 + i * 0.034, -0.5)
        self.chat_field.x = left + 0.45
        self.chat_field.label.x = left + 0.012
        self.chat_field.y = self.chat_field.label.y = -0.34
        self.dmg.scale = (a * 2 + 1, 2)
        self.water.scale = (a * 2 + 1, 2)
        self.vig.scale = (a * 1.15, 1.15)

    # --------------------------------------------------------------- hotbar / hearts
    def refresh_hotbar(self):
        p = self.g.player
        survival = self.g.gamemode == "survival"
        for i in range(9):
            name = p.hotbar[i]
            ic = self.slot_icon[i]
            if name:
                ic.texture = self.icon_tex(name)
                ic.enabled = True
                if survival:
                    c = p.count(name)
                    self.slot_count[i].text = str(c) if c != 1 else ""
                    ic.color = Color(1, 1, 1, 1) if c > 0 else Color(1, 1, 1, 0.25)
                else:
                    self.slot_count[i].text = ""
                    ic.color = Color(1, 1, 1, 1)
            else:
                ic.enabled = False
                self.slot_count[i].text = ""
        self.sel.x = -4 * self.slot_w + p.selected * self.slot_w
        self.update_hand()
        sel = p.hotbar[p.selected]
        self.name_label.text = (sel or "").replace("_", " ")
        self.name_t = 1.6

    def set_survival_ui(self, survival):
        for h in self.hearts:
            h.enabled = survival
        self._health_cache = None

    def _hearts(self, hp):
        key = int(hp)
        if key == self._health_cache:
            return
        self._health_cache = key
        for i, h in enumerate(self.hearts):
            v = hp - i * 2
            h.texture = self.tex_heart["full" if v >= 2 else ("half" if v >= 1 else "empty")]

    # ---------------------------------------------------------------------- chat
    def say(self, text, col=None):
        self.chat_lines.append((text, col or U.TEXT, utime.dt * 0 + self.g.clock))
        self.chat_lines = self.chat_lines[-30:]
        self._chat_dirty = True

    def toast(self, text, col=None):
        self.toast_text.text = text
        self.toast_text.color = col or U.WARN
        self.toast_t = 3.0

    def open_chat(self, prefill=""):
        self.chat_field.enabled = True
        self.chat_field.label.enabled = True
        self.chat_field.text = prefill
        self.chat_field.on_click()
        self.g.chat_open = True

    def close_chat(self):
        self.chat_field.blur()
        self.chat_field.enabled = False
        self.chat_field.label.enabled = False
        self.g.ui.focus = None
        self.g.chat_open = False

    # ---------------------------------------------------------------- held block
    def update_hand(self):
        p = self.g.player
        name = p.hotbar[p.selected]
        if name == self.hand_name:
            return
        self.drop_hand()
        self.hand_name = name
        if not name:
            return
        r = self.g.renderer
        if name == "meat":
            mesh = render.box_mesh((0.3, 0.2, 0.42), (0.78, 0.36, 0.32), (0, -0.1, 0))
            group = "mob"
        else:
            b = B.by_name(name)
            if b is None:
                return
            mesh = render.block_cube_mesh(B.tables, self.g.atlas.uv, b.id, 0.27)
            group = "solid"
        node = render.build_geom_node(mesh, "hand")
        np_ = NodePath(node)
        np_.reparent_to(camera)
        np_.set_bin("fixed", 40)
        np_.set_depth_test(False)
        np_.set_depth_write(False)
        np_.set_two_sided(False)
        r.add_node(group, np_)
        self.hand = np_
        self._hand_group = group
        self._place_hand(0.0)

    def _place_hand(self, swing):
        if self.hand is None:
            return
        s = math.sin(swing * math.pi)
        self.hand.set_pos(0.36 - 0.10 * s, -0.31 - 0.08 * s, 0.80 - 0.08 * s)
        self.hand.set_hpr(-20 + 8 * s, 18 + 38 * s, 0)

    def swing_now(self):
        self.swing = 1.0

    def drop_hand(self):
        if self.hand is not None:
            grp = self.g.renderer.groups[getattr(self, "_hand_group", "solid")]
            if self.hand in grp:
                grp.remove(self.hand)
            self.hand.remove_node()
            self.hand = None
        self.hand_name = None

    # ------------------------------------------------------------------- per frame
    def update(self, dt):
        g = self.g
        if abs(window.aspect_ratio - (self._aspect or 0)) > 1e-3:
            self.layout()
        p = g.player
        if g.gamemode == "survival":
            self._hearts(p.health)
        # swing
        if self.swing > 0:
            self.swing = max(0.0, self.swing - dt * 4.5)
            self._place_hand(1.0 - self.swing)
        # overlays
        flash = max(0.0, getattr(g, "dmg_flash", 0.0))
        self.dmg.color = Color(0.8, 0.05, 0.05, min(0.55, flash))
        self.water.color = Color(0.1, 0.25, 0.6, 0.38 if p.head_water else 0.0)
        self.vig.color = Color(0, 0, 0, 0.55 if g.cfg.get("shader") == "cinematic" else 0.0)
        # name flash above hotbar
        if self.name_t > 0:
            self.name_t -= dt
            if self.name_t <= 0:
                self.name_label.text = ""
        if self.toast_t > 0:
            self.toast_t -= dt
            if self.toast_t <= 0:
                self.toast_text.text = ""
        # chat fade
        now = g.clock
        if getattr(self, "_chat_dirty", True) or g.chat_open or self._chat_visible(now):
            lines = self.chat_lines[-7:]
            any_vis = False
            for i, t in enumerate(self.chat_texts):
                idx = len(lines) - 1 - i
                if idx >= 0:
                    text, col, born = lines[idx]
                    age = now - born
                    a = 1.0 if g.chat_open else max(0.0, min(1.0, (9.0 - age) / 1.5))
                    if a > 0.02:
                        t.text = text
                        t.color = Color(col.r, col.g, col.b, a)
                        any_vis = True
                    else:
                        t.text = ""
                else:
                    t.text = ""
            self._chat_dirty = False
            self.chat_bg.enabled = False
        # debug
        if g.cfg.get("show_debug"):
            self._dbg_t -= dt
            if self._dbg_t <= 0:
                self._dbg_t = 0.25
                self.debug.text = g.debug_text()
        # chat cursor blink handled by the field's update()

    def _chat_visible(self, now):
        return bool(self.chat_lines) and (now - self.chat_lines[-1][2]) < 10.5

    def set_debug(self, on):
        self.debug.enabled = on
        if not on:
            self.debug.text = ""
        else:
            self._dbg_t = 0.0

    def show(self, on):
        self.root.enabled = on
        if self.hand is not None:
            if on:
                self.hand.show()
            else:
                self.hand.hide()

    def destroy(self):
        self.drop_hand()
        destroy(self.root)
