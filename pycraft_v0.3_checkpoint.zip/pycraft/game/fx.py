"""Visual extras: block-break particles, sun/moon/stars/clouds, remote-player avatars."""
import colorsys
import math
import random

from panda3d.core import NodePath, TextNode, Vec3

from engine import render


class Particles:
    def __init__(self, renderer, n=72):
        self.r = renderer
        proto = render.build_geom_node(render.box_mesh((0.1, 0.1, 0.1), (1, 1, 1), (0, -0.05, 0)), "particle")
        self.nodes, self.state = [], []
        for _ in range(n):
            holder = renderer.mob_root.attach_new_node("p")
            holder.attach_new_node(proto)
            holder.hide()
            self.nodes.append(holder)
            self.state.append(None)
        self.cursor = 0

    def burst(self, x, y, z, rgb, n=10, speed=2.6):
        for _ in range(n):
            i = self.cursor
            self.cursor = (self.cursor + 1) % len(self.nodes)
            jit = random.uniform(0.75, 1.15)
            col = (min(1, rgb[0] * jit), min(1, rgb[1] * jit), min(1, rgb[2] * jit))
            node = self.nodes[i]
            node.set_color_scale(col[0], col[1], col[2], 1)
            pos = [x + random.uniform(-0.4, 0.4), y + random.uniform(-0.4, 0.4), z + random.uniform(-0.4, 0.4)]
            vel = [random.uniform(-1, 1) * speed, random.uniform(0.3, 1.4) * speed, random.uniform(-1, 1) * speed]
            self.state[i] = [pos, vel, random.uniform(0.45, 0.9)]
            node.set_pos(*pos)
            node.show()

    def update(self, dt):
        for i, s in enumerate(self.state):
            if s is None:
                continue
            pos, vel, life = s
            life -= dt
            if life <= 0:
                self.nodes[i].hide()
                self.state[i] = None
                continue
            vel[1] -= 16 * dt
            pos[0] += vel[0] * dt
            pos[1] += vel[1] * dt
            pos[2] += vel[2] * dt
            s[2] = life
            self.nodes[i].set_pos(*pos)

    def clear(self):
        for i, n in enumerate(self.nodes):
            n.hide()
            self.state[i] = None

    def destroy(self):
        for n in self.nodes:
            n.remove_node()
        self.nodes, self.state = [], []


class Sky:
    """Sun, moon, stars, clouds. All blended by time of day, ~4 draw calls total."""

    CLOUD_CELL = 12.0

    def __init__(self, renderer, scene):
        self.r = renderer
        self.root = NodePath("sky")
        self.root.reparent_to(scene)
        self.sun = render.make_card(26, (1.0, 0.93, 0.62, 1.0))
        self.sun.reparent_to(self.root)
        self.moon = render.make_card(18, (0.86, 0.9, 1.0, 1.0))
        self.moon.reparent_to(self.root)
        self.stars = render.make_stars()
        self.stars.reparent_to(self.root)
        cl = render.make_clouds()
        self.clouds = renderer.cloud_root.attach_new_node(cl)
        self.clouds.set_two_sided(False)
        self.clouds.set_transparency(1)
        self.drift = 0.0

    def update(self, cam_pos, tod, dt, cloud_y):
        a = tod * math.tau
        dx, dy = math.cos(a), math.sin(a)
        self.root.set_pos(*cam_pos)
        self.sun.set_pos(dx * 88, dy * 88, 12)
        self.moon.set_pos(-dx * 88, -dy * 88, -12)
        night = max(0.0, min(1.0, (-dy + 0.05) * 3.0))
        self.stars.set_color_scale(1, 1, 1, night)
        self.stars.show() if night > 0.02 else self.stars.hide()
        self.sun.show() if dy > -0.25 else self.sun.hide()
        self.moon.show() if -dy > -0.25 else self.moon.hide()
        self.drift = (self.drift + dt * 1.2) % self.CLOUD_CELL
        c = self.CLOUD_CELL
        self.clouds.set_pos(math.floor((cam_pos[0] - self.drift) / c) * c + self.drift,
                            cloud_y,
                            math.floor(cam_pos[2] / c) * c)

    def destroy(self):
        self.clouds.remove_node()
        self.root.remove_node()


def _avatar_mesh(rgb):
    skin = (0.86, 0.68, 0.55)
    dark = tuple(c * 0.55 for c in rgb)
    parts = [
        render.box_mesh((0.5, 0.7, 0.28), rgb, (0, 0.75, 0)),
        render.box_mesh((0.46, 0.46, 0.46), skin, (0, 1.45, 0)),
        render.box_mesh((0.48, 0.12, 0.48), (0.25, 0.17, 0.1), (0, 1.82, 0)),
        render.box_mesh((0.2, 0.7, 0.2), skin, (-0.36, 0.75, 0)),
        render.box_mesh((0.2, 0.7, 0.2), skin, (0.36, 0.75, 0)),
        render.box_mesh((0.24, 0.75, 0.24), dark, (-0.13, 0.0, 0)),
        render.box_mesh((0.24, 0.75, 0.24), dark, (0.13, 0.0, 0)),
    ]
    return render.merge_meshes(parts)


class RemotePlayer:
    def __init__(self, renderer, pid, name):
        self.pid, self.name = pid, name
        h = (pid * 0.37) % 1.0
        rgb = colorsys.hsv_to_rgb(h, 0.6, 0.85)
        self.root = renderer.mob_root.attach_new_node(f"player{pid}")
        self.root.attach_new_node(render.build_geom_node(_avatar_mesh(rgb), "avatar"))
        tn = TextNode("tag")
        tn.set_text(name)
        tn.set_align(TextNode.ACenter)
        tn.set_text_color(1, 1, 1, 1)
        tn.set_shadow(0.06, 0.06)
        tn.set_shadow_color(0, 0, 0, 0.9)
        tag = self.root.attach_new_node(tn)
        tag.set_pos(0, 2.25, 0)
        tag.set_scale(0.32)
        tag.set_billboard_point_eye()
        tag.set_light_off()
        tag.set_shader_off(10)
        tag.set_fog_off()
        tag.set_depth_test(False)
        tag.set_bin("fixed", 45)
        self.tag = tag
        self.target = None
        self.pos = None
        self.yaw = 0.0

    def set_target(self, x, y, z, yaw):
        self.target = (x, y, z, yaw)
        if self.pos is None:
            self.pos = [x, y, z]
            self.yaw = yaw

    def update(self, dt):
        if self.target is None:
            return
        k = min(1.0, 14 * dt)
        for i in range(3):
            self.pos[i] += (self.target[i] - self.pos[i]) * k
        d = (self.target[3] - self.yaw + 180) % 360 - 180
        self.yaw += d * k
        self.root.set_pos(*self.pos)
        self.root.set_h(self.yaw)

    def destroy(self):
        self.root.remove_node()
