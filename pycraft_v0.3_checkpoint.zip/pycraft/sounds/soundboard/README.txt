Drop your own .wav / .ogg / .mp3 clips in this folder.
They show up (green buttons) in the Soundboard screen the next time you open it.
