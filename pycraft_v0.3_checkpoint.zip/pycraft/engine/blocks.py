"""
Block registry. Dynamic so mods can add blocks before the texture atlas is built.

Render classes (what the mesher cares about):
  OPAQUE  full cube, hides neighbouring faces
  CUTOUT  full cube with see-through pixels (leaves, glass); same-id faces culled
  WATER   translucent liquid, separate draw pass
"""
import numpy as np

AIR_CLS, OPAQUE, CUTOUT, WATER_CLS = 0, 1, 2, 3

MATERIALS = ("stone", "dirt", "wood", "sand", "gravel", "glass", "leaves",
             "snow", "grass", "water")


class Block:
    __slots__ = ("id", "name", "cls", "solid", "hardness", "top", "bottom",
                 "side", "material", "placeable", "blocks_sky", "icon", "glow")

    def __init__(self, id, name, cls=OPAQUE, solid=True, hardness=1.0,
                 top=None, bottom=None, side=None, material="stone",
                 placeable=True, blocks_sky=None, icon=None, glow=False):
        self.id = id
        self.name = name
        self.cls = cls
        self.solid = solid
        self.hardness = hardness
        base = name
        self.top = top or side or base
        self.bottom = bottom or side or base
        self.side = side or base
        self.material = material
        self.placeable = placeable
        self.blocks_sky = (cls == OPAQUE or name == "leaves") \
            if blocks_sky is None else blocks_sky
        self.icon = icon or self.side
        self.glow = glow


_blocks = {}
_by_name = {}
_next_mod_id = 64

# --- ids for the built-ins (stable so old saves keep working) -----------------
AIR = 0
GRASS = 1
DIRT = 2
STONE = 3
SAND = 4
WATER = 5
LOG = 6
LEAVES = 7
GLASS = 8
BEDROCK = 9
SNOW_GRASS = 10
PLANKS = 11
GRAVEL = 12
COAL_ORE = 13
IRON_ORE = 14
GOLD_ORE = 15
DIAMOND_ORE = 16
COBBLE = 17


def _reg(b):
    _blocks[b.id] = b
    _by_name[b.name] = b
    return b


def _register_builtins():
    _reg(Block(AIR, "air", cls=AIR_CLS, solid=False, placeable=False,
               blocks_sky=False))
    _reg(Block(GRASS, "grass", top="grass_top", bottom="dirt",
               side="grass_side", hardness=0.6, material="grass",
               icon="grass_side"))
    _reg(Block(DIRT, "dirt", hardness=0.5, material="dirt"))
    _reg(Block(STONE, "stone", hardness=1.5, material="stone"))
    _reg(Block(SAND, "sand", hardness=0.5, material="sand"))
    _reg(Block(WATER, "water", cls=WATER_CLS, solid=False, placeable=False,
               material="water", blocks_sky=False))
    _reg(Block(LOG, "log", top="log_top", bottom="log_top", side="log_side",
               hardness=1.2, material="wood", icon="log_side"))
    _reg(Block(LEAVES, "leaves", cls=CUTOUT, hardness=0.2, material="leaves"))
    _reg(Block(GLASS, "glass", cls=CUTOUT, hardness=0.4, material="glass",
               blocks_sky=False))
    _reg(Block(BEDROCK, "bedrock", hardness=float("inf"), placeable=False,
               material="stone"))
    _reg(Block(SNOW_GRASS, "snow_grass", top="snow", bottom="dirt",
               side="snow_side", hardness=0.6, material="snow",
               icon="snow_side"))
    _reg(Block(PLANKS, "planks", hardness=1.0, material="wood"))
    _reg(Block(GRAVEL, "gravel", hardness=0.6, material="gravel"))
    _reg(Block(COAL_ORE, "coal_ore", hardness=2.0, material="stone"))
    _reg(Block(IRON_ORE, "iron_ore", hardness=2.2, material="stone"))
    _reg(Block(GOLD_ORE, "gold_ore", hardness=2.2, material="stone"))
    _reg(Block(DIAMOND_ORE, "diamond_ore", hardness=2.6, material="stone"))
    _reg(Block(COBBLE, "cobblestone", hardness=1.6, material="stone"))


_register_builtins()

HOTBAR_DEFAULT = ["grass", "dirt", "stone", "cobblestone", "log", "planks",
                  "glass", "sand", "leaves"]

# extra tiles that mods want generated (name -> (r,g,b) or png path)
extra_tiles = {}


def register_mod_block(name, color=None, png=None, hardness=1.0, solid=True,
                       transparent=False, material="stone", glow=False,
                       hotbar=False):
    """Called by the mod API before the atlas is built. Returns the block id."""
    global _next_mod_id
    if name in _by_name:
        return _by_name[name].id
    while _next_mod_id in _blocks:
        _next_mod_id += 1
    if _next_mod_id > 250:
        raise RuntimeError("too many mod blocks")
    bid = _next_mod_id
    _next_mod_id += 1
    _reg(Block(bid, name, cls=CUTOUT if transparent else OPAQUE, solid=solid,
               hardness=hardness, material=material, glow=glow))
    if png is not None:
        extra_tiles[name] = str(png)
    elif color is not None:
        extra_tiles[name] = tuple(color)
    if hotbar:
        HOTBAR_DEFAULT.append(name)
    return bid


def get(bid):
    return _blocks.get(int(bid), _blocks[AIR])


def by_name(name):
    return _by_name.get(name)


def all_blocks():
    return [b for _, b in sorted(_blocks.items())]


def placeable_blocks():
    return [b for b in all_blocks() if b.placeable]


def tile_names():
    """Every tile name needed, in a stable order."""
    names = []
    for b in all_blocks():
        if b.cls == AIR_CLS:
            continue
        for n in (b.top, b.bottom, b.side):
            if n not in names:
                names.append(n)
    return names


class Tables:
    """numpy lookup tables indexed by block id (256 entries)."""

    def __init__(self):
        self.cls = np.zeros(256, np.uint8)
        self.solid = np.zeros(256, bool)
        self.top = np.zeros(256, np.int32)
        self.bottom = np.zeros(256, np.int32)
        self.side = np.zeros(256, np.int32)
        self.sky = np.zeros(256, bool)
        self.glow = np.zeros(256, bool)

    def build(self, tile_index):
        for b in all_blocks():
            self.cls[b.id] = b.cls
            self.solid[b.id] = b.solid
            self.sky[b.id] = b.blocks_sky
            self.glow[b.id] = b.glow
            if b.cls != AIR_CLS:
                self.top[b.id] = tile_index[b.top]
                self.bottom[b.id] = tile_index[b.bottom]
                self.side[b.id] = tile_index[b.side]
        return self


tables = Tables()
