"""
Sound: every effect, mob voice, soundboard clip and music track is synthesised
here with numpy (nothing is copied from any game). Files are generated once into
cache/sounds_v1/*.wav, then played through Panda3D's audio manager.

If the machine has no audio device the manager silently becomes a null manager and
the game keeps running -- sound can never crash it.
"""
import math
import random
import wave
from pathlib import Path

import numpy as np

from engine.settings import CACHE_DIR, SOUND_DIR

SR = 22050
CACHE_VERSION = "sounds_v1"
rng_global = np.random.default_rng(1234)


# ------------------------------------------------------------ DSP helpers -----
def _t(sec):
    return np.arange(int(sec * SR)) / SR


def _noise(n, rng):
    return rng.uniform(-1.0, 1.0, n).astype(np.float32)


def _lowpass(x, cutoff, passes=1):
    a = 1.0 - math.exp(-2.0 * math.pi * cutoff / SR)
    n = max(8, int(6.0 / a))
    k = (a * (1.0 - a) ** np.arange(min(n, 4000))).astype(np.float32)
    y = x
    for _ in range(passes):
        y = np.convolve(y, k)[:len(x)]
    return y.astype(np.float32)


def _highpass(x, cutoff, passes=1):
    return (x - _lowpass(x, cutoff, passes)).astype(np.float32)


def _bandpass(x, lo, hi):
    return _lowpass(_highpass(x, lo), hi)


def _env(n, attack=0.002, decay=0.1):
    t = np.arange(n) / SR
    a = np.minimum(1.0, t / max(attack, 1e-4))
    return (a * np.exp(-t / max(decay, 1e-4))).astype(np.float32)


def _sine(freq, sec, phase=0.0):
    return np.sin(2 * math.pi * freq * _t(sec) + phase).astype(np.float32)


def _glide(f0, f1, sec, curve=1.0):
    t = np.linspace(0.0, 1.0, int(sec * SR)) ** curve
    return f0 + (f1 - f0) * t


def _osc(freq_curve, harmonics=1, kind="sine"):
    ph = np.cumsum(2 * math.pi * freq_curve / SR)
    if kind == "sine":
        return np.sin(ph).astype(np.float32)
    if kind == "saw":
        return (2.0 * ((ph / (2 * math.pi)) % 1.0) - 1.0).astype(np.float32)
    if kind == "square":
        return np.sign(np.sin(ph)).astype(np.float32)
    if kind == "tri":
        return (2.0 * np.abs(2.0 * ((ph / (2 * math.pi)) % 1.0) - 1.0) - 1.0).astype(np.float32)
    return np.sin(ph).astype(np.float32)


def _voice(f0_curve, formants, sec_env=None, nharm=24, breath=0.0, rng=None):
    """Additive 'vocal' synth: harmonics weighted by formant peaks."""
    n = len(f0_curve)
    ph = np.cumsum(2 * math.pi * f0_curve / SR)
    out = np.zeros(n, np.float32)
    for k in range(1, nharm + 1):
        fk = k * f0_curve
        g = np.zeros(n, np.float32)
        for fc, bw, amp in formants:
            g += amp * np.exp(-((fk - fc) / bw) ** 2)
        g[fk > SR * 0.45] = 0
        out += (g / k ** 0.35 * np.sin(k * ph)).astype(np.float32)
    if breath and rng is not None:
        out += breath * _lowpass(_noise(n, rng), 1800)
    if sec_env is not None:
        out *= sec_env[:n]
    return out


def _norm(x, peak=0.9):
    m = float(np.max(np.abs(x))) or 1.0
    return (x / m * peak).astype(np.float32)


def _fade(x, ms=4):
    n = int(ms * SR / 1000)
    if len(x) > 2 * n:
        r = np.linspace(0, 1, n, dtype=np.float32)
        x[:n] *= r
        x[-n:] *= r[::-1]
    return x


def _echo(x, delay=0.18, fb=0.35, taps=4):
    d = int(delay * SR)
    out = np.zeros(len(x) + d * taps, np.float32)
    out[:len(x)] += x
    for i in range(1, taps + 1):
        out[d * i:d * i + len(x)] += x * (fb ** i)
    return out


def write_wav(path, x):
    x = np.clip(x, -1.0, 1.0)
    data = (x * 32767).astype("<i2").tobytes()
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(data)


# ----------------------------------------------------------- block sounds ------
def _hit(material, sec, rng, soft=1.0):
    n = int(sec * SR)
    nz = _noise(n, rng)
    if material == "stone":
        body = _lowpass(nz, 2600, 2) * _env(n, 0.001, sec * 0.28)
        thump = _sine(95 + rng.uniform(-8, 8), sec) * _env(n, 0.001, 0.05)
        crack = _highpass(nz, 4000) * _env(n, 0.0005, 0.012)
        x = body * 1.4 + thump * 0.8 + crack * 0.6
    elif material in ("dirt", "grass"):
        body = _lowpass(nz, 900 if material == "dirt" else 1400, 2) * _env(n, 0.001, sec * 0.3)
        thump = _sine(70 + rng.uniform(-6, 6), sec) * _env(n, 0.001, 0.06)
        x = body * 1.8 + thump * 0.7
        if material == "grass":
            x += _highpass(nz, 3500) * _env(n, 0.002, sec * 0.2) * 0.25
    elif material == "sand":
        x = _bandpass(nz, 600, 3000) * _env(n, 0.002, sec * 0.35) * 1.5
    elif material == "gravel":
        x = _bandpass(nz, 500, 4500) * _env(n, 0.001, sec * 0.3) * 1.3
        for _ in range(int(sec * 40)):
            i = rng.integers(0, n - 80)
            x[i:i + 60] += _highpass(_noise(60, rng), 2000) * rng.uniform(0.2, 0.8)
    elif material == "wood":
        x = np.zeros(n, np.float32)
        for f, a, d in ((150, 1.0, 0.05), (310, 0.7, 0.04), (640, 0.4, 0.03), (1190, 0.2, 0.02)):
            x += a * _sine(f * rng.uniform(0.96, 1.04), sec) * _env(n, 0.0007, d)
        x += _bandpass(nz, 800, 3000) * _env(n, 0.0005, 0.01) * 0.5
    elif material == "glass":
        x = np.zeros(n, np.float32)
        for _ in range(7):
            f = rng.uniform(1800, 6500)
            x += _sine(f, sec) * _env(n, 0.0005, rng.uniform(0.02, 0.09)) * rng.uniform(0.2, 0.7)
        x += _highpass(nz, 5000) * _env(n, 0.0005, 0.02) * 0.5
    elif material == "leaves":
        x = _bandpass(nz, 2200, 7000) * _env(n, 0.004, sec * 0.3) * 1.4
    elif material == "snow":
        x = _bandpass(nz, 400, 2200) * _env(n, 0.004, sec * 0.35) * 1.8
        x += _sine(900, sec) * _env(n, 0.002, 0.02) * 0.08
    elif material == "water":
        x = _bandpass(nz, 300, 3500) * _env(n, 0.01, sec * 0.45) * 1.5
        for _ in range(4):
            f0 = rng.uniform(300, 700)
            c = _glide(f0, f0 * 2.2, 0.08)
            b = _osc(c) * _env(len(c), 0.001, 0.03) * 0.3
            i = rng.integers(0, max(1, n - len(c)))
            x[i:i + len(c)] += b[:max(0, min(len(c), n - i))]
    else:
        x = _lowpass(nz, 2000) * _env(n, 0.001, sec * 0.3)
    return _fade(_norm(x, 0.8 * soft))


def _gen_block_sounds(out, rng):
    mats = ("stone", "dirt", "grass", "sand", "gravel", "wood", "glass", "leaves", "snow")
    for m in mats:
        for i in range(3):
            out[f"break_{m}_{i}"] = _hit(m, 0.26, rng)
            out[f"place_{m}_{i}"] = _hit(m, 0.18, rng, 0.8)
            out[f"step_{m}_{i}"] = _hit(m, 0.10, rng, 0.5)
            out[f"hit_{m}_{i}"] = _hit(m, 0.07, rng, 0.45)
    for i in range(2):
        out[f"splash_{i}"] = _hit("water", 0.5, rng)
        out[f"swim_{i}"] = _hit("water", 0.22, rng, 0.45)
    # glass shatter is a longer break
    out["break_glass_0"] = _hit("glass", 0.5, rng)


# ----------------------------------------------------------- creature voices ----
def _boar(rng, kind="idle"):
    sec = 0.38 if kind == "idle" else 0.22
    f0 = _glide(170, 95, sec, 0.6) if kind != "death" else _glide(210, 60, 0.6)
    n = len(f0)
    f0 = f0 * (1 + 0.03 * np.sin(2 * math.pi * 26 * np.arange(n) / SR))
    env = _env(n, 0.01, sec * 0.7)
    x = _voice(f0, [(650, 350, 1.0), (1250, 450, 0.6), (2400, 600, 0.2)], env, breath=0.12, rng=rng)
    x += 0.35 * _lowpass(_noise(n, rng), 900) * env
    return _fade(_norm(x, 0.8))


def _woolly(rng, kind="idle"):
    sec = 0.7 if kind == "idle" else 0.3
    n = int(sec * SR)
    t = np.arange(n) / SR
    base = 330 if kind != "death" else 280
    f0 = base * (1 + 0.025 * np.sin(2 * math.pi * 7 * t)) * (1 - 0.18 * t / sec)
    env = np.minimum(1, t / 0.04) * np.exp(-t / (sec * 0.8))
    x = _voice(f0, [(700, 300, 1.0), (1250, 400, 0.9), (2700, 500, 0.3)], env, breath=0.1, rng=rng)
    x *= (0.75 + 0.25 * np.sin(2 * math.pi * 28 * t)).astype(np.float32)   # bleaty flutter
    return _fade(_norm(x, 0.75))


def _hen(rng, kind="idle"):
    parts = []
    count = 3 if kind == "idle" else 1
    for i in range(count):
        sec = 0.07
        f = _glide(rng.uniform(850, 950), rng.uniform(520, 600), sec)
        n = len(f)
        x = _voice(f, [(1700, 600, 1.0), (900, 300, 0.5)], _env(n, 0.004, 0.035), nharm=14)
        parts.append(x)
        parts.append(np.zeros(int(0.06 * SR), np.float32))
    x = np.concatenate(parts)
    if kind == "death":
        x = _voice(_glide(800, 300, 0.4), [(1500, 600, 1.0)], _env(int(0.4 * SR), 0.004, 0.2), nharm=14)
    return _fade(_norm(x, 0.7))


def _shambler(rng, kind="idle"):
    sec = {"idle": 1.0, "hurt": 0.35, "death": 1.1}[kind]
    n = int(sec * SR)
    t = np.arange(n) / SR
    jitter = np.cumsum(rng.normal(0, 0.6, n)) * 0.004
    jitter = jitter - np.convolve(jitter, np.ones(2000) / 2000, "same")
    f0 = (95 - 22 * t / sec) * (1 + jitter) * (1 + 0.02 * np.sin(2 * math.pi * 5 * t))
    if kind == "hurt":
        f0 = f0 * 1.3
    env = np.minimum(1, t / 0.08) * np.exp(-((t - sec * 0.35) / (sec * 0.45)) ** 2)
    x = _voice(f0, [(430, 220, 1.0), (880, 300, 0.7), (2200, 500, 0.15)], env, breath=0.35, rng=rng)
    x = np.tanh(x * 2.2)
    return _fade(_norm(x, 0.8))


def _player_hurt(rng):
    f = _glide(230, 130, 0.22)
    n = len(f)
    x = _voice(f, [(520, 260, 1.0), (1100, 400, 0.6)], _env(n, 0.005, 0.12), breath=0.15, rng=rng)
    return _fade(_norm(x, 0.8))


def _eat(rng):
    parts = []
    for _ in range(3):
        n = int(0.06 * SR)
        parts.append(_bandpass(_noise(n, rng), 500, 3800) * _env(n, 0.001, 0.02) * 1.5)
        parts.append(np.zeros(int(0.07 * SR), np.float32))
    return _fade(_norm(np.concatenate(parts), 0.7))


def _gen_creatures(out, rng):
    for kind in ("idle", "hurt", "death"):
        for i in range(2):
            out[f"boar_{kind}_{i}"] = _boar(rng, kind)
            out[f"woolly_{kind}_{i}"] = _woolly(rng, kind)
            out[f"hen_{kind}_{i}"] = _hen(rng, kind)
            out[f"shambler_{kind}_{i}"] = _shambler(rng, kind)
    out["player_hurt"] = _player_hurt(rng)
    out["player_death"] = _fade(_norm(_voice(_glide(260, 70, 0.8, 0.7),
                                             [(500, 260, 1.0), (1000, 400, 0.5)],
                                             _env(int(0.8 * SR), 0.01, 0.5), breath=0.2, rng=rng), 0.8))
    out["eat"] = _eat(rng)


# ------------------------------------------------------------------- UI / misc ---
def _tone(f, sec, kind="sine", decay=0.08, vol=0.8):
    c = np.full(int(sec * SR), float(f))
    return _osc(c, kind=kind) * _env(len(c), 0.001, decay) * vol


def _gen_ui(out, rng):
    out["click"] = _fade(_tone(1100, 0.05, "square", 0.02, 0.5) + _tone(660, 0.05, "sine", 0.03, 0.5))
    out["tick"] = _fade(_tone(1500, 0.03, "sine", 0.012, 0.6))
    out["pop"] = _fade(_osc(_glide(500, 1000, 0.09)) * _env(int(0.09 * SR), 0.001, 0.04) * 0.7)
    out["levelup"] = _fade(_norm(np.concatenate([_tone(f, 0.12, "tri", 0.1) for f in (523, 659, 784, 1046)]), 0.7))
    out["door"] = _hit("wood", 0.2, rng)
    out["fall"] = _fade(_norm(_lowpass(_noise(int(0.3 * SR), rng), 500) * _env(int(0.3 * SR), 0.001, 0.08), 0.9))


# --------------------------------------------------------------- soundboard ------
def _gen_soundboard(out, rng):
    # airhorn
    n = int(1.1 * SR)
    t = np.arange(n) / SR
    f = 392 * (1 + 0.004 * np.sin(2 * math.pi * 6 * t))
    horn = np.zeros(n, np.float32)
    for k, a in ((1, 1.0), (2, 0.8), (3, 0.6), (4, 0.4), (5, 0.3), (6, 0.2)):
        horn += a * np.sin(2 * math.pi * k * np.cumsum(f) / SR)
    horn += 0.9 * np.sin(2 * math.pi * np.cumsum(f * 1.5) / SR)
    horn = np.tanh(horn * 0.9) * np.minimum(1, t / 0.02) * np.minimum(1, (1.1 - t) / 0.1)
    out["sb_airhorn"] = _norm(horn.astype(np.float32), 0.8)
    # laser
    out["sb_laser"] = _fade(_osc(_glide(2400, 200, 0.28, 0.7), kind="saw") * _env(int(0.28 * SR), 0.001, 0.2) * 0.6)
    # coin
    out["sb_coin"] = _fade(np.concatenate([_tone(988, 0.07, "square", 0.2, 0.45), _tone(1319, 0.35, "square", 0.12, 0.45)]))
    # power-up (arpeggio)
    out["sb_powerup"] = _fade(np.concatenate([_tone(f, 0.07, "square", 0.08, 0.4)
                                              for f in (262, 330, 392, 523, 659, 784, 1046)]))
    # sad trombone
    notes = [(233, 0.5), (220, 0.5), (208, 0.5), (196, 1.1)]
    parts = []
    for i, (f, d) in enumerate(notes):
        n = int(d * SR)
        t = np.arange(n) / SR
        fr = f * (1 + (0.03 * np.sin(2 * math.pi * 5 * t) if i == 3 else 0))
        if i == 3:
            fr = fr * (1 - 0.06 * t / d)
        s = _osc(fr, kind="saw") * 0.6 + _osc(fr * 2, kind="tri") * 0.2
        s = _lowpass(s, 1400) * np.minimum(1, t / 0.04) * np.minimum(1, (d - t) / 0.06)
        parts.append(s.astype(np.float32))
    out["sb_sadhorn"] = _norm(np.concatenate(parts), 0.75)
    # drum roll + cymbal
    n = int(1.4 * SR)
    t = np.arange(n) / SR
    roll = np.zeros(n, np.float32)
    pos = 0.0
    while pos < 1.1:
        i = int(pos * SR)
        m = min(int(0.05 * SR), n - i)
        roll[i:i + m] += _lowpass(_noise(m, rng), 1800) * _env(m, 0.0005, 0.015) * (0.4 + 0.5 * pos / 1.1)
        pos += 0.045 - 0.02 * (pos / 1.1)
    i = int(1.1 * SR)
    m = n - i
    roll[i:] += _highpass(_noise(m, rng), 4000) * _env(m, 0.001, 0.18) * 0.8
    out["sb_drumroll"] = _norm(roll, 0.8)
    # applause
    n = int(2.0 * SR)
    t = np.arange(n) / SR
    clap = np.zeros(n, np.float32)
    for _ in range(int(2.0 * 140)):
        i = rng.integers(0, n - 300)
        clap[i:i + 260] += _bandpass(_noise(260, rng), 800, 4500) * _env(260, 0.0004, 0.01) * rng.uniform(0.2, 1.0)
    clap *= np.minimum(1, t / 0.3) * np.minimum(1, (2.0 - t) / 0.5)
    out["sb_applause"] = _norm(clap, 0.7)
    # doorbell
    out["sb_doorbell"] = _fade(_norm(np.concatenate([_tone(659, 0.5, "sine", 0.25), _tone(523, 0.8, "sine", 0.4)]) +
                                     np.concatenate([_tone(1318, 0.5, "sine", 0.1) * 0.3, _tone(1046, 0.8, "sine", 0.15) * 0.3]), 0.7))
    # siren
    n = int(1.6 * SR)
    t = np.arange(n) / SR
    f = 700 + 350 * np.sin(2 * math.pi * 1.2 * t)
    out["sb_siren"] = _fade(_osc(f, kind="square") * 0.35 * np.minimum(1, (1.6 - t) / 0.1))
    # wow (vocal sweep)
    n = int(0.9 * SR)
    t = np.arange(n) / SR
    f0 = 180 + 60 * np.sin(math.pi * t / 0.9)
    wow = _voice(f0, [(500, 200, 1.0), (900, 300, 0.4)], np.minimum(1, t / 0.05) * np.minimum(1, (0.9 - t) / 0.2), breath=0.05, rng=rng)
    sweep = np.interp(t, [0, 0.3, 0.6, 0.9], [350, 1800, 600, 400])
    wow = _voice(f0, [(500, 200, 1.0), (900, 300, 0.4)], None)
    gate = np.minimum(1, t / 0.05) * np.minimum(1, (0.9 - t) / 0.2)
    out["sb_wow"] = _fade(_norm(wow * gate, 0.75))
    # bonk
    out["sb_bonk"] = _fade(_norm(_osc(_glide(420, 120, 0.22, 0.4)) * _env(int(0.22 * SR), 0.001, 0.09), 0.85))
    # chime
    out["sb_chime"] = _fade(_norm(sum(_tone(f, 1.6, "sine", 0.5, 0.3) for f in (880, 1320, 1760, 2217)), 0.7))
    # explosion-ish boom
    n = int(1.2 * SR)
    boom = _lowpass(_noise(n, rng), 700, 2) * _env(n, 0.002, 0.3) + _sine(55, 1.2) * _env(n, 0.002, 0.4)
    out["sb_boom"] = _fade(_norm(np.tanh(boom * 2), 0.85))
    # whoosh
    n = int(0.8 * SR)
    t = np.arange(n) / SR
    wz = _noise(n, rng)
    ws = np.zeros(n, np.float32)
    for lo, hi, a in ((300, 900, 1.0), (900, 2500, 0.8), (2500, 6000, 0.4)):
        ws += _bandpass(wz, lo, hi) * a
    ws *= np.sin(math.pi * t / 0.8) ** 2
    out["sb_whoosh"] = _fade(_norm(ws, 0.7))
    # tada fanfare
    out["sb_tada"] = _fade(_norm(np.concatenate([_tone(523, 0.12, "tri", 0.2), _tone(523, 0.12, "tri", 0.2),
                                                 _tone(659, 0.12, "tri", 0.2), _tone(784, 0.7, "tri", 0.4)]) +
                                 np.concatenate([_tone(262, 0.36, "square", 0.2, 0.2), _tone(392, 0.7, "square", 0.4, 0.2)]), 0.75))


SOUNDBOARD_LABELS = {
    "sb_airhorn": "Air horn", "sb_laser": "Laser", "sb_coin": "Coin", "sb_powerup": "Power-up",
    "sb_sadhorn": "Sad horn", "sb_drumroll": "Drum roll", "sb_applause": "Applause",
    "sb_doorbell": "Doorbell", "sb_siren": "Siren", "sb_wow": "Wow", "sb_bonk": "Bonk",
    "sb_chime": "Chime", "sb_boom": "Boom", "sb_whoosh": "Whoosh", "sb_tada": "Ta-da!",
}


# ------------------------------------------------------------------- music -------
SCALES = {
    "dorian": [0, 2, 3, 5, 7, 9, 10],
    "pentatonic": [0, 2, 4, 7, 9],
    "lydian": [0, 2, 4, 6, 7, 9, 11],
    "aeolian": [0, 2, 3, 5, 7, 8, 10],
}


def _piano_note(freq, sec, vel=0.6):
    n = int(sec * SR)
    t = np.arange(n) / SR
    x = np.zeros(n, np.float32)
    for k, a in ((1, 1.0), (2, 0.45), (3, 0.22), (4, 0.12), (5, 0.06)):
        det = 1 + 0.0007 * k * k
        x += a * np.sin(2 * math.pi * freq * k * det * t) * np.exp(-t * (1.1 + 0.9 * k))
    x *= np.minimum(1, t / 0.006)
    return (x * vel).astype(np.float32)


def _music_track(seed, root, scale, sec=48, tempo=0.9):
    r = random.Random(seed)
    n = int(sec * SR)
    mix = np.zeros(n + 6 * SR, np.float32)
    steps = SCALES[scale]
    # slow pad chords
    pos = 0.0
    chord_roots = [0, 3, 4, 2] if scale != "pentatonic" else [0, 2, 3, 1]
    ci = 0
    while pos < sec - 4:
        base = root * 0.5
        deg = chord_roots[ci % len(chord_roots)]
        for off in (0, 2, 4):
            idx = deg + off
            semis = steps[idx % len(steps)] + 12 * (idx // len(steps))
            f = base * 2 ** (semis / 12)
            ln = 7
            nn = int(ln * SR)
            t = np.arange(nn) / SR
            pad = (np.sin(2 * math.pi * f * t) + 0.3 * np.sin(2 * math.pi * f * 2.003 * t)) * 0.07
            pad *= np.minimum(1, t / 1.5) * np.minimum(1, (ln - t) / 2.0)
            i = int(pos * SR)
            mix[i:i + nn] += pad.astype(np.float32)[:len(mix) - i]
        pos += 6.0
        ci += 1
    # sparse piano melody
    pos = 1.0
    deg = r.randrange(len(steps))
    while pos < sec - 3:
        deg = max(0, min(len(steps) * 2 - 1, deg + r.choice([-2, -1, -1, 0, 1, 1, 2, 3])))
        semis = steps[deg % len(steps)] + 12 * (deg // len(steps))
        f = root * 2 ** (semis / 12)
        note = _piano_note(f, 3.2, r.uniform(0.35, 0.7))
        i = int(pos * SR)
        mix[i:i + len(note)] += note[:len(mix) - i]
        pos += r.choice([0.9, 1.2, 1.8, 2.4, 3.0]) * tempo
    mix = _echo(mix, 0.33, 0.38, 3)[:n + 4 * SR]
    mix = _lowpass(mix, 4500)
    fade = np.minimum(1, np.arange(len(mix)) / (2 * SR)) * np.minimum(1, (len(mix) - np.arange(len(mix))) / (3 * SR))
    return _norm(mix * fade, 0.55)


def _gen_music(out):
    out["music_0"] = _music_track(11, 220.0, "dorian")
    out["music_1"] = _music_track(23, 196.0, "pentatonic", tempo=1.1)
    out["music_2"] = _music_track(37, 261.63, "lydian", tempo=1.0)


# ------------------------------------------------------------------- manager ---------
def ensure_sounds(progress=None):
    """Generate any missing wav files. Returns the directory."""
    d = CACHE_DIR / CACHE_VERSION
    d.mkdir(parents=True, exist_ok=True)
    marker = d / "_complete"
    if marker.exists():
        return d
    rng = np.random.default_rng(2024)
    steps = [("block sounds", _gen_block_sounds), ("creature voices", _gen_creatures),
             ("interface sounds", _gen_ui), ("soundboard", _gen_soundboard)]
    for i, (label, fn) in enumerate(steps):
        bank = {}
        fn(bank, rng)
        for name, arr in bank.items():
            write_wav(d / f"{name}.wav", arr)
        if progress:
            progress(label)
    bank = {}
    _gen_music(bank)
    for name, arr in bank.items():
        write_wav(d / f"{name}.wav", arr)
    if progress:
        progress("music")
    marker.write_text("ok")
    return d


class AudioSystem:
    """Thin, crash-proof wrapper around Panda3D's audio."""

    POOL = 3

    def __init__(self, loader, config):
        self.loader = loader
        self.cfg = config
        self.dir = None
        self.pool = {}
        self.cursor = {}
        self.music = None
        self.music_idx = -1
        self.next_music_at = 12.0
        self.clock = 0.0
        self.ok = True
        self.user_clips = []        # (label, path)
        self.names = set()

    # ---- loading ---------------------------------------------------------------
    def load(self, progress=None):
        try:
            self.dir = ensure_sounds(progress)
            self.names = {p.stem for p in self.dir.glob("*.wav")}
        except Exception as e:
            print("[audio] could not build sounds:", e)
            self.ok = False
        self.scan_user_clips()

    def scan_user_clips(self):
        self.user_clips = []
        d = SOUND_DIR / "soundboard"
        d.mkdir(parents=True, exist_ok=True)
        for p in sorted(d.iterdir()):
            if p.suffix.lower() in (".wav", ".ogg", ".mp3", ".flac"):
                self.user_clips.append((p.stem, p))

    def _sound(self, key, path):
        from panda3d.core import Filename
        lst = self.pool.get(key)
        if lst is None:
            lst = []
            try:
                for _ in range(self.POOL):
                    s = self.loader.load_sfx(Filename.from_os_specific(str(path)))
                    lst.append(s)
            except Exception as e:
                print("[audio] failed to load", path, e)
                lst = []
            self.pool[key] = lst
            self.cursor[key] = 0
        return lst

    # ---- playing -----------------------------------------------------------------
    def volume(self):
        return float(self.cfg.get("master_volume", 0.7))

    def play(self, name, volume=1.0, pitch=1.0, balance=0.0):
        if not self.ok or self.dir is None:
            return
        try:
            if name not in self.names:
                return
            lst = self._sound(name, self.dir / f"{name}.wav")
            if not lst:
                return
            i = self.cursor[name] = (self.cursor[name] + 1) % len(lst)
            s = lst[i]
            s.set_volume(max(0.0, min(1.0, volume * self.volume())))
            s.set_play_rate(pitch)
            s.set_balance(max(-1.0, min(1.0, balance)))
            s.play()
        except Exception as e:
            print("[audio] play error:", e)

    def play_var(self, base, volume=1.0, pitch=None, variants=3, balance=0.0):
        n = random.randrange(variants)
        self.play(f"{base}_{n}", volume, pitch or random.uniform(0.92, 1.08), balance)

    def play_at(self, name, pos, listener, yaw, volume=1.0, variants=1, maxd=26.0):
        dx, dy, dz = pos[0] - listener[0], pos[1] - listener[1], pos[2] - listener[2]
        d = math.sqrt(dx * dx + dy * dy + dz * dz)
        if d > maxd:
            return
        att = (1.0 - d / maxd) ** 1.5
        a = math.radians(yaw)
        right = (math.cos(a), -math.sin(a))
        bal = 0.0
        if d > 0.5:
            bal = (dx * right[0] + dz * right[1]) / d * 0.8
        nm = f"{name}_{random.randrange(variants)}" if variants > 1 else name
        self.play(nm, volume * att, random.uniform(0.95, 1.05), bal)

    def play_file(self, path, volume=1.0):
        if not self.ok:
            return
        try:
            key = "file:" + str(path)
            lst = self._sound(key, path)
            if not lst:
                return
            i = self.cursor[key] = (self.cursor[key] + 1) % len(lst)
            lst[i].set_volume(max(0.0, min(1.0, volume * self.volume())))
            lst[i].play()
        except Exception as e:
            print("[audio] play_file error:", e)

    def stop_all(self):
        for lst in self.pool.values():
            for s in lst:
                try:
                    s.stop()
                except Exception:
                    pass

    # ---- block helpers ---------------------------------------------------------------
    def block_sound(self, kind, material, volume=1.0, balance=0.0):
        m = material if material in ("stone", "dirt", "grass", "sand", "gravel", "wood",
                                      "glass", "leaves", "snow") else "stone"
        self.play_var(f"{kind}_{m}", volume, balance=balance)

    # ---- music ----------------------------------------------------------------------------
    def update(self, dt):
        if not self.ok or self.dir is None:
            return
        self.clock += dt
        want = bool(self.cfg.get("music", True))
        try:
            if self.music is not None:
                self.music.set_volume(self.volume() * 0.55 if want else 0.0)
                if self.music.status() != self.music.PLAYING:
                    self.music = None
                    self.next_music_at = self.clock + random.uniform(25, 70)
            elif want and self.clock >= self.next_music_at:
                self.music_idx = (self.music_idx + 1 + random.randrange(2)) % 3
                from panda3d.core import Filename
                p = self.dir / f"music_{self.music_idx}.wav"
                self.music = self.loader.load_music(Filename.from_os_specific(str(p)))
                self.music.set_volume(self.volume() * 0.55)
                self.music.play()
        except Exception as e:
            print("[audio] music error:", e)
            self.music = None
            self.next_music_at = self.clock + 120

    def music_now(self):
        self.next_music_at = 0.0
