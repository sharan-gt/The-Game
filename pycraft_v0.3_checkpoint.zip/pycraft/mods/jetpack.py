MOD_NAME = "Jetpack"
MOD_VERSION = "1.0"
MOD_AUTHOR = "PyCraft"
MOD_DESC = "Press J to toggle a jetpack: hold SPACE to climb. Works in survival too."

_state = {"on": False}


def _toggle(game):
    _state["on"] = not _state["on"]
    game.say("Jetpack " + ("ON  (hold SPACE)" if _state["on"] else "off"))
    game.audio.play("sb_powerup" if _state["on"] else "click", 0.6)


def _tick(game, dt):
    if _state["on"] and game.player.thrust_held():
        game.player.vel[1] = min(game.player.vel[1] + 60 * dt, 7.5)
        game.player.fall_start = game.player.pos[1]       # no fall damage while flying


def register(api):
    api.add_key("j", _toggle, "toggle jetpack")
    api.on("tick", _tick)
