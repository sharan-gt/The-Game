import sys, os, time, resource, shutil
ROOT = __import__("pathlib").Path(__file__).resolve().parent.parent; sys.path.insert(0, str(ROOT)); os.chdir(ROOT)
from ursina import Ursina, window, held_keys
app = Ursina(title="t", development_mode=False, fullscreen=False, borderless=False, vsync=False,
             size=(640, 400), show_ursina_splash=False, editor_ui_enabled=False)
from game.app import Game
g = Game(app)
while g.state == "boot":
    app.taskMgr.step(); g.tick(1/60)
shutil.rmtree("saves/_trek", ignore_errors=True)
g.start_new_world("_trek", 31337, "survival")
while g.state == "loading":
    app.taskMgr.step(); g.tick(1/60)
g.cfg["auto_performance"] = False
g.set_render_distance(5)
def rss(): return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024
import numpy as np
ms = []
R0 = rss()
x0 = g.player.pos[0]
for n in range(1, 2400):
    g.player.pos[0] += 0.5               # ~30 blocks/s: faster than anyone can fly
    g.player.pos[2] += 0.12
    top = g.world.column_top(int(g.player.pos[0]), int(g.player.pos[2]))
    g.player.pos[1] = max(top, 22) + 3 if top >= 0 else g.player.pos[1]
    g.player.vel = [0, 0, 0]
    t0 = time.perf_counter(); g.tick(1/60); ms.append((time.perf_counter()-t0)*1000)
    if n % 6 == 0: app.taskMgr.step()
    if n % 600 == 0:
        print(f"n={n} x={g.player.pos[0]:.0f} chunks={len(g.world.chunks)} saved={len(g.world.saved)} mobs={len(g.mobs.mobs)} rss={rss():.0f}MB pending_gen={len(g.world._pending_gen)}")
a = np.array(ms)
print(f"tick ms median {np.median(a):.2f} p95 {np.percentile(a,95):.2f} p99 {np.percentile(a,99):.2f} max {a.max():.1f}; >16.7ms: {(a>16.7).sum()}/{len(a)}")
print(f"walked {g.player.pos[0]-x0:.0f} blocks; RSS {R0:.0f} -> {rss():.0f} MB")
