"""
Original mobs (nothing here comes from another game):

  boar      passive, grunts, bolts when hurt
  woolly    passive, bleats
  hen       passive, flutters down slowly
  shambler  hostile, spawns at night and in caves, chases and swipes, is
            weakened by daylight

Models are a few coloured boxes with vertex-colour shading, built once per kind and
instanced. AI + physics run at a fixed 20 Hz (like Minecraft's tick) with render
interpolation, only for mobs near the player, so even 20 mobs cost very little.
"""
import math
import random

from panda3d.core import NodePath

from engine import blocks as B
from engine import physics, render

TICK = 1.0 / 20.0
_PROTO_CACHE = {}

# name: (hp, width, height, walk speed, kind)
SPECS = {
    "boar":     dict(hp=7, w=0.8, h=0.9, speed=1.5, flee=3.2, hostile=False, fall=1.0),
    "woolly":   dict(hp=7, w=0.8, h=1.1, speed=1.2, flee=2.8, hostile=False, fall=1.0),
    "hen":      dict(hp=3, w=0.4, h=0.6, speed=1.1, flee=2.4, hostile=False, fall=0.25),
    "shambler": dict(hp=12, w=0.6, h=1.9, speed=1.05, flee=0.0, hostile=True, fall=1.0),
}
PASSIVE = ("boar", "woolly", "hen")


def _model(kind):
    """-> dict(static=[mesh...], legs=[(pivot, mesh, phase)...], arms=[...])"""
    if kind == "boar":
        fur, dark, snout = (0.76, 0.50, 0.40), (0.52, 0.34, 0.28), (0.90, 0.62, 0.58)
        static = [
            (render.box_mesh((0.66, 0.52, 0.98), fur), (0, 0.38, 0)),
            (render.box_mesh((0.46, 0.42, 0.40), fur), (0, 0.55, 0.62)),
            (render.box_mesh((0.26, 0.2, 0.14), snout), (0, 0.58, 0.88)),
            (render.box_mesh((0.1, 0.07, 0.04), (0.08, 0.05, 0.05)), (-0.12, 0.8, 0.83)),
            (render.box_mesh((0.1, 0.07, 0.04), (0.08, 0.05, 0.05)), (0.12, 0.8, 0.83)),
            (render.box_mesh((0.07, 0.12, 0.06), (0.95, 0.9, 0.78)), (-0.12, 0.62, 0.9)),
            (render.box_mesh((0.07, 0.12, 0.06), (0.95, 0.9, 0.78)), (0.12, 0.62, 0.9)),
            (render.box_mesh((0.16, 0.12, 0.08), dark), (-0.17, 0.9, 0.55)),
            (render.box_mesh((0.16, 0.12, 0.08), dark), (0.17, 0.9, 0.55)),
        ]
        legs = [((x, 0.4, z), render.box_mesh((0.2, 0.4, 0.2), dark, (0, -0.4, 0)), ph)
                for (x, z, ph) in ((-0.2, 0.34, 0), (0.2, 0.34, 1), (-0.2, -0.34, 1), (0.2, -0.34, 0))]
        return dict(static=static, legs=legs, arms=[])
    if kind == "woolly":
        wool, face, dark = (0.93, 0.92, 0.88), (0.34, 0.30, 0.28), (0.40, 0.34, 0.30)
        static = [
            (render.box_mesh((0.84, 0.72, 1.05), wool), (0, 0.46, 0)),
            (render.box_mesh((0.4, 0.44, 0.44), face), (0, 0.8, 0.66)),
            (render.box_mesh((0.5, 0.16, 0.5), wool), (0, 1.18, 0.6)),
            (render.box_mesh((0.1, 0.07, 0.04), (0.95, 0.95, 0.9)), (-0.11, 1.0, 0.89)),
            (render.box_mesh((0.1, 0.07, 0.04), (0.95, 0.95, 0.9)), (0.11, 1.0, 0.89)),
            (render.box_mesh((0.06, 0.06, 0.03), (0.05, 0.05, 0.05)), (-0.11, 1.0, 0.905)),
            (render.box_mesh((0.06, 0.06, 0.03), (0.05, 0.05, 0.05)), (0.11, 1.0, 0.905)),
        ]
        legs = [((x, 0.46, z), render.box_mesh((0.2, 0.46, 0.2), dark, (0, -0.46, 0)), ph)
                for (x, z, ph) in ((-0.24, 0.36, 0), (0.24, 0.36, 1), (-0.24, -0.36, 1), (0.24, -0.36, 0))]
        return dict(static=static, legs=legs, arms=[])
    if kind == "hen":
        feather, comb, beak, leg = (0.96, 0.94, 0.88), (0.85, 0.14, 0.14), (0.95, 0.70, 0.2), (0.9, 0.6, 0.15)
        static = [
            (render.box_mesh((0.38, 0.34, 0.54), feather), (0, 0.26, 0)),
            (render.box_mesh((0.2, 0.3, 0.2), feather), (0, 0.5, 0.3)),
            (render.box_mesh((0.06, 0.1, 0.2), comb), (0, 0.78, 0.3)),
            (render.box_mesh((0.1, 0.06, 0.12), beak), (0, 0.62, 0.45)),
            (render.box_mesh((0.06, 0.1, 0.05), comb), (0, 0.5, 0.42)),
            (render.box_mesh((0.06, 0.22, 0.36), (0.88, 0.85, 0.78)), (-0.21, 0.34, 0.0)),
            (render.box_mesh((0.06, 0.22, 0.36), (0.88, 0.85, 0.78)), (0.21, 0.34, 0.0)),
            (render.box_mesh((0.2, 0.26, 0.1), (0.15, 0.25, 0.3)), (0, 0.4, -0.32)),
            (render.box_mesh((0.05, 0.05, 0.03), (0.05, 0.05, 0.05)), (-0.1, 0.66, 0.405)),
            (render.box_mesh((0.05, 0.05, 0.03), (0.05, 0.05, 0.05)), (0.1, 0.66, 0.405)),
        ]
        legs = [((x, 0.26, 0.0), render.box_mesh((0.06, 0.26, 0.06), leg, (0, -0.26, 0)), ph)
                for (x, ph) in ((-0.1, 0), (0.1, 1))]
        return dict(static=static, legs=legs, arms=[])
    # shambler
    skin, moss, tunic, pants, eye, horn = (0.42, 0.58, 0.38), (0.30, 0.45, 0.25), (0.22, 0.40, 0.50), (0.2, 0.2, 0.42), (1.0, 0.9, 0.2), (0.88, 0.84, 0.7)
    static = [
        (render.box_mesh((0.56, 0.74, 0.3), tunic), (0, 0.78, 0.0)),
        (render.box_mesh((0.5, 0.2, 0.34), moss), (0, 1.3, 0.0)),
        (render.box_mesh((0.5, 0.48, 0.48), skin), (0, 1.5, 0.08)),
        (render.box_mesh((0.1, 0.06, 0.04), eye), (-0.12, 1.72, 0.33)),
        (render.box_mesh((0.1, 0.06, 0.04), eye), (0.12, 1.72, 0.33)),
        (render.box_mesh((0.12, 0.2, 0.12), horn), (-0.17, 1.96, 0.1)),
        (render.box_mesh((0.12, 0.2, 0.12), horn), (0.17, 1.96, 0.1)),
        (render.box_mesh((0.28, 0.06, 0.04), (0.15, 0.2, 0.15)), (0, 1.58, 0.33)),
    ]
    legs = [((x, 0.78, 0.0), render.box_mesh((0.26, 0.78, 0.26), pants, (0, -0.78, 0)), ph)
            for (x, ph) in ((-0.15, 0), (0.15, 1))]
    arms = [((x, 1.46, 0.0), render.box_mesh((0.2, 0.74, 0.2), skin, (0, -0.74, 0)), ph)
            for (x, ph) in ((-0.38, 0), (0.38, 1))]
    return dict(static=static, legs=legs, arms=arms)


class Mob:
    def __init__(self, mid, kind, pos, proxy=False):
        sp = SPECS[kind]
        self.id = mid
        self.kind = kind
        self.spec = sp
        self.pos = list(pos)
        self.prev = list(pos)
        self.vel = [0.0, 0.0, 0.0]
        self.yaw = random.uniform(0, 360)
        self.target_yaw = self.yaw
        self.hp = sp["hp"]
        self.on_ground = False
        self.walk = 0.0                 # leg-swing phase
        self.moving = 0.0
        self.think = random.uniform(0.5, 3.0)
        self.wander = 0.0               # seconds left to keep walking
        self.flee_t = 0.0
        self.hurt_t = 0.0
        self.dead_t = 0.0
        self.cool = 0.0
        self.voice_t = random.uniform(4, 12)
        self.age = 0.0
        self.proxy = proxy
        self.net_target = None
        self.root = None
        self.legs = []
        self.arms = []
        self.hit_vel = [0.0, 0.0]


class MobManager:
    def __init__(self, world, renderer, audio, hooks):
        """hooks: dict of callables -> player_pos(), is_night(), hurt_player(dmg, from_pos),
        drop(kind, pos), gamemode(), listener()"""
        self.world = world
        self.r = renderer
        self.audio = audio
        self.h = hooks
        self.mobs = {}
        self.next_id = 1
        self.acc = 0.0
        self.spawn_t = 2.0
        self.enabled = True
        self.net_proxy = False         # joined clients only render what the host sends
        self.protos = _PROTO_CACHE
        if not self.protos:
            self._build_protos()
        world.on_chunk_unload = self._chunk_unloaded

    # ----------------------------------------------------------- models ----
    def _build_protos(self):
        for kind in SPECS:
            m = _model(kind)
            static = []
            for mesh, pos in m["static"]:
                mesh = dict(mesh)
                mesh["pos"] = mesh["pos"] + [pos[0], pos[1], pos[2]]
                static.append(mesh)
            body = render.build_geom_node(render.merge_meshes(static), f"{kind}_body")
            legs = [(piv, render.build_geom_node(mesh, f"{kind}_leg"), ph) for piv, mesh, ph in m["legs"]]
            arms = [(piv, render.build_geom_node(mesh, f"{kind}_arm"), ph) for piv, mesh, ph in m["arms"]]
            self.protos[kind] = (body, legs, arms)

    def _attach(self, mob):
        body, legs, arms = self.protos[mob.kind]
        root = self.r.mob_root.attach_new_node(f"mob{mob.id}")
        root.attach_new_node(body)
        for piv, node, ph in legs:
            holder = root.attach_new_node("leg")
            holder.set_pos(*piv)
            holder.attach_new_node(node)
            mob.legs.append((holder, ph))
        for piv, node, ph in arms:
            holder = root.attach_new_node("arm")
            holder.set_pos(*piv)
            holder.set_p(-80 if mob.kind == "shambler" else 0)
            holder.attach_new_node(node)
            mob.arms.append((holder, ph))
        mob.root = root
        self._place(mob, 1.0)

    # ------------------------------------------------------------ spawn ----
    def spawn(self, kind, pos, mid=None, proxy=False):
        if mid is None:
            mid = self.next_id
            self.next_id += 1
        mob = Mob(mid, kind, pos, proxy)
        self._attach(mob)
        self.mobs[mid] = mob
        return mob

    def remove(self, mid):
        mob = self.mobs.pop(mid, None)
        if mob and mob.root is not None:
            mob.root.remove_node()

    def clear(self):
        for mid in list(self.mobs):
            self.remove(mid)

    def _chunk_unloaded(self, cx, cz):
        for mid in [m.id for m in self.mobs.values()
                    if (int(m.pos[0]) >> 4) == cx and (int(m.pos[2]) >> 4) == cz]:
            self.remove(mid)

    def counts(self):
        p = sum(1 for m in self.mobs.values() if m.kind in PASSIVE)
        return p, len(self.mobs) - p

    def _try_spawn(self):
        w = self.world
        px, py, pz = self.h["player_pos"]()
        passive, hostile = self.counts()
        creative = self.h["gamemode"]() == "creative"
        want_passive = passive < 12
        want_hostile = hostile < 6 and not creative and self.h["is_night"]()
        cave_try = hostile < 4 and not creative
        if not (want_passive or want_hostile or cave_try):
            return
        for _ in range(4):
            ang = random.uniform(0, math.tau)
            dist = random.uniform(20, 42)
            x = int(px + math.cos(ang) * dist)
            z = int(pz + math.sin(ang) * dist)
            top = w.column_top(x, z)
            if top < 0:
                continue
            under = w.get_block(x, top, z)
            if w.get_block(x, top + 1, z) != B.AIR or w.get_block(x, top + 2, z) != B.AIR:
                continue
            pos = (x + 0.5, top + 1.0, z + 0.5)
            if want_passive and under in (B.GRASS, B.SNOW_GRASS) and random.random() < 0.6:
                kind = random.choice(PASSIVE)
                herd = 1 if kind == "hen" else random.choice((1, 2, 2, 3))
                for i in range(herd):
                    jx, jz = random.uniform(-1.5, 1.5), random.uniform(-1.5, 1.5)
                    hy = w.column_top(int(pos[0] + jx), int(pos[2] + jz))
                    if hy > 0 and w.get_block(int(pos[0] + jx), hy + 1, int(pos[2] + jz)) == B.AIR:
                        self.spawn(kind, (pos[0] + jx, hy + 1.0, pos[2] + jz))
                return
            if want_hostile and under not in (B.WATER, B.LEAVES):
                self.spawn("shambler", pos)
                return
        if cave_try:
            for _ in range(6):
                ang = random.uniform(0, math.tau)
                dist = random.uniform(14, 34)
                x = int(px + math.cos(ang) * dist)
                z = int(pz + math.sin(ang) * dist)
                top = w.column_top(x, z)
                if top < 12:
                    continue
                y = random.randint(4, top - 5)
                if (w.get_block(x, y, z) == B.AIR and w.get_block(x, y + 1, z) == B.AIR
                        and w.is_solid(x, y - 1, z) and w.get_block(x, y - 1, z) != B.WATER):
                    self.spawn("shambler", (x + 0.5, y, z + 0.5))
                    return

    # --------------------------------------------------------------- update ----
    def update(self, dt):
        if not self.enabled:
            return
        if self.net_proxy:
            for m in self.mobs.values():
                self._proxy_update(m, dt)
            return
        self.acc += min(dt, 0.1)
        ticked = False
        while self.acc >= TICK:
            self.acc -= TICK
            self._tick(TICK)
            ticked = True
        alpha = self.acc / TICK
        ppos = self.h["player_pos"]()
        for m in self.mobs.values():
            if abs(m.pos[0] - ppos[0]) + abs(m.pos[2] - ppos[2]) < 90:
                self._place(m, alpha)
        self.spawn_t -= dt
        if self.spawn_t <= 0:
            self.spawn_t = 1.5
            self._try_spawn()

    def _tick(self, dt):
        px, py, pz = self.h["player_pos"]()
        night = self.h["is_night"]()
        dead = []
        for m in list(self.mobs.values()):
            m.prev[0], m.prev[1], m.prev[2] = m.pos
            dx, dz = m.pos[0] - px, m.pos[2] - pz
            d2 = dx * dx + dz * dz
            if d2 > 110 * 110 or (m.spec["hostile"] and d2 > 70 * 70):
                dead.append(m.id)
                continue
            if d2 > 56 * 56:          # frozen when far (keeps the tick cheap)
                continue
            if m.dead_t > 0:
                m.dead_t += dt
                if m.dead_t > 0.9:
                    dead.append(m.id)
                continue
            self._ai(m, dt, px, py, pz, night, d2)
        for mid in dead:
            self.remove(mid)

    def _ai(self, m, dt, px, py, pz, night, d2):
        sp = m.spec
        w = self.world
        m.age += dt
        m.hurt_t = max(0.0, m.hurt_t - dt)
        m.cool = max(0.0, m.cool - dt)
        m.voice_t -= dt
        speed = 0.0
        if m.flee_t > 0:
            m.flee_t -= dt
        if not w.loaded_around(m.pos[0], m.pos[2], 0):
            return

        if sp["hostile"]:
            # daylight weakens shamblers that are standing in the open
            if not night and w.column_top(int(math.floor(m.pos[0])), int(math.floor(m.pos[2]))) < m.pos[1] \
                    and int(m.age * 20) % 20 == 0:
                self.damage(m, 1, None)
                if m.dead_t > 0:
                    return
            dist = math.sqrt(d2)
            if dist < 18 and self.h["gamemode"]() == "survival":
                m.target_yaw = math.degrees(math.atan2(px - m.pos[0], pz - m.pos[2]))
                speed = sp["speed"] * 2.1
                if dist < 1.35 and m.cool <= 0 and abs(py - m.pos[1]) < 1.6:
                    m.cool = 1.0
                    self.h["hurt_player"](3, (m.pos[0], m.pos[1], m.pos[2]))
                    m.vel[0] -= math.sin(math.radians(m.yaw)) * 1.5
                    m.vel[2] -= math.cos(math.radians(m.yaw)) * 1.5
            else:
                speed = self._wander(m, dt, sp)
        else:
            if m.flee_t > 0:
                speed = sp["flee"]
            else:
                speed = self._wander(m, dt, sp)

        # turn toward the wanted heading
        diff = (m.target_yaw - m.yaw + 180) % 360 - 180
        m.yaw += max(-420 * dt, min(420 * dt, diff * min(1.0, 12 * dt)))
        fx, fz = math.sin(math.radians(m.yaw)), math.cos(math.radians(m.yaw))
        # horizontal velocity eases toward the walk vector (knockback decays naturally)
        k = min(1.0, 9 * dt)
        m.vel[0] += (fx * speed - m.vel[0]) * k
        m.vel[2] += (fz * speed - m.vel[2]) * k

        in_water = w.is_water(int(math.floor(m.pos[0])), int(math.floor(m.pos[1] + 0.3)), int(math.floor(m.pos[2])))
        if in_water:
            m.vel[1] = min(m.vel[1] + 30 * dt, 2.2)
        else:
            g = 28.0 * sp["fall"] if m.vel[1] < 0 else 28.0
            m.vel[1] = max(m.vel[1] - g * dt, -30.0)
        og, hx, hz, _ = physics.move(w, m.pos, m.vel, dt, sp["w"] / 2, sp["h"])
        m.on_ground = og
        if (hx or hz) and og and speed > 0:
            m.vel[1] = 8.2                    # hop over one-block ledges
        sp2 = math.hypot(m.vel[0], m.vel[2])
        m.moving += (min(1.0, sp2 / 1.4) - m.moving) * min(1.0, 10 * dt)
        m.walk += sp2 * dt * 2.6
        if m.pos[1] < -8:
            m.hp = 0
            m.dead_t = 0.01

        if m.voice_t <= 0:
            m.voice_t = random.uniform(7, 16)
            if d2 < 22 * 22:
                self._voice(m, "idle")

    def _wander(self, m, dt, sp):
        m.think -= dt
        if m.think <= 0:
            if random.random() < 0.55:
                m.wander = random.uniform(1.5, 4.5)
                m.target_yaw = random.uniform(0, 360)
            else:
                m.wander = 0.0
            m.think = random.uniform(2.0, 6.0)
        if m.wander > 0:
            m.wander -= dt
            # don't walk off cliffs / into the sea on purpose
            ahead_x = m.pos[0] + math.sin(math.radians(m.target_yaw)) * 1.0
            ahead_z = m.pos[2] + math.cos(math.radians(m.target_yaw)) * 1.0
            ay = int(math.floor(m.pos[1]))
            if self.world.is_water(int(math.floor(ahead_x)), ay - 1, int(math.floor(ahead_z))) \
                    or (not self.world.is_solid(int(math.floor(ahead_x)), ay - 1, int(math.floor(ahead_z)))
                        and not self.world.is_solid(int(math.floor(ahead_x)), ay - 2, int(math.floor(ahead_z)))
                        and not self.world.is_solid(int(math.floor(ahead_x)), ay - 3, int(math.floor(ahead_z)))):
                m.wander = 0
                m.target_yaw = m.yaw + random.uniform(120, 240)
                return 0.0
            return sp["speed"]
        return 0.0

    def _voice(self, m, kind):
        pp = self.h["player_pos"]()
        name = f"{m.kind}_{kind}"
        lis, yaw = self.h["listener"]()
        self.audio.play_at(name, (m.pos[0], m.pos[1] + 0.8, m.pos[2]), lis, yaw,
                           volume=0.9, variants=2)

    # ------------------------------------------------------------- combat ----
    def damage(self, m, amount, from_pos, knock=1.0):
        if m.dead_t > 0:
            return False
        m.hp -= amount
        m.hurt_t = 0.3
        if from_pos is not None:
            dx, dz = m.pos[0] - from_pos[0], m.pos[2] - from_pos[2]
            n = math.hypot(dx, dz) or 1.0
            m.vel[0] += dx / n * 6.5 * knock
            m.vel[2] += dz / n * 6.5 * knock
            m.vel[1] = 5.0
            if not m.spec["hostile"]:
                m.flee_t = 4.0
                m.target_yaw = math.degrees(math.atan2(dx, dz)) + random.uniform(-40, 40)
        if m.hp <= 0:
            m.dead_t = 0.01
            self._voice(m, "death")
            self.h["drop"](m.kind, (m.pos[0], m.pos[1] + 0.5, m.pos[2]))
        else:
            self._voice(m, "hurt")
        return True

    def pick(self, origin, direction, max_dist=5.0):
        best = None
        ox, oy, oz = origin
        dx, dy, dz = direction
        for m in self.mobs.values():
            if m.dead_t > 0:
                continue
            hw, h = m.spec["w"] / 2 + 0.05, m.spec["h"]
            lo = (m.pos[0] - hw, m.pos[1], m.pos[2] - hw)
            hi = (m.pos[0] + hw, m.pos[1] + h, m.pos[2] + hw)
            tmin, tmax = 0.0, max_dist
            ok = True
            for o, d, l, u in ((ox, dx, lo[0], hi[0]), (oy, dy, lo[1], hi[1]), (oz, dz, lo[2], hi[2])):
                if abs(d) < 1e-9:
                    if o < l or o > u:
                        ok = False
                        break
                else:
                    t1, t2 = (l - o) / d, (u - o) / d
                    if t1 > t2:
                        t1, t2 = t2, t1
                    tmin, tmax = max(tmin, t1), min(tmax, t2)
                    if tmin > tmax:
                        ok = False
                        break
            if ok and (best is None or tmin < best[1]):
                best = (m, tmin)
        return best

    # ---------------------------------------------------------- rendering ----
    def _place(self, m, alpha):
        if m.root is None:
            return
        x = m.prev[0] + (m.pos[0] - m.prev[0]) * alpha
        y = m.prev[1] + (m.pos[1] - m.prev[1]) * alpha
        z = m.prev[2] + (m.pos[2] - m.prev[2]) * alpha
        r = m.root
        r.set_pos(x, y, z)
        r.set_h(m.yaw)
        if m.dead_t > 0:
            t = min(1.0, m.dead_t / 0.5)
            r.set_r(90 * t)
            r.set_color_scale(1, 0.45, 0.45, 1)
        elif m.hurt_t > 0:
            r.set_color_scale(1, 0.4, 0.4, 1)
        else:
            r.set_color_scale(1, 1, 1, 1)
        sw = math.sin(m.walk) * 38 * m.moving
        for holder, ph in m.legs:
            holder.set_p(sw if ph == 0 else -sw)
        for holder, ph in m.arms:
            base = -80 if m.kind == "shambler" else 0
            holder.set_p(base + (math.sin(m.walk) * 10 if ph == 0 else -math.sin(m.walk) * 10) * m.moving)
        if m.kind == "hen" and not m.on_ground:
            for holder, ph in m.legs:
                holder.set_p(40)

    # ---------------------------------------------------------- networking ----
    def snapshot(self):
        return [[m.id, m.kind, round(m.pos[0], 2), round(m.pos[1], 2), round(m.pos[2], 2),
                 round(m.yaw, 1), 1 if m.dead_t > 0 else 0, 1 if m.hurt_t > 0 else 0]
                for m in self.mobs.values() if m.dead_t == 0]

    def apply_snapshot(self, snap):
        seen = set()
        for mid, kind, x, y, z, yaw, dead, hurt in snap:
            if kind not in SPECS:
                continue
            seen.add(mid)
            m = self.mobs.get(mid)
            if m is None:
                m = self.spawn(kind, (x, y, z), mid=mid, proxy=True)
            m.net_target = (x, y, z, yaw)
            if hurt:
                m.hurt_t = 0.25
        for mid in [i for i in self.mobs if i not in seen]:
            self.remove(mid)

    def _proxy_update(self, m, dt):
        if m.net_target is None:
            return
        tx, ty, tz, tyaw = m.net_target
        k = min(1.0, 12 * dt)
        ox, oz = m.pos[0], m.pos[2]
        m.pos[0] += (tx - m.pos[0]) * k
        m.pos[1] += (ty - m.pos[1]) * k
        m.pos[2] += (tz - m.pos[2]) * k
        m.prev[:] = m.pos
        d = (tyaw - m.yaw + 180) % 360 - 180
        m.yaw += d * k
        sp = math.hypot(m.pos[0] - ox, m.pos[2] - oz) / max(dt, 1e-3)
        m.moving += (min(1.0, sp / 1.4) - m.moving) * min(1.0, 10 * dt)
        m.walk += sp * dt * 2.6
        m.hurt_t = max(0.0, m.hurt_t - dt)
        m.on_ground = True
        self._place(m, 1.0)
