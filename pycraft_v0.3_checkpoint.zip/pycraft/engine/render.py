"""
Rendering helpers: numpy mesh -> Panda3D geometry, texture atlas, shader presets,
fog/sun, sky bodies, selection outline, simple box meshes for mobs/particles.

Each chunk is at most TWO draw calls (opaque+cutout, water). Geometry is built
straight from numpy buffers (no per-vertex Python), which is what removes the
multi-hundred-millisecond stalls Ursina's Mesh class causes.
"""
import numpy as np
from panda3d.core import (
    CardMaker, Fog, Geom, GeomLinestrips, GeomNode, GeomTriangles, GeomVertexArrayFormat,
    GeomVertexData, GeomVertexFormat, InternalName, LineSegs, NodePath, SamplerState,
    Shader, Texture, TransparencyAttrib, Vec2, Vec3, Vec4, ColorBlendAttrib,
)

from engine import meshing

_REC = np.dtype([("p", "<f4", 3), ("t", "<f4", 2), ("c", "u1", 4)])
_FMT = None


def _vertex_format():
    global _FMT
    if _FMT is None:
        arr = GeomVertexArrayFormat()
        arr.add_column(InternalName.get_vertex(), 3, Geom.NT_float32, Geom.C_point)
        arr.add_column(InternalName.get_texcoord(), 2, Geom.NT_float32, Geom.C_texcoord)
        arr.add_column(InternalName.get_color(), 4, Geom.NT_uint8, Geom.C_color)
        fmt = GeomVertexFormat()
        fmt.add_array(arr)
        _FMT = GeomVertexFormat.register_format(fmt)
        assert _FMT.get_array(0).get_stride() == _REC.itemsize, \
            f"vertex stride {_FMT.get_array(0).get_stride()} != {_REC.itemsize}"
    return _FMT


def build_geom_node(mesh, name="mesh"):
    """mesh: dict(pos float32 (n,3), uv float32 (n,2), col uint8 (n,4), idx uint32)."""
    n = len(mesh["pos"])
    rec = np.empty(n, _REC)
    rec["p"] = mesh["pos"]
    rec["t"] = mesh["uv"]
    rec["c"] = mesh["col"]
    vdata = GeomVertexData(name, _vertex_format(), Geom.UH_static)
    vdata.unclean_set_num_rows(n)
    vdata.modify_array(0).modify_handle().copy_data_from(rec)
    prim = GeomTriangles(Geom.UH_static)
    idx = mesh["idx"]
    if n < 65535:
        prim.set_index_type(Geom.NT_uint16)
        idx = idx.astype(np.uint16)
    else:
        prim.set_index_type(Geom.NT_uint32)
        idx = idx.astype(np.uint32)
    va = prim.modify_vertices()
    va.unclean_set_num_rows(len(idx))
    va.modify_handle().copy_data_from(idx)
    geom = Geom(vdata)
    geom.add_primitive(prim)
    node = GeomNode(name)
    node.add_geom(geom)
    return node


def box_mesh(size, rgb, offset=(0, 0, 0), shades=True):
    """Axis-aligned box centred on x/z with its bottom at y=0 (+offset)."""
    w, h, d = size
    ox, oy, oz = offset
    pos, col, idx, uv = [], [], [], []
    for name, nrm, corners, sel, shade in meshing.FACES:
        b = len(pos)
        for cx, cy, cz in corners:
            pos.append(((cx - 0.5) * w + ox, cy * h + oy, (cz - 0.5) * d + oz))
            s = shade if shades else 1.0
            col.append((int(rgb[0] * s * 255), int(rgb[1] * s * 255), int(rgb[2] * s * 255), 255))
            uv.append((0.0, 0.0))
        idx += [b, b + 2, b + 1, b, b + 3, b + 2]
    return {"pos": np.array(pos, np.float32), "uv": np.array(uv, np.float32),
            "col": np.array(col, np.uint8), "idx": np.array(idx, np.uint32)}


def merge_meshes(meshes):
    pos = np.concatenate([m["pos"] for m in meshes])
    uv = np.concatenate([m["uv"] for m in meshes])
    col = np.concatenate([m["col"] for m in meshes])
    idx, off = [], 0
    for m in meshes:
        idx.append(m["idx"] + off)
        off += len(m["pos"])
    return {"pos": pos, "uv": uv, "col": col, "idx": np.concatenate(idx).astype(np.uint32)}


# ---------------------------------------------------------------- shaders ----
_VERT = """#version 130
uniform mat4 p3d_ModelViewProjectionMatrix;
uniform mat4 p3d_ModelViewMatrix;
in vec4 p3d_Vertex;
in vec4 p3d_Color;
in vec2 p3d_MultiTexCoord0;
out vec2 uv;
out vec4 vcol;
out float depth;
void main() {
    gl_Position = p3d_ModelViewProjectionMatrix * p3d_Vertex;
    uv = p3d_MultiTexCoord0;
    vcol = p3d_Color;
    depth = length((p3d_ModelViewMatrix * p3d_Vertex).xyz);
}
"""

_FRAG = """#version 130
uniform sampler2D p3d_Texture0;
uniform vec4 p3d_ColorScale;
uniform vec4 fog_color;
uniform vec2 fog_range;
uniform float sun;
uniform vec2 screen;
in vec2 uv;
in vec4 vcol;
in float depth;
out vec4 p3d_FragColor;

vec3 aces(vec3 x) {
    return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);
}

void main() {
#ifdef MOB
    vec4 t = vec4(1.0);
#else
    vec4 t = texture(p3d_Texture0, uv);
#endif
#ifdef CUTOUT
    if (t.a < 0.5) discard;
#endif
    vec3 lit = vcol.rgb;
    vec3 c = t.rgb * lit * p3d_ColorScale.rgb;
#ifdef MOB
    c *= (0.35 + 0.65 * sun);
#else
    c *= sun;
#endif
#if defined(VIVID) || defined(CINEMATIC)
    float l = dot(c, vec3(0.299, 0.587, 0.114));
    c = mix(vec3(l), c, 1.20);
    vec3 warm = vec3(1.04, 1.00, 0.92);
    vec3 cool = vec3(0.90, 0.96, 1.06);
    c *= mix(cool, warm, clamp(lit.r * 1.15, 0.0, 1.0));
    c = (c - 0.5) * 1.07 + 0.5;
#endif
#ifdef CINEMATIC
    c = aces(c * 1.30);
    c = mix(vec3(dot(c, vec3(0.299, 0.587, 0.114))), c, 1.12);
#endif
    float f = clamp((depth - fog_range.x) / (fog_range.y - fog_range.x), 0.0, 1.0);
    c = mix(c, fog_color.rgb, f * f * (3.0 - 2.0 * f));
    p3d_FragColor = vec4(c, t.a * vcol.a * p3d_ColorScale.a);
}
"""

SHADER_NAMES = ["off", "lite", "vivid", "cinematic"]
SHADER_INFO = {
    "off": "Fixed-function. Fastest and the safest if anything looks wrong.",
    "lite": "Textured + ambient occlusion + fog. Light on the GPU.",
    "vivid": "Richer colour, warm sunlight and cool shade.",
    "cinematic": "Film tone-mapping and a soft vignette.",
}


def _compile(variant, cutout=False, mob=False):
    defines = ""
    if variant == "vivid":
        defines += "#define VIVID\n"
    if variant == "cinematic":
        defines += "#define CINEMATIC\n"
    if cutout:
        defines += "#define CUTOUT\n"
    if mob:
        defines += "#define MOB\n"
    frag = _FRAG.replace("#version 130\n", "#version 130\n" + defines, 1)
    return Shader.make(Shader.SL_GLSL, _VERT, frag)


# ---------------------------------------------------------------- renderer ---
class Renderer:
    def __init__(self, scene, window_size=(1024, 600)):
        self.scene = scene
        self.root = NodePath("world_root")
        self.root.reparent_to(scene)
        self.chunk_root = self.root.attach_new_node("chunks")
        self.water_root = self.root.attach_new_node("water")
        self.mob_root = self.root.attach_new_node("mobs")
        self.fx_root = self.root.attach_new_node("fx")
        self.tex = None
        self.shader_name = "off"
        self.fog = Fog("pycraft_fog")
        self.fog.set_mode(Fog.M_linear)
        self.screen = Vec2(*window_size)
        self._shaders = {}
        self.gl_ok = True
        self._sun = 1.0
        self._fogc = Vec4(0.6, 0.75, 0.95, 1)
        self._fogr = Vec2(40, 70)

        self.cloud_root = self.mob_root.attach_new_node("clouds")
        self.groups = {"solid": [self.chunk_root], "water": [self.water_root],
                       "mob": [self.mob_root]}
        self.water_root.set_transparency(TransparencyAttrib.M_alpha)
        self.water_root.set_depth_write(False)
        self.water_root.set_bin("transparent", 20)
        self.chunk_root.set_transparency(TransparencyAttrib.M_binary)
        self.mob_root.set_transparency(TransparencyAttrib.M_alpha)

    # ---- texture ------------------------------------------------------------
    def set_atlas(self, pil_image):
        from PIL import Image
        w, h = pil_image.size
        flipped = pil_image.transpose(Image.FLIP_TOP_BOTTOM).convert("RGBA")
        tex = Texture("atlas")
        tex.setup_2d_texture(w, h, Texture.T_unsigned_byte, Texture.F_rgba8)
        tex.set_ram_image_as(flipped.tobytes(), "RGBA")
        tex.set_magfilter(SamplerState.FT_nearest)
        tex.set_minfilter(SamplerState.FT_nearest_mipmap_linear)
        tex.set_anisotropic_degree(2)
        tex.set_wrap_u(SamplerState.WM_clamp)
        tex.set_wrap_v(SamplerState.WM_clamp)
        self.tex = tex
        for g in ("solid", "water"):
            for n in self.groups[g]:
                n.set_texture(tex, 1)

    def add_node(self, group, node):
        """Register an extra node (e.g. the held block) so it gets the same
        texture / shader / fog inputs as the rest of its group."""
        self.groups[group].append(node)
        if self.tex is not None and group in ("solid", "water"):
            node.set_texture(self.tex, 1)
        self.set_shader(self.shader_name)
        return node

    def _all_nodes(self):
        for g in self.groups.values():
            g[:] = [n for n in g if not n.is_empty()]      # a removed node must never be touched
            for n in g:
                yield n

    # ---- shader presets -------------------------------------------------------
    def set_shader(self, name):
        if name not in SHADER_NAMES:
            name = "lite"
        self.shader_name = name
        if name == "off":
            for n in self._all_nodes():
                n.clear_shader()
                n.set_shader_off(1)
            self.scene.set_fog(self.fog)
            return
        try:
            if name not in self._shaders:
                self._shaders[name] = {"solid": _compile(name, cutout=True),
                                       "water": _compile(name),
                                       "mob": _compile(name, cutout=True, mob=True)}
            sh = self._shaders[name]
        except Exception as e:                     # compile failure -> safe mode
            print("[shader] compile failed, falling back to fixed-function:", e)
            self.gl_ok = False
            return self.set_shader("off")
        self.scene.clear_fog()
        for g, nodes in self.groups.items():
            for n in nodes:
                n.clear_shader()
                n.set_shader(sh[g], 1)
                n.set_color_scale(1, 1, 1, 1)
        self._push_inputs()

    def _push_inputs(self):
        for n in self._all_nodes():
            n.set_shader_input("screen", self.screen)
            n.set_shader_input("sun", self._sun)
            n.set_shader_input("fog_color", self._fogc)
            n.set_shader_input("fog_range", self._fogr)

    def set_screen_size(self, w, h):
        self.screen = Vec2(w, h)
        self._push_inputs()

    # ---- per-frame environment ---------------------------------------------------
    def set_env(self, sky_rgb, sun, fog_start, fog_end):
        self._sun = 0.22 + 0.78 * sun
        c = Vec4(sky_rgb[0], sky_rgb[1], sky_rgb[2], 1)
        self._fogc = c
        self._fogr = Vec2(fog_start, fog_end)
        self.fog.set_color(c[0], c[1], c[2])
        self.fog.set_linear_range(fog_start, fog_end)
        if self.shader_name == "off":
            s = 0.25 + 0.75 * sun
            for n in self._all_nodes():
                n.set_color_scale(s, s, s, 1)
        else:
            for n in self._all_nodes():
                n.set_shader_input("fog_color", c)
                n.set_shader_input("fog_range", self._fogr)
                n.set_shader_input("sun", self._sun)

    # ---- chunk nodes ---------------------------------------------------------------
    def make_chunk_nodes(self, cx, cz, solid, water, size_x=16, size_z=16):
        s_np = w_np = None
        if solid is not None:
            s_np = self.chunk_root.attach_new_node(build_geom_node(solid, f"c{cx}_{cz}"))
            s_np.set_pos(cx * size_x, 0, cz * size_z)
        if water is not None:
            w_np = self.water_root.attach_new_node(build_geom_node(water, f"w{cx}_{cz}"))
            w_np.set_pos(cx * size_x, 0, cz * size_z)
        return s_np, w_np

    def make_mesh_node(self, mesh, parent=None, name="part"):
        np_ = (parent or self.mob_root).attach_new_node(build_geom_node(mesh, name))
        return np_


# ---------------------------------------------------------------- misc nodes ---
def make_outline():
    ls = LineSegs()
    ls.set_thickness(2.0)
    ls.set_color(0, 0, 0, 0.85)
    e = 0.004
    a, b = -e, 1 + e
    pts = [(a, a, a), (b, a, a), (b, a, b), (a, a, b), (a, a, a),
           (a, b, a), (b, b, a), (b, b, b), (a, b, b), (a, b, a)]
    ls.move_to(*pts[0])
    for p in pts[1:]:
        ls.draw_to(*p)
    for p, q in (((b, a, a), (b, b, a)), ((b, a, b), (b, b, b)), ((a, a, b), (a, b, b))):
        ls.move_to(*p)
        ls.draw_to(*q)
    node = NodePath(ls.create())
    node.set_light_off()
    node.set_shader_off(10)
    node.set_fog_off()
    node.set_transparency(TransparencyAttrib.M_alpha)
    return node


def make_card(size, rgba):
    cm = CardMaker("card")
    cm.set_frame(-size / 2, size / 2, -size / 2, size / 2)
    n = NodePath(cm.generate())
    n.set_color(*rgba)
    n.set_light_off()
    n.set_shader_off(10)
    n.set_fog_off()
    n.set_transparency(TransparencyAttrib.M_alpha)
    n.set_bin("background", 5)
    n.set_depth_write(False)
    n.set_depth_test(False)
    n.set_two_sided(True)
    n.set_billboard_point_eye()
    return n


# ------------------------------------------------------------- sky helpers -----
def make_stars(count=160, radius=95.0, seed=5):
    """A single GeomPoints node of white points on a sphere (1 draw call)."""
    from panda3d.core import GeomPoints
    rng = np.random.default_rng(seed)
    v = rng.normal(size=(count * 2, 3))
    v = v[v[:, 1] > 0.05][:count]                       # upper hemisphere only
    v = v / np.linalg.norm(v, axis=1, keepdims=True) * radius
    br = rng.uniform(150, 255, len(v)).astype(np.uint8)
    rec = np.empty(len(v), _REC)
    rec["p"] = v.astype(np.float32)
    rec["t"] = 0
    rec["c"][:, 0] = br
    rec["c"][:, 1] = br
    rec["c"][:, 2] = br
    rec["c"][:, 3] = 255
    vdata = GeomVertexData("stars", _vertex_format(), Geom.UH_static)
    vdata.unclean_set_num_rows(len(v))
    vdata.modify_array(0).modify_handle().copy_data_from(rec)
    prim = GeomPoints(Geom.UH_static)
    prim.add_consecutive_vertices(0, len(v))
    geom = Geom(vdata)
    geom.add_primitive(prim)
    node = GeomNode("stars")
    node.add_geom(geom)
    n = NodePath(node)
    n.set_render_mode_thickness(2.0)
    n.set_light_off()
    n.set_shader_off(10)
    n.set_fog_off()
    n.set_bin("background", 3)
    n.set_depth_write(False)
    n.set_depth_test(False)
    n.set_transparency(TransparencyAttrib.M_alpha)
    return n


def make_clouds(seed=7, grid=9, cell=12.0, y=0.0):
    """Blocky cloud layer: merged slabs, one draw call. Tiles by moving with the player."""
    rng = np.random.default_rng(seed)
    meshes = []
    h = 2.5
    for i in range(-grid, grid + 1):
        for j in range(-grid, grid + 1):
            if rng.random() < 0.34:
                w = cell * rng.uniform(0.7, 1.5)
                d = cell * rng.uniform(0.6, 1.3)
                m = box_mesh((w, h, d), (1.0, 1.0, 1.0), (i * cell, y, j * cell))
                m["col"][:, 3] = 215
                meshes.append(m)
    node = build_geom_node(merge_meshes(meshes), "clouds")
    return node


def block_cube_mesh(tables, uvt, bid, size=1.0):
    """A textured unit cube for a block id (held item / dropped item), centred on the origin."""
    pos, uv, col, idx = [], [], [], []
    for name, nrm, corners, sel, shade in meshing.FACES:
        tile = int(getattr(tables, sel)[bid])
        u0, v0, u1, v1 = uvt[tile]
        b = len(pos)
        for c, (cu, cv) in zip(corners, ((u0, v0), (u0, v1), (u1, v1), (u1, v0))):
            pos.append(((c[0] - 0.5) * size, (c[1] - 0.5) * size, (c[2] - 0.5) * size))
            uv.append((cu, cv))
            g = int(255 * shade)
            col.append((g, g, g, 255))
        idx += [b, b + 2, b + 1, b, b + 3, b + 2]
    return {"pos": np.array(pos, np.float32), "uv": np.array(uv, np.float32),
            "col": np.array(col, np.uint8), "idx": np.array(idx, np.uint32)}
