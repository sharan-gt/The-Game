"""
AABB-vs-voxel collision. No Panda3D colliders, just integer lookups into the
world's block arrays, which is O(1) per block and very cheap.

Movement is swept per axis in small sub-steps, so a lag spike or a fast fall can
never tunnel through the floor, and the entity ends up flush against the face it hit
(no hovering gap like a "check then refuse" scheme leaves).
"""
import math

EPS = 1e-4
MAX_STEP = 0.35


def _collides(world, x, y, z, hw, h):
    x0 = math.floor(x - hw)
    x1 = math.floor(x + hw - EPS)
    y0 = math.floor(y)
    y1 = math.floor(y + h - EPS)
    z0 = math.floor(z - hw)
    z1 = math.floor(z + hw - EPS)
    solid = world.is_solid
    for bx in range(x0, x1 + 1):
        for bz in range(z0, z1 + 1):
            for by in range(y0, y1 + 1):
                if solid(bx, by, bz):
                    return True
    return False


def _sweep_axis(world, pos, axis, delta, hw, h):
    """Move along one axis; returns (moved_ok, new_value)."""
    if delta == 0.0:
        return True
    hit = False
    steps = max(1, int(math.ceil(abs(delta) / MAX_STEP)))
    d = delta / steps
    for _ in range(steps):
        pos[axis] += d
        if _collides(world, pos[0], pos[1], pos[2], hw, h):
            # snap flush to the block face we ran into
            if axis == 0:
                if d > 0:
                    pos[0] = math.floor(pos[0] + hw) - hw - EPS
                else:
                    pos[0] = math.floor(pos[0] - hw) + 1 + hw + EPS
            elif axis == 1:
                if d > 0:
                    pos[1] = math.floor(pos[1] + h) - h - EPS
                else:
                    pos[1] = math.floor(pos[1]) + 1 + EPS
            else:
                if d > 0:
                    pos[2] = math.floor(pos[2] + hw) - hw - EPS
                else:
                    pos[2] = math.floor(pos[2] - hw) + 1 + hw + EPS
            # still stuck (embedded corner case)? back out fully
            if _collides(world, pos[0], pos[1], pos[2], hw, h):
                pos[axis] -= d
            hit = True
            break
    return not hit


def move(world, pos, vel, dt, hw=0.3, h=1.8):
    """Advance `pos` (list x,y,z) by vel*dt with collision.
    Returns (on_ground, hit_x, hit_z, hit_ceiling)."""
    dt = min(dt, 0.1)
    ok_y = _sweep_axis(world, pos, 1, vel[1] * dt, hw, h)
    on_ground = False
    hit_ceiling = False
    if not ok_y:
        if vel[1] < 0:
            on_ground = True
        else:
            hit_ceiling = True
        vel[1] = 0.0
    elif vel[1] <= 0.0:
        # resting contact test (standing still on the floor)
        if _collides(world, pos[0], pos[1] - 0.02, pos[2], hw, h):
            on_ground = True
    ok_x = _sweep_axis(world, pos, 0, vel[0] * dt, hw, h)
    ok_z = _sweep_axis(world, pos, 2, vel[2] * dt, hw, h)
    if not ok_x:
        vel[0] = 0.0
    if not ok_z:
        vel[2] = 0.0
    return on_ground, (not ok_x), (not ok_z), hit_ceiling


def in_water(world, pos, h=1.8):
    x, z = math.floor(pos[0]), math.floor(pos[2])
    return world.is_water(x, math.floor(pos[1] + 0.4), z), \
        world.is_water(x, math.floor(pos[1] + h * 0.9), z)


def free_spot(world, pos, hw=0.3, h=1.8):
    return not _collides(world, pos[0], pos[1], pos[2], hw, h)
