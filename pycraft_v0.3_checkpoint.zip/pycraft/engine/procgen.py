"""
Original procedurally painted block tiles (no one else's art). Used as the
default pack and as a fallback for any tile a resource pack doesn't supply.
All painters take the tile size S and return an (S,S,4) uint8 RGBA array.
"""
import zlib
import numpy as np


def _rng(name, S):
    return np.random.default_rng(zlib.crc32(f"{name}:{S}".encode()))


def _blobs(S, rng, cell):
    """Smooth-ish low-frequency noise in 0..1 (blocky clumps `cell` px wide)."""
    n = max(2, S // cell + 1)
    small = rng.random((n, n))
    big = np.kron(small, np.ones((cell, cell)))[:S, :S]
    return big


def _speckle(base, var, S, rng, clump=0.0, cell=4):
    base = np.array(base, float)
    n = rng.integers(-var, var + 1, (S, S, 1))
    img = base[None, None, :] + n
    if clump:
        c = (_blobs(S, rng, cell) - 0.5) * 2 * clump
        img = img + c[:, :, None]
    return np.clip(img, 0, 255)


def _rgba(rgb, alpha=255):
    S = rgb.shape[0]
    out = np.empty((S, S, 4), np.uint8)
    out[:, :, :3] = np.clip(rgb, 0, 255).astype(np.uint8)
    out[:, :, 3] = alpha
    return out


def _jag_mask(S, rng, frac, amp=0.12):
    """Mask that is True in the top `frac` of the tile with a ragged edge."""
    edge = (frac + (rng.random(S) - 0.5) * 2 * amp) * S
    y = np.arange(S)[:, None]
    return y < edge[None, :]


# ---------------------------------------------------------------- painters
def grass_top(S):
    r = _rng("grass_top", S)
    return _rgba(_speckle((92, 158, 64), 14, S, r, clump=14))


def dirt(S):
    r = _rng("dirt", S)
    return _rgba(_speckle((123, 87, 60), 13, S, r, clump=12))


def grass_side(S):
    r = _rng("grass_side", S)
    d = _speckle((123, 87, 60), 13, S, r, clump=12)
    g = _speckle((92, 158, 64), 14, S, r, clump=14)
    m = _jag_mask(S, r, 0.26)[:, :, None]
    return _rgba(np.where(m, g, d))


def stone(S):
    r = _rng("stone", S)
    img = _speckle((126, 126, 130), 9, S, r, clump=16, cell=max(3, S // 6))
    cracks = r.random((S, S)) < 0.035
    img[cracks] *= 0.78
    return _rgba(img)


def sand(S):
    r = _rng("sand", S)
    return _rgba(_speckle((219, 207, 160), 8, S, r, clump=6))


def water(S):
    r = _rng("water", S)
    y, x = np.mgrid[0:S, 0:S]
    wave = np.sin((x + y * 0.6) * 2 * np.pi / (S / 2)) * 8
    base = np.array([44, 104 + 0, 196], float)
    img = base[None, None, :] + wave[:, :, None] + r.integers(-4, 5, (S, S, 1))
    out = _rgba(img, 175)
    return out


def log_side(S):
    r = _rng("log_side", S)
    x = np.arange(S)[None, :]
    stripes = (np.sin(x * 2 * np.pi / max(4, S // 4) + r.random() * 6) > 0.4)
    base = np.where(stripes[:, :, None], np.array([88, 66, 40]), np.array([108, 82, 50]))
    img = base + r.integers(-8, 9, (S, S, 1))
    return _rgba(img)


def log_top(S):
    r = _rng("log_top", S)
    y, x = np.mgrid[0:S, 0:S]
    d = np.sqrt((x - S / 2 + .5) ** 2 + (y - S / 2 + .5) ** 2)
    ring = ((d / max(2, S / 10)).astype(int) % 2) == 0
    base = np.where(ring[:, :, None], np.array([160, 124, 80]), np.array([135, 102, 64]))
    edge = (np.minimum(np.minimum(x, S - 1 - x), np.minimum(y, S - 1 - y)) < max(1, S // 10))
    base = np.where(edge[:, :, None], np.array([100, 76, 46]), base)
    return _rgba(base + r.integers(-6, 7, (S, S, 1)))


def leaves(S):
    r = _rng("leaves", S)
    img = _speckle((64, 130, 52), 22, S, r, clump=18, cell=max(2, S // 8))
    holes = r.random((S, S)) < 0.16
    alpha = np.where(holes, 0, 255).astype(np.uint8)
    out = _rgba(img)
    out[:, :, 3] = alpha
    return out


def glass(S):
    out = np.zeros((S, S, 4), np.uint8)
    out[:, :] = (205, 232, 240, 60)
    b = max(1, S // 16)
    out[:b, :] = (225, 240, 245, 255)
    out[-b:, :] = (225, 240, 245, 255)
    out[:, :b] = (225, 240, 245, 255)
    out[:, -b:] = (225, 240, 245, 255)
    for i in range(S // 4, S // 2):                     # diagonal glint
        out[i, i // 1 - S // 4 + b + 1:i - S // 4 + b + 3] = (240, 250, 255, 255)
    return out


def bedrock(S):
    r = _rng("bedrock", S)
    img = _speckle((52, 52, 56), 12, S, r, clump=18, cell=max(2, S // 8))
    light = r.random((S, S)) < 0.06
    img[light] += 28
    return _rgba(img)


def snow(S):
    r = _rng("snow", S)
    return _rgba(_speckle((240, 244, 249), 5, S, r, clump=4))


def snow_side(S):
    r = _rng("snow_side", S)
    d = _speckle((123, 87, 60), 13, S, r, clump=12)
    s = _speckle((240, 244, 249), 5, S, r, clump=4)
    m = _jag_mask(S, r, 0.28)[:, :, None]
    return _rgba(np.where(m, s, d))


def planks(S):
    r = _rng("planks", S)
    h = max(2, S // 4)
    y = np.arange(S)[:, None]
    board = (y // h) % 2
    base = np.where(board[:, :, None] == 0, np.array([178, 140, 86]), np.array([164, 127, 76]))
    img = base + r.integers(-7, 8, (S, S, 1))
    seam = (y % h == 0)
    img = np.where(seam[:, :, None], img * 0.72, img)
    return _rgba(img)


def gravel(S):
    r = _rng("gravel", S)
    img = _speckle((124, 121, 119), 26, S, r, clump=24, cell=max(2, S // 8))
    return _rgba(img)


# ----- derived tiles (built from another tile so they match any pack) --------
def derive_cobble(stone_rgba):
    S = stone_rgba.shape[0]
    r = _rng("cobble", S)
    pts = r.random((max(6, S // 4), 2)) * S
    y, x = np.mgrid[0:S, 0:S]
    d = np.stack([np.minimum(np.abs(x - px), S - np.abs(x - px)) ** 2 +
                  np.minimum(np.abs(y - py), S - np.abs(y - py)) ** 2
                  for px, py in pts], 0)
    srt = np.sort(d, axis=0)
    gap = np.sqrt(srt[1]) - np.sqrt(srt[0])
    crack = gap < max(0.9, S / 18)
    out = stone_rgba.astype(float).copy()
    cell_id = np.argmin(d, 0)
    shade = 0.88 + 0.22 * ((cell_id * 2654435761 % 97) / 97.0)
    out[:, :, :3] *= shade[:, :, None]
    out[:, :, :3][crack] *= 0.5
    out[:, :, 3] = 255
    return np.clip(out, 0, 255).astype(np.uint8)


ORE_COLORS = {"coal_ore": (28, 28, 30), "iron_ore": (214, 172, 140),
              "gold_ore": (250, 232, 70), "diamond_ore": (88, 220, 214)}


def derive_ore(stone_rgba, name):
    S = stone_rgba.shape[0]
    r = _rng(name, S)
    out = stone_rgba.copy()
    col = np.array(ORE_COLORS[name], np.uint8)
    for _ in range(max(3, S // 5)):                     # a few little clusters
        cx, cy = r.integers(2, S - 2, 2)
        for _ in range(r.integers(3, 6)):
            dx, dy = r.integers(-1, 2, 2)
            w = max(1, S // 12)
            x0, y0 = int(cx + dx * w), int(cy + dy * w)
            out[max(0, y0):y0 + w + 1, max(0, x0):x0 + w + 1, :3] = col
    return out


def derive_grass_side(dirt_rgba, grass_rgba):
    S = dirt_rgba.shape[0]
    r = _rng("grass_side_derived", S)
    m = _jag_mask(S, r, 0.26)[:, :, None]
    return np.where(m, grass_rgba, dirt_rgba)


def color_tile(S, rgb, name="mod", glow=False):
    r = _rng(name, S)
    img = _speckle(rgb, 10, S, r, clump=10)
    if glow:
        y, x = np.mgrid[0:S, 0:S]
        d = np.sqrt((x - S / 2 + .5) ** 2 + (y - S / 2 + .5) ** 2) / (S / 2)
        img = img + (1 - np.clip(d, 0, 1))[:, :, None] * 60
        edge = np.minimum(np.minimum(x, S - 1 - x), np.minimum(y, S - 1 - y)) < max(1, S // 12)
        img[edge] *= 0.55
    return _rgba(img)


PAINTERS = {
    "grass_top": grass_top, "dirt": dirt, "grass_side": grass_side,
    "stone": stone, "sand": sand, "water": water, "log_side": log_side,
    "log_top": log_top, "leaves": leaves, "glass": glass, "bedrock": bedrock,
    "snow": snow, "snow_side": snow_side, "planks": planks, "gravel": gravel,
}
