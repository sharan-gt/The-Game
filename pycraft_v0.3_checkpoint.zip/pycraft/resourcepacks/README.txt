Resource packs
==============
resourcepacks/<name>/blocks/<tile>.png   (any square size, ideally 16 / 32 / 64)
resourcepacks/<name>/pack.json           (optional)

Tile names: grass_top grass_side dirt stone sand water log_side log_top leaves glass
bedrock snow snow_side planks gravel coal_ore iron_ore gold_ore diamond_ore cobblestone
(plus any block added by a mod). Missing tiles fall back to the built-in procedural art,
so a pack can replace just a few textures.

pack.json example:
    {"name": "My Pack", "tile_size": 32,
     "opaque_leaves": true,
     "tint": {"grass_top": [0.52, 0.84, 0.30], "leaves": [0.40, 0.72, 0.28]}}

Change packs live in Options -> Resource pack.
