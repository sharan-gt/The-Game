"""Wire format: one JSON object per line over TCP. Chunks travel as zlib+base64."""
import base64
import json
import zlib

import numpy as np

PORT = 25677
DISCOVERY_PORT = 25678
PROTOCOL = 2
MAX_CLIENT_LINE = 64 * 1024
MAX_SERVER_LINE = 64 * 1024 * 1024


def encode(msg):
    return (json.dumps(msg, separators=(",", ":")) + "\n").encode("utf-8")


def pack_chunk(arr):
    return base64.b64encode(zlib.compress(np.ascontiguousarray(arr, np.uint8).tobytes(), 3)).decode("ascii")


def unpack_chunk(s, shape):
    raw = zlib.decompress(base64.b64decode(s))
    a = np.frombuffer(raw, np.uint8)
    if a.size != int(np.prod(shape)):
        raise ValueError("bad chunk payload")
    return a.reshape(shape).copy()


class LineBuffer:
    def __init__(self, limit):
        self.buf = bytearray()
        self.limit = limit

    def feed(self, data):
        """Yields decoded dicts for each complete line; raises ValueError on overflow."""
        self.buf += data
        if len(self.buf) > self.limit and b"\n" not in self.buf:
            raise ValueError("line too long")
        out = []
        while True:
            i = self.buf.find(b"\n")
            if i < 0:
                break
            line = bytes(self.buf[:i])
            del self.buf[:i + 1]
            if not line.strip():
                continue
            try:
                m = json.loads(line)
            except ValueError:
                continue
            if isinstance(m, dict):
                out.append(m)
        return out
