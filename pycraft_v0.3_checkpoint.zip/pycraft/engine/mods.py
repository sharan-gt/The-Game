"""
Mod loader. Drop a .py file (or a folder with mod.py) into mods/ and it is loaded at
startup. A mod looks like this:

    MOD_NAME = "My Mod"
    MOD_VERSION = "1.0"
    MOD_AUTHOR = "you"
    MOD_DESC = "what it does"

    def register(api):
        api.add_block("ruby_block", color=(0.8, 0.1, 0.2), hotbar=True)
        api.add_command("hi", lambda game, args: "hello!", "say hello")
        api.on("tick", lambda game, dt: None)
        api.add_key("j", toggle_something, "toggle something")

Events: start(game) tick(game, dt) block_break(game, pos, block_name)
        block_place(game, pos, block_name) key(game, key) chat(game, text)
        mob_killed(game, kind)

A mod that raises more than 3 errors is switched off for the rest of the session, so
a broken mod can never take the game down.
"""
import importlib.util
import traceback
from pathlib import Path

from engine import blocks as B
from engine.settings import MOD_DIR

EVENTS = ("start", "tick", "block_break", "block_place", "key", "chat", "mob_killed")


class LoadedMod:
    def __init__(self, ident, path):
        self.id = ident
        self.path = path
        self.name = ident
        self.version = "?"
        self.author = "?"
        self.desc = ""
        self.enabled = True
        self.error = None
        self.errors = 0
        self.blocks = []
        self.commands = []
        self.keys = []


class ModAPI:
    def __init__(self, manager, mod):
        self._m = manager
        self._mod = mod

    def add_block(self, name, **kw):
        bid = B.register_mod_block(name, **kw)
        self._mod.blocks.append(name)
        return bid

    def add_command(self, name, func, help=""):
        self._m.commands[name.lower()] = (func, help, self._mod)
        self._mod.commands.append(name)

    def add_key(self, key, func, help=""):
        self._m.keys.setdefault(key, []).append((func, help, self._mod))
        self._mod.keys.append(key)

    def on(self, event, func):
        if event not in EVENTS:
            raise ValueError(f"unknown event {event!r}; choose from {EVENTS}")
        self._m.handlers.setdefault(event, []).append((func, self._mod))

    def log(self, *a):
        print(f"[mod:{self._mod.name}]", *a)


class ModManager:
    def __init__(self, disabled=()):
        self.mods = []
        self.commands = {}
        self.handlers = {}
        self.keys = {}
        self.disabled = set(disabled)

    def load_all(self):
        MOD_DIR.mkdir(parents=True, exist_ok=True)
        entries = []
        for p in sorted(MOD_DIR.iterdir()):
            if p.name.startswith("_") or p.name.startswith("."):
                continue
            if p.suffix == ".py":
                entries.append((p.stem, p))
            elif p.is_dir() and (p / "mod.py").exists():
                entries.append((p.name, p / "mod.py"))
        for ident, path in entries:
            mod = LoadedMod(ident, path)
            self.mods.append(mod)
            if ident in self.disabled:
                mod.enabled = False
                continue
            try:
                spec = importlib.util.spec_from_file_location(f"pycraft_mod_{ident}", path)
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                mod.name = getattr(module, "MOD_NAME", ident)
                mod.version = str(getattr(module, "MOD_VERSION", "?"))
                mod.author = str(getattr(module, "MOD_AUTHOR", "?"))
                mod.desc = str(getattr(module, "MOD_DESC", ""))
                reg = getattr(module, "register", None)
                if reg is None:
                    raise RuntimeError("mod has no register(api) function")
                reg(ModAPI(self, mod))
            except Exception as e:
                mod.error = f"{type(e).__name__}: {e}"
                mod.enabled = False
                print(f"[mods] {ident} failed to load:\n{traceback.format_exc()}")
        return self.mods

    # ---- dispatch (never raises) ----------------------------------------------------
    def _fail(self, mod, e):
        mod.errors += 1
        mod.error = f"{type(e).__name__}: {e}"
        print(f"[mods] error in {mod.name}:\n{traceback.format_exc()}")
        if mod.errors >= 3:
            mod.enabled = False
            print(f"[mods] {mod.name} disabled after repeated errors")

    def fire(self, event, *args):
        for func, mod in self.handlers.get(event, ()):
            if not mod.enabled:
                continue
            try:
                func(*args)
            except Exception as e:
                self._fail(mod, e)

    def key(self, game, key):
        for func, _, mod in self.keys.get(key, ()):
            if not mod.enabled:
                continue
            try:
                func(game)
            except Exception as e:
                self._fail(mod, e)

    def run_command(self, game, name, args):
        ent = self.commands.get(name.lower())
        if ent is None:
            return None
        func, _, mod = ent
        if not mod.enabled:
            return f"mod '{mod.name}' is disabled"
        try:
            r = func(game, args)
            return r if r is not None else ""
        except Exception as e:
            self._fail(mod, e)
            return f"mod error: {e}"
