"""Two-party loopback test: host + client talk, disconnects are detected, nothing blocks."""
import sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from net.server import GameServer
from net.client import GameClient
from net import protocol as P
import numpy as np


def wait(cond, secs=4):
    t0 = time.time()
    while time.time() - t0 < secs:
        if cond(): return True
        time.sleep(0.01)
    return False


def main():
    srv = GameServer(port=25999)
    cli = GameClient("127.0.0.1", 25999, "Alice")
    got = []
    assert wait(lambda: cli.state == "connected")
    evs = []
    assert wait(lambda: evs.extend(srv.poll()) or any(e[0] == "join" for e in evs))
    pid = [e for e in evs if e[0] == "join"][0][1]
    assert [e for e in evs if e[0] == "join"][0][2] == "Alice"
    arr = (np.random.default_rng(1).integers(0, 17, (16, 64, 16))).astype(np.uint8)
    srv.send(pid, {"t": "welcome", "chunk": P.pack_chunk(arr), "n": 1})
    assert wait(lambda: got.extend(cli.poll()) or any(m.get("t") == "welcome" for m in got))
    m = [m for m in got if m["t"] == "welcome"][0]
    assert (P.unpack_chunk(m["chunk"], (16, 64, 16)) == arr).all()
    cli.send({"t": "block", "x": 1, "y": 2, "z": 3, "id": 4})
    evs = []
    assert wait(lambda: evs.extend(srv.poll()) or any(e[0] == "msg" for e in evs))
    assert [e for e in evs if e[0] == "msg"][0][2]["id"] == 4
    # burst of 5000 messages must not block the sender
    t0 = time.time()
    for i in range(5000):
        srv.broadcast({"t": "pos", "i": i})
    assert time.time() - t0 < 1.0
    # client disconnect is noticed by the host
    cli.close()
    evs = []
    assert wait(lambda: evs.extend(srv.poll()) or any(e[0] == "leave" for e in evs)), "leave not detected"
    # host shutdown is noticed by a new client
    cli2 = GameClient("127.0.0.1", 25999, "Bob")
    assert wait(lambda: cli2.state == "connected")
    srv.close()
    assert wait(lambda: cli2.state == "closed", 4), "host close not detected"
    bad = GameClient("127.0.0.1", 25998, "X")
    assert wait(lambda: bad.state == "failed"), bad.state
    print("NET TESTS PASSED")

main()
