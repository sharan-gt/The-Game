"""Player state + movement. No Ursina entities: the camera is placed by the game loop."""
import math

from engine import blocks as B
from engine import physics
from engine.settings import (EYE_HEIGHT, FLY_SPEED, GRAVITY, JUMP_SPEED, PLAYER_HEIGHT,
                             PLAYER_WIDTH, SPRINT_SPEED, TERMINAL_VELOCITY, WALK_SPEED)

HW = PLAYER_WIDTH / 2
FOOD = ("meat",)


class Inputs:
    forward = 0.0
    strafe = 0.0
    jump = False
    sneak = False
    sprint = False
    fly_up = False
    fly_down = False


class Player:
    def __init__(self, game):
        self.game = game
        self.pos = [0.0, 40.0, 0.0]
        self.vel = [0.0, 0.0, 0.0]
        self.yaw = 0.0
        self.pitch = 0.0
        self.on_ground = False
        self.flying = False
        self.sprinting = False
        self.sneaking = False
        self.in_water = False
        self.head_water = False
        self.health = 20.0
        self.dead = False
        self.hurt_cd = 0.0
        self.regen_t = 0.0
        self.fall_start = None
        self.step_dist = 0.0
        self.eye = EYE_HEIGHT
        self.fov_extra = 0.0
        self._jump_cd = 0.0
        self._space_prev = False
        self._space_tap = -9.0
        self._clock = 0.0
        self.hotbar = ["grass", "dirt", "stone", "cobblestone", "log", "planks", "glass", "sand", "leaves"]
        self.selected = 0
        self.items = {}               # survival inventory: name -> count
        self._inp = Inputs()
        self.speed_mult = 1.0

    # ---- helpers ------------------------------------------------------------------
    def eye_pos(self):
        return (self.pos[0], self.pos[1] + self.eye, self.pos[2])

    def look_dir(self):
        y, p = math.radians(self.yaw), math.radians(self.pitch)
        return (math.sin(y) * math.cos(p), -math.sin(p), math.cos(y) * math.cos(p))

    def thrust_held(self):
        return self._inp.jump

    def selected_name(self):
        return self.hotbar[self.selected]

    def reset_motion(self):
        self.vel = [0.0, 0.0, 0.0]
        self.fall_start = None

    # ---- inventory (survival) -------------------------------------------------------
    def count(self, name):
        return self.items.get(name, 0)

    def give(self, name, n=1):
        self.items[name] = self.items.get(name, 0) + n
        if name not in self.hotbar and None in self.hotbar:
            self.hotbar[self.hotbar.index(None)] = name

    def take(self, name, n=1):
        have = self.items.get(name, 0)
        if have < n:
            return False
        self.items[name] = have - n
        if self.items[name] <= 0:
            del self.items[name]
        return True

    # ---- health -----------------------------------------------------------------------
    def hurt(self, dmg, from_pos=None, sound=True):
        if self.dead or self.hurt_cd > 0 or self.game.gamemode == "creative":
            return False
        self.health = max(0.0, self.health - dmg)
        self.hurt_cd = 0.5
        self.regen_t = -6.0
        if from_pos is not None:
            dx, dz = self.pos[0] - from_pos[0], self.pos[2] - from_pos[2]
            n = math.hypot(dx, dz) or 1.0
            self.vel[0] += dx / n * 5.0
            self.vel[2] += dz / n * 5.0
            self.vel[1] = max(self.vel[1], 4.5)
        if sound:
            self.game.audio.play("player_hurt", 0.9)
        self.game.on_player_hurt()
        if self.health <= 0:
            self.dead = True
            self.game.on_player_died()
        return True

    def heal(self, n):
        self.health = min(20.0, self.health + n)

    # ---- the main update ----------------------------------------------------------------
    def update(self, dt, inp):
        self._inp = inp
        w = self.game.world
        dt = min(dt, 0.08)
        self._clock += dt
        self.hurt_cd = max(0.0, self.hurt_cd - dt)
        creative = self.game.gamemode == "creative"
        if not w.loaded_around(self.pos[0], self.pos[2], 0):
            return                                     # wait for the ground to exist
        if self.dead:
            return

        # double-tap space = toggle flight (creative)
        if inp.jump and not self._space_prev and creative:
            if self._clock - self._space_tap < 0.30:
                self.flying = not self.flying
                self.vel[1] = 0.0
                self._space_tap = -9.0
            else:
                self._space_tap = self._clock
        self._space_prev = inp.jump
        if not creative:
            self.flying = False

        feet_wet, head_wet = physics.in_water(w, self.pos, PLAYER_HEIGHT)
        self.in_water, self.head_water = feet_wet, head_wet

        # wish direction in world space
        yaw = math.radians(self.yaw)
        fx, fz = math.sin(yaw), math.cos(yaw)
        rx, rz = math.cos(yaw), -math.sin(yaw)
        wx = fx * inp.forward + rx * inp.strafe
        wz = fz * inp.forward + rz * inp.strafe
        n = math.hypot(wx, wz)
        if n > 0:
            wx, wz = wx / n, wz / n

        self.sneaking = inp.sneak and not self.flying
        want_sprint = inp.sprint and inp.forward > 0 and not self.sneaking
        if want_sprint:
            self.sprinting = True
        elif inp.forward <= 0 or self.sneaking:
            self.sprinting = False

        if self.flying:
            speed = FLY_SPEED * (2.0 if inp.sprint else 1.0)
        elif self.sneaking:
            speed = 1.6
        elif self.sprinting:
            speed = SPRINT_SPEED
        else:
            speed = WALK_SPEED
        if feet_wet and not self.flying:
            speed *= 0.55
        speed *= self.speed_mult

        # horizontal: ease toward the wish velocity (snappy on ground, floaty in air)
        k = (14.0 if self.on_ground else (4.0 if not self.flying else 9.0)) * dt
        k = min(1.0, k)
        self.vel[0] += (wx * speed - self.vel[0]) * k
        self.vel[2] += (wz * speed - self.vel[2]) * k

        # vertical
        if self.flying:
            vy = (inp.fly_up - inp.fly_down) * FLY_SPEED * 0.8 * (1.6 if inp.sprint else 1.0)
            self.vel[1] += (vy - self.vel[1]) * min(1.0, 12 * dt)
            self.fall_start = None
        elif feet_wet:
            self.vel[1] -= GRAVITY * 0.25 * dt
            self.vel[1] *= (1.0 - 2.2 * dt)
            if inp.jump:
                self.vel[1] = min(self.vel[1] + 38 * dt, 3.6)
            self.fall_start = None
        else:
            self.vel[1] = max(self.vel[1] - GRAVITY * dt, TERMINAL_VELOCITY)
            self._jump_cd = max(0.0, self._jump_cd - dt)
            if inp.jump and self.on_ground and self._jump_cd <= 0:
                self.vel[1] = JUMP_SPEED
                self._jump_cd = 0.25
                if self.sprinting:
                    self.vel[0] += wx * 1.2
                    self.vel[2] += wz * 1.2
                self.game.audio.play_var("step_" + self._ground_material(), 0.5, variants=3)

        old = (self.pos[0], self.pos[2])
        was_ground = self.on_ground
        og, hx, hz, hc = physics.move(w, self.pos, self.vel, dt, HW, PLAYER_HEIGHT)
        self.on_ground = og

        # sneaking never walks off an edge
        if self.sneaking and was_ground and not self.flying:
            if not self._supported(self.pos[0], self.pos[1], self.pos[2]):
                if self._supported(old[0], self.pos[1], self.pos[2]):
                    self.pos[0] = old[0]
                    self.vel[0] = 0
                elif self._supported(self.pos[0], self.pos[1], old[1]):
                    self.pos[2] = old[1]
                    self.vel[2] = 0
                else:
                    self.pos[0], self.pos[2] = old
                    self.vel[0] = self.vel[2] = 0

        # fall damage / landing
        if not og and not self.flying and not feet_wet and self.vel[1] < -0.5:
            if self.fall_start is None:
                self.fall_start = self.pos[1]
            self.fall_start = max(self.fall_start, self.pos[1])
        if og:
            if self.fall_start is not None:
                dist = self.fall_start - self.pos[1]
                if dist > 3.0 and not creative:
                    self.hurt(int(dist - 3.0 + 0.999), sound=False)
                    self.game.audio.play("fall", 0.9)
                elif dist > 1.2:
                    self.game.audio.play_var("step_" + self._ground_material(), 0.7, variants=3)
            self.fall_start = None
        elif feet_wet:
            self.fall_start = None
        if feet_wet and not getattr(self, "_was_wet", False):
            self.game.audio.play_var("splash", 0.6, variants=2)
        self._was_wet = feet_wet

        # footsteps
        moved = math.hypot(self.pos[0] - old[0], self.pos[2] - old[1])
        if og and moved > 0 and not self.flying:
            self.step_dist += moved
            stride = 2.5 if self.sprinting else (1.4 if self.sneaking else 1.9)
            if self.step_dist >= stride:
                self.step_dist = 0.0
                self.game.audio.play_var("step_" + self._ground_material(),
                                         0.25 if self.sneaking else 0.4, variants=3)
        elif feet_wet and moved > 0.001:
            self.step_dist += moved
            if self.step_dist >= 1.5:
                self.step_dist = 0.0
                self.game.audio.play_var("swim", 0.35, variants=2)

        # regen
        if not creative and self.health < 20:
            self.regen_t += dt
            if self.regen_t >= 4.0:
                self.regen_t = 0.0
                self.heal(1)
        elif creative:
            self.health = 20.0

        # camera height (sneak) and fov kick (sprint)
        target_eye = EYE_HEIGHT - (0.3 if self.sneaking else 0.0)
        self.eye += (target_eye - self.eye) * min(1.0, 14 * dt)
        target_fov = 9.0 if (self.sprinting and (abs(self.vel[0]) + abs(self.vel[2])) > 3.0) or (self.flying and inp.sprint) else 0.0
        self.fov_extra += (target_fov - self.fov_extra) * min(1.0, 8 * dt)

        # void safety
        if self.pos[1] < -20:
            self.game.respawn_player(void=True)

    def _supported(self, x, y, z):
        return physics._collides(self.game.world, x, y - 0.6, z, HW, 0.5)

    def _ground_material(self):
        w = self.game.world
        bid = w.get_block(int(math.floor(self.pos[0])), int(math.floor(self.pos[1] - 0.2)), int(math.floor(self.pos[2])))
        if bid <= 0:
            return "stone"
        mat = B.get(bid).material
        return mat if mat in ("stone", "dirt", "grass", "sand", "gravel", "wood", "glass", "leaves", "snow") else "stone"
