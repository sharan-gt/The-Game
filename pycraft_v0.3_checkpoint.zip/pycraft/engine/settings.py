"""
Constants + user config (settings.json).

Everything that affects speed on a weak laptop lives here or in settings.json:
  render_distance  - chunks around you (the biggest FPS lever)
  shader           - off | lite | vivid | cinematic
"""
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
USER_DIR = ROOT                       # saves/config live next to the game
SAVE_DIR = USER_DIR / "saves"
CACHE_DIR = USER_DIR / "cache"
SOUND_DIR = USER_DIR / "sounds"
PACK_DIR = ROOT / "resourcepacks"
MOD_DIR = ROOT / "mods"
CONFIG_PATH = USER_DIR / "settings.json"

# ---- world geometry --------------------------------------------------------
CHUNK_X = 16
CHUNK_Z = 16
CHUNK_H = 64
SEA_LEVEL = 22
VERSION = "0.3"
TITLE = "PyCraft"

# ---- player physics (blocks / second) ---------------------------------------
PLAYER_WIDTH = 0.6
PLAYER_HEIGHT = 1.8
EYE_HEIGHT = 1.62
GRAVITY = 28.0
TERMINAL_VELOCITY = -50.0
JUMP_SPEED = 8.7
WALK_SPEED = 4.4
SPRINT_SPEED = 6.4
FLY_SPEED = 11.0
REACH = 6.0

DEFAULTS = {
    "render_distance": 4,
    "fov": 80,
    "mouse_sensitivity": 40,
    "master_volume": 0.7,
    "music": True,
    "resource_pack": "patrix",
    "shader": "lite",
    "gamemode": "creative",       # creative | survival
    "mobs": True,
    "show_debug": False,
    "auto_performance": True,
    "player_name": "Player",
    "last_ip": "127.0.0.1",
    "mods_disabled": [],
}


class Config(dict):
    def __init__(self):
        super().__init__(DEFAULTS)
        try:
            if CONFIG_PATH.exists():
                with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                    data = json.load(f)
                for k, v in data.items():
                    if k in DEFAULTS:
                        self[k] = v
        except Exception as e:                      # corrupt file -> defaults
            print("settings.json unreadable, using defaults:", e)
        if "--safe" in sys.argv:
            self["shader"] = "off"
            self["render_distance"] = min(self["render_distance"], 3)

    def save(self):
        try:
            tmp = str(CONFIG_PATH) + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(dict(self), f, indent=2)
            os.replace(tmp, CONFIG_PATH)
        except Exception as e:
            print("could not save settings:", e)


config = Config()
