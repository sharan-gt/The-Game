"""Walk a long way through new terrain with mobs around; report CPU frame cost and memory."""
import sys, os, time, resource, shutil
ROOT = __import__("pathlib").Path(__file__).resolve().parent.parent; sys.path.insert(0, str(ROOT)); os.chdir(ROOT)
OUT = str(ROOT / "cache")
from ursina import Ursina, window, held_keys
from panda3d.core import Filename
app = Ursina(title="t", development_mode=False, fullscreen=False, borderless=False, vsync=False,
             size=(800, 480), show_ursina_splash=False, editor_ui_enabled=False)
from game.app import Game
g = Game(app)
while g.state == "boot":
    app.taskMgr.step(); g.tick(1/60)
shutil.rmtree("saves/_soak", ignore_errors=True)
g.start_new_world("_soak", 99, "survival")
while g.state == "loading":
    app.taskMgr.step(); g.tick(1/60)
g.cfg["auto_performance"] = False
g.set_render_distance(6)
g.player.pos[1] += 0
held_keys["w"] = 1
held_keys["control"] = 1
def rss(): return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024
tick_ms, step_ms = [], []
R0 = rss(); t_end = time.time() + 60
yaw = 0; n = 0
while time.time() - t_end < 0 and n < 3000:
    n += 1
    if n % 200 == 0: g.player.yaw += 70; g.player.vel[1] = 8.0   # turn + hop over obstacles
    if g.player.pos[1] < 5: g.respawn_player()
    t0 = time.perf_counter(); g.tick(1/60); t1 = time.perf_counter()
    app.taskMgr.step(); t2 = time.perf_counter()
    tick_ms.append((t1-t0)*1000); step_ms.append((t2-t1)*1000)
    if n % 700 == 0:
        print(f"frame {n}: pos {[round(v) for v in g.player.pos]} chunks {len(g.world.chunks)} mobs {len(g.mobs.mobs)} rss {rss():.0f} MB")
import numpy as np
a = np.array(tick_ms)
print(f"game tick ms: median {np.median(a):.2f}  p95 {np.percentile(a,95):.2f}  p99 {np.percentile(a,99):.2f}  max {a.max():.1f}")
print(f"frames over 16.7ms (tick only): {(a>16.7).sum()} / {len(a)};  over 33ms: {(a>33).sum()}")
print(f"RSS start {R0:.0f} MB -> end {rss():.0f} MB   dist walked: {abs(g.player.pos[0])+abs(g.player.pos[2]):.0f}")
print(g.debug_text())
