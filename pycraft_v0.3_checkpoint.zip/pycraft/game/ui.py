"""
Small widget toolkit on top of Ursina entities (camera.ui):
Label, Btn, Cycler, Toggle, TextField, ScrollList, Panel, Bar.

Why custom widgets: Ursina's InputField/Button have quirks (None callbacks,
limit_content_to being overwritten, text scaling with button size). These are tiny,
predictable, and everything is destroyed with its screen -- no leaks.
"""
from ursina import Entity, Text, camera, color, destroy, mouse, application, held_keys
from ursina import time as utime
from ursina.color import Color

BG = Color(0.055, 0.065, 0.085, 1)
PANEL = Color(0.10, 0.115, 0.15, 0.92)
BTN = Color(0.21, 0.235, 0.29, 1)
BTN_HI = Color(0.30, 0.38, 0.52, 1)
BTN_ON = Color(0.22, 0.50, 0.30, 1)
BTN_ON_HI = Color(0.30, 0.62, 0.38, 1)
BTN_RED = Color(0.55, 0.20, 0.20, 1)
BTN_RED_HI = Color(0.70, 0.28, 0.28, 1)
TEXT = Color(0.93, 0.95, 1.0, 1)
DIM = Color(0.62, 0.68, 0.78, 1)
ACCENT = Color(0.45, 0.85, 0.50, 1)
WARN = Color(1.0, 0.82, 0.35, 1)
BAD = Color(1.0, 0.45, 0.45, 1)


def rgba(r, g, b, a=1.0):
    return Color(r, g, b, a)


class Label(Text):
    def __init__(self, parent, text, x=0, y=0, size=1.0, col=TEXT, origin=(0, 0), z=-0.02, **kw):
        super().__init__(text=text, parent=parent, position=(x, y, z), origin=origin,
                         scale=size, color=col, add_to_scene_entities=False, **kw)


class Panel(Entity):
    def __init__(self, parent, x, y, w, h, col=PANEL, z=0.0):
        super().__init__(parent=parent, model='quad', position=(x, y, z), scale=(w, h), color=col)


class Bar:
    """Progress bar (real progress only)."""

    def __init__(self, parent, x, y, w, h=0.018):
        self.w = w
        self.back = Entity(parent=parent, model='quad', position=(x, y, -0.01), scale=(w, h), color=Color(1, 1, 1, 0.12))
        self.fill = Entity(parent=parent, model='quad', origin=(-0.5, 0), position=(x - w / 2, y, -0.02),
                           scale=(0.0001, h), color=ACCENT)
        self.value = 0.0

    def set(self, v):
        self.value = max(0.0, min(1.0, v))
        self.fill.scale_x = max(0.0001, self.w * self.value)


class Btn(Entity):
    def __init__(self, parent, text, x, y, w=0.4, h=0.06, on_click=None, col=BTN, hi=BTN_HI,
                 size=1.05, text_col=TEXT):
        super().__init__(parent=parent, model='quad', position=(x, y, -0.01), scale=(w, h),
                         color=col, collider='box')
        self.base, self.hi = col, hi
        self.cb = on_click
        self.text_col = text_col
        self.label = Label(parent, text, x, y, size, text_col, z=-0.03)
        self.disabled = False

    def set_text(self, t):
        self.label.text = t

    def set_style(self, col, hi):
        self.base, self.hi = col, hi
        self.color = col

    def on_mouse_enter(self):
        if not self.disabled:
            self.color = self.hi

    def on_mouse_exit(self):
        self.color = self.base

    def on_click(self):
        if self.disabled or not self.cb:
            return
        g = _game()
        if g is not None:
            g.audio.play("click", 0.5)
        self.cb()

    def set_disabled(self, v):
        self.disabled = v
        self.label.color = DIM if v else self.text_col
        self.color = Color(self.base.r * 0.6, self.base.g * 0.6, self.base.b * 0.6, 1) if v else self.base


class Toggle(Btn):
    def __init__(self, parent, title, x, y, w, h, get, set_, **kw):
        self.title, self.get, self.set_ = title, get, set_
        super().__init__(parent, "", x, y, w, h, self._flip, **kw)
        self._refresh()

    def _flip(self):
        self.set_(not self.get())
        self._refresh()

    def _refresh(self):
        on = bool(self.get())
        self.label.text = f"{self.title}: {'ON' if on else 'OFF'}"
        self.set_style(BTN_ON if on else BTN, BTN_ON_HI if on else BTN_HI)


class Cycler(Btn):
    """Click to step through values (right-click steps backwards)."""

    def __init__(self, parent, title, x, y, w, h, values, get, set_, fmt=None, **kw):
        self.title, self.values, self.get, self.set_ = title, list(values), get, set_
        self.fmt = fmt or (lambda v: str(v))
        super().__init__(parent, "", x, y, w, h, lambda: self.step(1), **kw)
        self._refresh()

    def step(self, d):
        cur = self.get()
        try:
            i = self.values.index(cur)
        except ValueError:
            i = 0
        self.set_(self.values[(i + d) % len(self.values)])
        self._refresh()

    def input(self, key):
        if key == 'right mouse down' and self.hovered and not self.disabled:
            self.step(-1)
            g = _game()
            if g:
                g.audio.play("click", 0.5)

    def _refresh(self):
        self.label.text = f"{self.title}: {self.fmt(self.get())}"


class TextField(Entity):
    """Single-line text input. Typed characters arrive through the app's keystroke
    event so symbols/shift/layouts all work."""

    def __init__(self, parent, x, y, w, h=0.055, text="", maxlen=24, allowed=None, hint="", on_enter=None):
        super().__init__(parent=parent, model='quad', position=(x, y, -0.01), scale=(w, h),
                         color=Color(0.03, 0.035, 0.05, 1), collider='box')
        self.text, self.maxlen, self.allowed, self.hint = text, maxlen, allowed, hint
        self.on_enter = on_enter
        self.label = Label(parent, "", x - w / 2 + 0.012, y, 1.0, TEXT, origin=(-0.5, 0), z=-0.03)
        self.focused = False
        self._blink = 0.0
        self._render()

    def _render(self):
        if self.text == "" and not self.focused:
            self.label.text = self.hint
            self.label.color = DIM
        else:
            cursor = "|" if self.focused and int(self._blink * 2.5) % 2 == 0 else " "
            self.label.text = self.text + cursor
            self.label.color = TEXT

    def on_click(self):
        g = _game()
        if g is not None:
            g.ui.focus = self
        self.focused = True
        self.color = Color(0.06, 0.07, 0.10, 1)

    def blur(self):
        self.focused = False
        self.color = Color(0.03, 0.035, 0.05, 1)
        self._render()

    def update(self):
        if self.focused:
            self._blink += utime.dt
            self._render()

    def type(self, ch):
        if len(self.text) >= self.maxlen:
            return
        if self.allowed is not None and ch not in self.allowed:
            return
        self.text += ch
        self._render()

    def key(self, key):
        if key in ('backspace', 'backspace hold'):
            self.text = self.text[:-1]
        elif key == 'enter' and self.on_enter:
            self.on_enter(self.text)
        self._render()


class ScrollList:
    """Fixed-height list of selectable rows with arrows + mouse wheel."""

    def __init__(self, parent, x, y, w, rows=6, row_h=0.07, on_select=None):
        self.parent, self.x, self.y, self.w, self.n, self.rh = parent, x, y, w, rows, row_h
        self.items = []
        self.sel = -1
        self.top = 0
        self.on_select = on_select
        self.btns = []
        for i in range(rows):
            b = Btn(parent, "", x, y - i * row_h, w, row_h - 0.008, lambda i=i: self._pick(i),
                    size=0.95)
            b.label.origin = (-0.5, 0)
            b.label.x = x - w / 2 + 0.015
            self.btns.append(b)
        self.up = Btn(parent, "^", x + w / 2 + 0.035, y, 0.05, 0.05, lambda: self.scroll(-1), size=1.0)
        self.dn = Btn(parent, "v", x + w / 2 + 0.035, y - (rows - 1) * row_h, 0.05, 0.05,
                      lambda: self.scroll(1), size=1.0)
        self.empty = Label(parent, "", x, y - row_h * 1.2, 1.0, DIM)

    def set_items(self, items, empty_text=""):
        self.items = list(items)
        self.sel = 0 if self.items else -1
        self.top = 0
        self.empty.text = "" if self.items else empty_text
        self._draw()
        if self.on_select and self.sel >= 0:
            self.on_select(self.sel)

    def _draw(self):
        for i, b in enumerate(self.btns):
            idx = self.top + i
            if idx < len(self.items):
                b.label.text = self.items[idx]
                on = idx == self.sel
                b.set_style(BTN_ON if on else BTN, BTN_ON_HI if on else BTN_HI)
                b.enabled = True
                b.label.enabled = True
            else:
                b.label.text = ""
                b.enabled = False
                b.label.enabled = False
        self.up.enabled = self.up.label.enabled = len(self.items) > self.n
        self.dn.enabled = self.dn.label.enabled = len(self.items) > self.n

    def _pick(self, i):
        idx = self.top + i
        if idx < len(self.items):
            self.sel = idx
            self._draw()
            if self.on_select:
                self.on_select(idx)

    def scroll(self, d):
        self.top = max(0, min(max(0, len(self.items) - self.n), self.top + d))
        self._draw()

    def selected(self):
        return self.sel if 0 <= self.sel < len(self.items) else None


class Screen:
    """A set of widgets under one root; destroy() removes everything."""

    def __init__(self, ui, name=""):
        self.ui = ui
        self.name = name
        self.root = Entity(parent=camera.ui)
        self.fields = []
        self.on_key = None
        self.on_update = None

    def destroy(self):
        if self.ui.focus in self.fields:
            self.ui.focus = None
        destroy(self.root)


def _game():
    from game import app as _a
    return _a.GAME


class UI:
    def __init__(self, game):
        self.game = game
        self.screen = None
        self.focus = None

    def show(self, screen):
        self.clear()
        self.screen = screen
        return screen

    def clear(self):
        if self.screen is not None:
            self.screen.destroy()
            self.screen = None
        self.focus = None

    # keystroke from the app -> focused field
    def keystroke(self, ch):
        if self.focus is not None and ch and ord(ch[0]) >= 32 and ord(ch[0]) != 127:
            self.focus.type(ch)

    def key(self, key):
        """Returns True if the UI consumed the key."""
        if self.focus is not None:
            if key in ('backspace', 'backspace hold', 'enter'):
                self.focus.key(key)
                return True
            if key == 'escape':
                self.focus.blur()
                self.focus = None
                return True
        return False
