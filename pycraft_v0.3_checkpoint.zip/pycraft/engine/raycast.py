"""Voxel ray traversal (Amanatides & Woo). Returns the first non-air, non-water
block along a ray plus the face normal, so we can break / place blocks."""
import math

from engine import blocks as B


def cast(world, origin, direction, max_dist=6.0):
    """-> (hit_block (x,y,z), previous_empty_block (x,y,z), normal (nx,ny,nz), id, distance) or None"""
    ox, oy, oz = origin
    dx, dy, dz = direction
    x, y, z = math.floor(ox), math.floor(oy), math.floor(oz)
    sx = 1 if dx > 0 else -1
    sy = 1 if dy > 0 else -1
    sz = 1 if dz > 0 else -1
    inf = float("inf")
    tdx = abs(1.0 / dx) if dx else inf
    tdy = abs(1.0 / dy) if dy else inf
    tdz = abs(1.0 / dz) if dz else inf
    tmx = ((x + (1 if sx > 0 else 0)) - ox) / dx if dx else inf
    tmy = ((y + (1 if sy > 0 else 0)) - oy) / dy if dy else inf
    tmz = ((z + (1 if sz > 0 else 0)) - oz) / dz if dz else inf
    prev = (x, y, z)
    normal = (0, 0, 0)
    t = 0.0
    get = world.get_block
    while t <= max_dist:
        b = get(x, y, z)
        if b > 0 and b != B.WATER:
            return (x, y, z), prev, normal, b, t
        prev = (x, y, z)
        if tmx < tmy and tmx < tmz:
            x += sx
            t = tmx
            tmx += tdx
            normal = (-sx, 0, 0)
        elif tmy < tmz:
            y += sy
            t = tmy
            tmy += tdy
            normal = (0, -sy, 0)
        else:
            z += sz
            t = tmz
            tmz += tdz
            normal = (0, 0, -sz)
    return None
