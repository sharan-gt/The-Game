import math

MOD_NAME = "Fun Commands"
MOD_VERSION = "1.0"
MOD_AUTHOR = "PyCraft"
MOD_DESC = "Adds /boom [radius], /pillar [height], /ring [radius] and /nuke."


def _boom(game, args):
    r = int(args[0]) if args else 3
    r = max(1, min(r, 6))
    x, y, z = [int(math.floor(v)) for v in (game.player.pos[0], game.player.pos[1], game.player.pos[2])]
    d = game.player.look_dir()
    cx, cy, cz = int(x + d[0] * (r + 3)), int(y + 1 + d[1] * (r + 3)), int(z + d[2] * (r + 3))
    n = 0
    for dx in range(-r, r + 1):
        for dy in range(-r, r + 1):
            for dz in range(-r, r + 1):
                if dx * dx + dy * dy + dz * dz <= r * r + 1:
                    b = game.world.get_block(cx + dx, cy + dy, cz + dz)
                    if b > 0 and b != 9:
                        game.world.set_block(cx + dx, cy + dy, cz + dz, 0)
                        n += 1
    game.audio.play("sb_boom", 1.0)
    return f"boom! removed {n} blocks"


def _pillar(game, args):
    h = int(args[0]) if args else 8
    h = max(1, min(h, 40))
    x, y, z = [int(math.floor(v)) for v in game.player.pos]
    for i in range(h):
        game.world.set_block(x, y + i, z, 3)
    game.player.pos[1] = y + h + 0.1
    return f"built a pillar {h} high"


def _ring(game, args):
    r = int(args[0]) if args else 5
    r = max(2, min(r, 20))
    x, y, z = [int(math.floor(v)) for v in game.player.pos]
    n = 0
    for a in range(0, 360, 2):
        bx = int(round(x + math.cos(math.radians(a)) * r))
        bz = int(round(z + math.sin(math.radians(a)) * r))
        if game.world.get_block(bx, y, bz) == 0:
            game.world.set_block(bx, y, bz, 11)
            n += 1
    return f"placed a ring of {n} planks"


def _nuke(game, args):
    n = 0
    for m in list(game.mobs.mobs.values()):
        game.mobs.damage(m, 999, game.player.pos)
        n += 1
    game.audio.play("sb_boom", 1.0)
    return f"{n} mobs vaporised"


def register(api):
    api.add_command("boom", _boom, "/boom [radius]  blow a hole where you look")
    api.add_command("pillar", _pillar, "/pillar [height]  build a stone pillar under you")
    api.add_command("ring", _ring, "/ring [radius]  plank ring around you")
    api.add_command("nuke", _nuke, "/nuke  kill every mob")
