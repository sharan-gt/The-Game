"""LAN client. connect() runs on a thread so the menu never freezes."""
import queue
import socket
import threading

from net import protocol as P


class GameClient:
    def __init__(self, ip, port=P.PORT, name="Player"):
        self.ip, self.port, self.name = ip, int(port), name
        self.state = "connecting"      # connecting | connected | failed | closed
        self.error = ""
        self.inbox = queue.SimpleQueue()
        self.out = queue.Queue(maxsize=4000)
        self.sock = None
        self.pid = None
        threading.Thread(target=self._run, name="net-client", daemon=True).start()

    def _run(self):
        try:
            s = socket.create_connection((self.ip, self.port), timeout=5)
        except OSError as e:
            self.state, self.error = "failed", f"Can't reach {self.ip}:{self.port} ({e.strerror or e})"
            return
        self.sock = s
        s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        s.settimeout(30)
        self.state = "connected"
        self.out.put(P.encode({"t": "hello", "name": self.name, "proto": P.PROTOCOL}))
        threading.Thread(target=self._writer, name="net-client-w", daemon=True).start()
        lb = P.LineBuffer(P.MAX_SERVER_LINE)
        try:
            while self.state == "connected":
                try:
                    data = s.recv(262144)
                except socket.timeout:
                    continue
                if not data:
                    break
                for m in lb.feed(data):
                    self.inbox.put(m)
        except (OSError, ValueError):
            pass
        finally:
            if self.state == "connected":
                self.state = "closed"
                self.error = self.error or "Connection lost"
            self.inbox.put({"t": "_closed"})

    def _writer(self):
        try:
            while self.state == "connected":
                try:
                    data = self.out.get(timeout=0.5)
                except queue.Empty:
                    continue
                if data is None:
                    break
                self.sock.sendall(data)
        except OSError:
            if self.state == "connected":
                self.state, self.error = "closed", "Connection lost"

    def poll(self):
        out = []
        while True:
            try:
                out.append(self.inbox.get_nowait())
            except queue.Empty:
                return out

    def send(self, msg):
        if self.state != "connected":
            return
        try:
            self.out.put_nowait(P.encode(msg))
        except queue.Full:
            self.state, self.error = "closed", "Connection too slow"

    def close(self):
        was = self.state
        self.state = "closed"
        try:
            self.out.put_nowait(None)
        except queue.Full:
            pass
        if self.sock is not None:
            try:
                self.sock.shutdown(socket.SHUT_RDWR)     # unblock recv() first
            except OSError:
                pass
            try:
                self.sock.close()
            except OSError:
                pass
