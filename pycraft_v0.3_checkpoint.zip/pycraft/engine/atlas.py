"""
Builds the texture atlas from a resource pack.

Why the atlas has padding: with mipmapping, neighbouring tiles bleed into each
other at distance (the shimmering seams you see in naive atlases). Every tile
therefore sits in a power-of-two cell with an edge-replicated border, which
keeps filtering clean down to ~16x minification. Atlas dimensions are also
power-of-two, because Panda3D silently rescales non-power-of-two textures.

Resource pack layout (resourcepacks/<id>/):
    pack.json            {"name", "description", "tile_size", "tint": {tile:[r,g,b]}}
    blocks/<tile>.png    any subset of the tile names; missing ones are painted
                         procedurally so a partial pack never breaks the game.
"""
import json
import math
from pathlib import Path

import numpy as np
from PIL import Image

from engine import procgen
from engine.settings import PACK_DIR, CACHE_DIR


class Atlas:
    def __init__(self):
        self.tile = 16
        self.pad = 8
        self.cell = 32
        self.size = 256
        self.image = None
        self.index = {}
        self.uv = np.zeros((1, 4), np.float32)
        self.avg = {}              # tile name -> (r,g,b) 0..1, for particles
        self.pack_id = "procedural"
        self.pack_name = "Procedural"
        self.tiles = {}            # name -> RGBA uint8 array (kept for icons)


def list_packs():
    packs = ["procedural"]
    if PACK_DIR.exists():
        for d in sorted(PACK_DIR.iterdir()):
            if d.is_dir() and (d / "blocks").is_dir():
                packs.append(d.name)
    return packs


def pack_info(pack_id):
    if pack_id == "procedural":
        return {"name": "Procedural (16x)", "tile_size": 16,
                "description": "Original generated textures."}
    p = PACK_DIR / pack_id / "pack.json"
    info = {"name": pack_id, "tile_size": 0, "description": ""}
    try:
        with open(p, "r", encoding="utf-8") as f:
            info.update(json.load(f))
    except Exception:
        pass
    return info


def _load_png(path, size):
    im = Image.open(path).convert("RGBA")
    if im.width != im.height:                    # animated strips: first frame
        im = im.crop((0, 0, im.width, im.width))
    if im.width != size:
        im = im.resize((size, size), Image.NEAREST)
    return np.array(im, np.uint8)


def _fix_transparent_rgb(a):
    """Give fully transparent pixels the average colour of visible ones so
    mip-mapping doesn't pull black fringes into leaves/glass."""
    if (a[:, :, 3] == 255).all():
        return a
    vis = a[:, :, 3] > 0
    if vis.any():
        avg = a[:, :, :3][vis].mean(axis=0)
        a = a.copy()
        a[:, :, :3][~vis] = avg.astype(np.uint8)
    return a


def build(pack_id, tile_names, extra_tiles=None):
    extra_tiles = extra_tiles or {}
    info = pack_info(pack_id)
    pack_dir = PACK_DIR / pack_id / "blocks"
    if pack_id != "procedural" and not pack_dir.is_dir():
        pack_id, info, pack_dir = "procedural", pack_info("procedural"), None
    elif pack_id == "procedural":
        pack_dir = None

    S = int(info.get("tile_size") or 0)
    if not S and pack_dir is not None:
        for f in sorted(pack_dir.glob("*.png")):
            S = Image.open(f).width
            break
    S = S or 16
    S = max(8, min(128, 1 << int(round(math.log2(S)))))     # power of two

    tint = info.get("tint", {}) if isinstance(info.get("tint"), dict) else {}
    tiles = {}

    def from_pack(name):
        if pack_dir is None:
            return None
        f = pack_dir / f"{name}.png"
        if not f.exists():
            return None
        try:
            a = _load_png(f, S)
        except Exception as e:
            print(f"[pack] could not read {f.name}: {e}")
            return None
        if name in tint:
            m = np.array(tint[name], float)
            a = a.copy()
            a[:, :, :3] = np.clip(a[:, :, :3] * m[None, None, :], 0, 255)
        if name == "leaves" and info.get("opaque_leaves"):
            # sparse leaf sprites look hollow without a backing colour
            a = a.copy()
            vis = a[:, :, 3] > 40
            fill = (a[:, :, :3][vis].mean(axis=0) * 0.55) if vis.any() else (30, 70, 25)
            a[:, :, :3][~vis] = np.array(fill, np.uint8)
            a[:, :, 3] = 255
        return a

    base = ["grass_top", "dirt", "stone", "sand", "water", "log_side",
            "log_top", "leaves", "glass", "bedrock", "snow", "snow_side",
            "planks", "gravel"]
    for name in base:
        a = from_pack(name)
        tiles[name] = a if a is not None else procgen.PAINTERS[name](S)

    a = from_pack("grass_side")
    tiles["grass_side"] = a if a is not None else procgen.derive_grass_side(
        tiles["dirt"], tiles["grass_top"])
    a = from_pack("cobblestone")
    tiles["cobblestone"] = a if a is not None else procgen.derive_cobble(tiles["stone"])
    for ore in procgen.ORE_COLORS:
        a = from_pack(ore)
        tiles[ore] = a if a is not None else procgen.derive_ore(tiles["stone"], ore)

    for name in tile_names:                       # anything else (mods)
        if name in tiles:
            continue
        spec = extra_tiles.get(name)
        a = None
        if isinstance(spec, str):
            try:
                a = _load_png(spec, S)
            except Exception as e:
                print(f"[mod tile] {name}: {e}")
        elif spec is not None:
            a = procgen.color_tile(S, spec, name, glow=True)
        if a is None:
            a = from_pack(name)
        tiles[name] = a if a is not None else procgen.color_tile(S, (200, 80, 200), name)

    # ---- pack into a padded power-of-two atlas ---------------------------
    names = [n for n in tile_names]
    n = len(names)
    cols = 1
    while cols * cols < n:
        cols *= 2
    pad = S // 2
    cell = S + 2 * pad
    size = cols * cell
    atlas = np.zeros((size, size, 4), np.uint8)
    uv = np.zeros((n, 4), np.float32)
    index = {}
    avg = {}
    for i, name in enumerate(names):
        t = _fix_transparent_rgb(tiles[name])
        tiles[name] = t
        padded = np.pad(t, ((pad, pad), (pad, pad), (0, 0)), mode="edge")
        c, r = i % cols, i // cols
        atlas[r * cell:(r + 1) * cell, c * cell:(c + 1) * cell] = padded
        x0, y0 = c * cell + pad, r * cell + pad
        uv[i] = (x0 / size, 1.0 - (y0 + S) / size, (x0 + S) / size, 1.0 - y0 / size)
        index[name] = i
        vis = t[:, :, 3] > 0
        avg[name] = tuple((t[:, :, :3][vis].mean(axis=0) / 255.0).tolist()) if vis.any() else (.5, .5, .5)

    out = Atlas()
    out.tile, out.pad, out.cell, out.size = S, pad, cell, size
    out.image = Image.fromarray(atlas, "RGBA")
    out.index, out.uv, out.avg, out.tiles = index, uv, avg, tiles
    out.pack_id, out.pack_name = pack_id, info.get("name", pack_id)
    try:
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        out.image.save(CACHE_DIR / "atlas_debug.png")
    except Exception:
        pass
    return out


# ---------------------------------------------------------------- icons -----
def _affine_face(tile_img, o, u, v, canvas):
    T = tile_img.width
    m = np.array([[u[0], v[0]], [u[1], v[1]]], float)
    inv = np.linalg.inv(m)
    o = np.array(o, float)
    a, b = T * inv[0]
    d, e = T * inv[1]
    c = -T * (inv[0] @ o)
    f = -T * (inv[1] @ o)
    return tile_img.transform((canvas, canvas), Image.AFFINE, (a, b, c, d, e, f),
                              resample=Image.NEAREST)


def make_icon(atlas, top_name, side_name, canvas=64):
    """Little isometric cube for the hotbar/inventory."""
    top = Image.fromarray(atlas.tiles[top_name], "RGBA")
    side = Image.fromarray(atlas.tiles[side_name], "RGBA")
    s = canvas / 64.0
    P = lambda x, y: (x * s, y * s)
    D, A, C, B, E, F, G = P(4, 18), P(32, 4), P(32, 32), P(60, 18), P(32, 60), P(4, 46), P(60, 46)
    sub = lambda p, q: (p[0] - q[0], p[1] - q[1])
    img = Image.new("RGBA", (canvas, canvas), (0, 0, 0, 0))
    faces = [
        (top, D, sub(A, D), sub(C, D), 1.0),
        (side, D, sub(C, D), sub(F, D), 0.78),
        (side, C, sub(B, C), sub(E, C), 0.58),
    ]
    for tile, o, u, v, shade in faces:
        f = _affine_face(tile, o, u, v, canvas)
        arr = np.array(f, np.float32)
        arr[:, :, :3] *= shade
        img = Image.alpha_composite(img, Image.fromarray(arr.astype(np.uint8), "RGBA"))
    return img
